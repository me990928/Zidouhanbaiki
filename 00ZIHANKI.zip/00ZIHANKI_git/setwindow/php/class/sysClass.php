<?php

  // require '../db/db.php';
  
  class SysTxt extends Db{
    
    // 改行位置
    public function getBr(){
      $stmt = $this->db->query('select COUNT(*) + 1 from t_layouts where f_item_id = \'-\' ');
      $data = $stmt->fetchAll(PDO::FETCH_NUM);

      return $data;
    }

    public function setTextS($arg){

      // 在庫がいない時ののメッセージ設定

      // echo __DIR__;

      $fp = @fopen('../sys/text/stock.txt', 'w');

      @fwrite($fp, $arg);

      fclose($fp);

      echo '書き込み完了';

    }

    public function setTextZ($arg){
      // 在庫が準備中の時

      $fp = @fopen('../sys/text/zyunbi.txt', 'w');

      @fwrite($fp, $arg);

      fclose($fp);

      echo '書き込み完了';
    }

    public function getTextS(){
      // 中身の配列化
      $fp = @fopen('./php/sys/text/stock.txt', 'r');

      while(!(feof($fp))){
        // 1行分の読み込み
        $aryData[] = fgets($fp);
      }

      fclose($fp);

      return $aryData;
    }

    public function getTextZ(){
      // 中身の配列化
      $fp = @fopen('./php/sys/text/zyunbi.txt', 'r');

      while(!(feof($fp))){
        // 1行分の読み込み
        $aryData[] = fgets($fp);
      }

      fclose($fp);

      return $aryData;
    }

    public function viewAllDisp($data){
      // $data は getText@で取得する
      // 取得データを表示
        $e = count($data);

        while ($e>0) {
          echo $data[$e-1];
          echo "\n";
          $e--;
        }
    }

    public function setDbStocktxt($arg){
      if($arg==='org'){
        $stmt = $this->db->query('update t_not_stock_messages set f_status_id = 1 where f_not_stock_message_id = 1');
        $stmt = $this->db->query('update t_not_stock_messages set f_not_stock_message_key = \'stock.txt\' where f_not_stock_message_id = 1');
      }elseif ($arg==='def'){
        $stmt = $this->db->query('update t_not_stock_messages set f_status_id = 0 where f_not_stock_message_id = 1');
        $stmt = $this->db->query('update t_not_stock_messages set f_not_stock_message_key = \'stock_org.txt\' where f_not_stock_message_id = 1');
      }
    }

    public function setDbZyunbitxt($arg){
      if($arg==='org'){
        $stmt = $this->db->query('update t_preparation_messages set f_status_id = 1 where f_preparation_message_id = 1');
        $stmt = $this->db->query('update t_preparation_messages set f_preparation_message_key = \'zyunbi.txt\' where f_preparation_message_id = 1');
      }elseif ($arg==='def'){
        $stmt = $this->db->query('update t_preparation_messages set f_status_id = 0 where f_preparation_message_id = 1');
        $stmt = $this->db->query('update t_preparation_messages set f_preparation_message_key = \'zyunbi_org.txt\' where f_preparation_message_id = 1');
      }
    }

    public function getStockMsg(){
      $stock = $this->db->query("select f_not_stock_message_key from t_not_stock_messages");
      $data = $stock->fetchAll(PDO::FETCH_NUM);
      return $data;
    }
    public function getZyunbiMsg(){
      $zyunbi = $this->db->query("select f_preparation_message_key from t_preparation_messages");
      $data = $zyunbi->fetchAll(PDO::FETCH_NUM);
      return $data;
    }

  }

?>