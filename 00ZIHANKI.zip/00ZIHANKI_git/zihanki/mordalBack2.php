<?php

// $_POST['drink']='MC000';

// var_dump($_POST);

// echo "a"

require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';

    

  error_reporting(-1);

  $itemObj = new Info();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    $arg[0] = $_POST['drink'];

    $itemObj->getInfo($arg);

    $data = $itemObj->outItemData();

    // $arg = '../setwindow/php/act/text/'.$data[3].'.txt';

    // $text = $itemObj->getInfoText($arg);

    $arg = '../setwindow/php/act/tip/'.$data[4].'.txt';

    $text2 = $itemObj->getInfoText($arg);


    // var_dump($text);

  }else{
    // echo "エラー";
  }

  // var_dump($data);

  // echo count($text);

  // $outInfo = null;

  // for ($i=0; $i < count($text); $i++) { 
  //   $outInfo .= $text[$i];
  // }

  $outTip = null;

  for ($i=0; $i < count($text2); $i++) { 
    $outTip .= $text2[$i];
  }

  echo $outTip;

  // infoTexta.innerText = '{$outInfo}';
  // TipText.innerText = '{$outTip}';
  // infoTexta.data = '../setwindow/php/act/text/{$data[3]}.txt';
  // TipText.data = '../setwindow/php/act/tip/{$data[4]}.txt';
?>