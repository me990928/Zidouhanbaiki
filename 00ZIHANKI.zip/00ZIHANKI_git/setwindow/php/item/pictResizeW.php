<?php

  require "./pictSet.php";

  if ($_POST['addKey']=="materials") {
    $Data = $materials;
  }elseif($_POST['addKey']=="items"){
    $Data = $itemData;
  }


  echo "<br>ここからpictResize<br>";

  // $upFile = $_FILES['in_file'];

  // is_uploaded_file関数
  // 引数：一時ファイル名($_FILESよりtmp_name)
  // 戻り値：true(ファイルアップでできたもの) or
  //        false(ファイルアップ以外)
  if(is_uploaded_file($upFile["tmp_name"])){

    $fileName = $upFile['name'];

      $i=0;


      if( file_exists($IMG_DIR_SL.$fileName)){
        echo "あるxUXUXUXうぅうぅ";
      }else{
        echo "ナイナイナイナイないxixixixix";
        echo $IMG_DIR_SL.$fileName;
        echo '<img src=\''.$IMG_DIR_SL.$fileName.'\'>';
      }

      while(file_exists($IMG_DIR_SL.$fileName)){
        $fileName = $i.$fileName;
        $i++;
      }


        $ext = explode(".",$fileName);

        if($_POST['addKey']=='items'){

          $itemData[1] = $ext[0];  // <-ここ対処

          $upFile['name'] = $fileName;

          $useData[6] = $itemData[1];

        }elseif ($_POST['addKey']=='materials') {

          $materials[1] = $ext[0];  // <-ここ対処

          $materials[2] = $materials[1];

          $upFile['name'] = $fileName;

        }

        echo '拡張子'.$ext[1];
        if($ext[1] === 'png' || $ext[1] === 'ping'){
          move_uploaded_file($upFile['tmp_name'], $IMG_DIR_SL.$upFile['name'] );
        }


    //ファイルアップでできたもの

    //入力検証
    //  ・ファイルの種類が正しいか(typeから判定)

    //  ・ファイル名の拡張子をチェック
    // //    ↓ explode or str_split
    // $ext = explode(".",$fileName);
    // $strExt = $ext[count($ext)-1];

    // アップロード処理
    //  move_uploded_file関数
    //    引数：コピー元ファイル名、コピー先ファイル名
    //    戻り値：true(成功) or false(失敗)
        echo '個こここここ'.$IMG_DIR_SL.$fileName;
    if(  move_uploaded_file( $upFile["tmp_name"], $IMG_DIR_SL.$fileName)  ){
      // 出来上がったファイルがプレビューできない・・・
      // ->tempフォルダに権限がない
      //  ->設定していないのでosのtempフォルダになる
      // print "<br><img src=\"./img/".$upFile['name']."\" style='width: 300px'>";


      print "アップロード完了！";

      // サムネイル化
        // GD2ライブラリ

      //1. プログラムで画像ファイルを操作できるようにする。
      //    →新規作成で中身空っぽの画像ファイル生成
      //2. 元画像から作成した画像ファイルにイメージをコピー
      //3. 画像ファイルの出力

      //iamgecreatefromjpeg関数
      //                 ↑gif,bmp,png,webp
      //  引数   ：画像ファイル名
      //  戻り値 ：リソースID(Resource)
      // $img_org_id = imagecreatefromjpeg($IMG_DIR_SL.$fileName);

      $file_type = mime_content_type($IMG_DIR_SL.$fileName);


          echo 'こここここっここここここ'.$fileName;

      switch ($file_type) {

        case 'image/jpeg':
          $img_org_id = imagecreatefromjpeg($IMG_DIR_SL.$fileName);
          $fileName = explode(".",$fileName);
          $fileName = $fileName[0];
          imagepng($img_org_id, $IMG_DIR_SL.$fileName.'.png');
          imagedestroy($img_org_id);
          break;

        case 'image/png':
          $img_org_id = imagecreatefrompng($IMG_DIR_SL.$fileName);
          $fileName = explode(".",$fileName);
          $fileName = $fileName[0];
          imagepng($img_org_id, $IMG_DIR_SL.$fileName.'.png');
          imagedestroy($img_org_id);
          break;

        case 'image/gif':
          $img_org_id = imagecreatefromgif($IMG_DIR_SL.$fileName);
          $fileName = explode(".",$fileName);
          $fileName = $fileName[0];
          imagepng($img_org_id, $IMG_DIR_SL.$fileName.'.png');
          imagedestroy($img_org_id);
          break;

        default:
          break;

      }

      $img_org_id = imagecreatefrompng($IMG_DIR_SL.$fileName.'.png');

      //imagesx関数(横幅)、imagesy関数(縦幅)
      //  引数  ： リソースID
      //  戻り値：幅(ピクセル)
      $img_org_x = imagesx($img_org_id);
      $img_org_y = imagesy($img_org_id);

      //  新しい横幅 200pxで計算  →続きは10/31 下の式は自分で出したやつ
      $img_new_xx = $IMG_NEW_WIDTH;
      $img_new_yy = $img_org_y * ($img_new_xx / $img_org_x);

      //imagecreatetruecolor関数
      //  新規作成で画像ファイルを作る
      //  引数  ：横幅、縦幅
      //  戻り値：リソースID
      $img_new_id = imagecreatetruecolor($img_new_xx, $img_new_yy);

      //②imagecopyresized関数
      //  引数：コピー先のID、コピー元のID
      //       コピー先の開始座標(x座標,y座標)
      //       コピー元の開始座標(x座標,y座標)
      //  戻り値：true or false
      $copy_flag = imagecopyresized($img_new_id,$img_org_id,0,0,0,0,$img_new_xx,$img_new_yy,$img_org_x,$img_org_y);
    
      if($copy_flag === true){
        print "コピー成功";
      }else{
        print "コピー失敗した！";
      }

      // 出力用のフォルダ確認と生成
      if(file_exists($THUM_DIR) === false){
        // フォルダなし
        mkdir($THUM_DIR,0777);
      }

      // ③imageXXXX関数
      //      →jpeg,gif,png,bmp
      //   引数：リソースID,ファイル名
      //   戻り値：true or false
      $out_flg = imagepng($img_new_id,$THUM_DIR_SL.$fileName.'.png');

      if($out_flg === false){
        print "出力に失敗した！！！！！";
      }

      print_r($img_new_id);
      print_r($img_org_id);

      // imagedestroy関数
      //  引数：リソースID
      imagedestroy($img_new_id);
      imagedestroy($img_org_id);

      unlink($IMG_DIR_SL.$fileName.'.png');
    }
  }else{
    //何かしらできたもの
    print"何でおんねん";
  }

  var_dump($_FILES);
?>
