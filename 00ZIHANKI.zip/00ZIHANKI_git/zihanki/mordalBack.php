<?php

// var_dump($_POST);

// echo "a"

require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';

    

  error_reporting(-1);

  $itemObj = new Info();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    $arg[0] = $_POST['drink'];

    $itemObj->getInfo($arg);

    $data = $itemObj->outItemData();

    $arg = '../setwindow/php/act/text/'.$data[3].'.txt';

    $text = $itemObj->getInfoText($arg);

    // var_dump($text);

  }else{
    // echo "エラー";
  }

  // var_dump($data);

  // echo count($text);

  $out = null;

  for ($i=0; $i < count($text); $i++) { 
    $out .= $text[$i].'<br>';
  }

echo "
<div id='winBox'>

            <div id='modal-window2'>
                <div id='box2'>
                            <div id='hukidashi' class='balloon2-right'>

                                <div id='title'>{$data[1]}</div>

                                <div class='colBox'>
                                    <img src='../setwindow/php/act/imgItemOri/{$data[7]}.png'>
                                    <p style='width: 400px;'>
                                        $out
                                    </p>
                                </div>

                            </div>
                      
                            <img id='char' src='sozai/akane_shiran_a.png' alt='ナレーター'>
                        
                </div>
            </div>



            <div id='modal-window'>
                <div id='box'>
                    <div id='msg'>{$data[1]}を購入しますか？<br>価格￥{$data[2]}</div>
                    <div id='yesNoSelector'>
                      <div id='btn'><a id='objA'>YES</a></div>
                      <div id='btn2'><a id='objA2'>NO</a></div>
                  </div>
                </div>
            </div>

            <script>

    $('#objA2').on('click',function(){
      $('#winBox').css('visibility','hidden')
    })
            </script>

          ";



?>