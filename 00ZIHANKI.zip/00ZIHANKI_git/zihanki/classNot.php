<?php

require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';
require '../setwindow/php/class/layoutClass.php';

require './zaikoSys.php';
require './zaiko_0.php';

$itemObj = new Info();
  $sysObj = new SysTxt();

  if($itemObj->conn()){     // DB実行準備

    $sysObj->conn();

    $dbConn2 = $sysObj->getDb();

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

    $list = $itemObj->getItemData();

    

    $cnt = count($list);

    for ($i=0; $i < $cnt; $i++) { 
      $e = $itemObj->getPictName($list[$i][8]);
      $pict[$i] = $e[0];
    }

    $layData = $itemObj->getlayoutData();
    // var_dump($pict[2]);


    $layData[0][2]; // 商品ID
    $layData[0][1]; // 配置番号
    $laySum = count($layData); // 合計配置数


for ($i=0; $i < $laySum; $i++) { 

    $arg[0] = $layData[$i][2];

    $itemObj->getInfo($arg);

    $data[$i] = $itemObj->outItemData();

  }

    // echo $pict[1][0];
    // echo $list[1][2];

    // var_dump($textTips);

   $brPosi = $sysObj->getBr();

  }else{
    // echo "エラー";
  }

$z = '0';


for ($i=0; $i < $laySum; $i++) { 
  $not = false;

  if ($layData[$i][3]==="1") {
    $z++;
    $hs = array_search($data[$i][0], $hot0);
    if($hot0[$hs]!=$data[$i][0]){
      $not = true;
    }
  }elseif ($layData[$i][3]==="0") {
    $z++;
    $cs = array_search($data[$i][0], $cool0);
    if($cool0[$cs]!=$data[$i][0]){
      $not = true;
    }
  }
    $nf = "";
  if ($layId[$i][1]<1 || $not=='true') {

    $class = "drink".$z;

    echo 
    "<script src='js/jquery-3.2.1.min.js'></script>
    <script>
     $(function(){
        let test = $(document).find('.{$class}').addClass('select-not');
        let test1 = $(document).find('.drink{$z}m').addClass('not');
        test.attr('id','{$layData[0][2]}not');
        test.removeClass('box');
        test.addClass('boxnot')
        console.log(test);
     });
    </script>";
  }


}

// var_dump($zaikoArr);
?>
