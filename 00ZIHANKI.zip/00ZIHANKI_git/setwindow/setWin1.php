<?php
  date_default_timezone_set('Asia/tokyo');

  require './php/escape.php';

  // var_dump($_COOKIE);

  error_reporting(0);


  if($_COOKIE['userClass']!=="1" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+1);
    header('location: ./back.php');
  }

  error_reporting(-1);

  require './php/class/db.php';

  require './php/item/itemsClass.php';

  $itemObj = new Items();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

  }else{
    // echo "エラー";
  }

  $list = $itemObj->getMaterialList();

  $num = $itemObj->getMaterialNum();

  $itemList = $itemObj->AlldispItemsId();


  // var_dump($_COOKIE);

?>

<!DOCTYPE html>


        <!-- <button id="openModal">Open modal</button> -->

        <!-- モーダルエリアここから -->
        <section id="modalArea" class="modalArea">
          <div id="modalBg" class="modalBg"></div>
          <div id="toggle" class="modalWrapper">
            <div class="modalContents">
              <h1 id="mordalTitle"></h1>
              <div id="stockList"></div>
              <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p> -->
            </div>
            <div id="closeModal" class="closeModal">
              ×
            </div>
          </div>
        </section>
        <!-- モーダルエリアここまで -->

        <!-- モーダルエリアここから -->
        <section id="modalArea2" class="modalArea2">
          <div id="modalBg2" class="modalBg2"></div>
          <div id="toggle" class="modalWrapper2">
            <div class="modalContents2">
              <h1 id="mordalTitle2"></h1>
              <div id="stockList2"></div>
              <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p> -->
            </div>
            <div id="closeModal2" class="closeModal2">
               ×
            </div>
          </div>
        </section>
        <!-- モーダルエリアここまで -->

<html lang="ja">



  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <script defer type="text/javascript" src="js/ajax-logout.js"></script>
    <script defer type="text/javascript" src="js/ajax-setWin1.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>

  </head>

  <body>

    <main class="content">



      <div id="infoBar">
        <p class="black">
          <?= date("Y-m-d") ?>
        </p>
      </div>
      
      <div id="contents">

        <form id="itemForm" method="post" action="addItemsPage.php" name="itemForm" enctype="multipart/form-data">

      <h1>商品追加</h1>

      商品名   :<input type="text" name="f_item_name" id="f_item_name" required><div id="errNamei" class="red"></div><br>

      価格       :<input type="number" name="f_price" id="f_price" required><div id="errPrice" class="red"></div><br>

      商品情報:<br>
      <textarea name="f_item_info_id" id="f_item_info_id" required></textarea><div id="errInfo" class="red"></div><br>

      商品豆知識:<br>
      <textarea name="f_tip_info_id" id="f_tip_info_id" required></textarea><div id="errTip" class="red"></div><br>

      材料１ :<select name="f_material_1_id" id="f_material_1_id" required>
        <option>----------</option>
        <?php
          for ($i=0; $i < $num[0][0]; $i++) { 
            echo "<option>".$list[$i]['f_material_id']."-".$list[$i]['f_material_name']."</option>";
          }
        ?>
      </select><div id="errMate1" class="red"></div><br>

      材料２ :<select name="f_material_2_id" id="f_material_2_id" required>
        <option>----------</option>
        <?php
          for ($i=0; $i < $num[0][0]; $i++) { 
            echo "<option>".$list[$i]['f_material_id']."-".$list[$i]['f_material_name']."</option>";
          }
        ?>
      </select><div id="errMate2" class="red"></div><br>

      商品画像  :<input type="file" name="itemPict" id="itemPict" accept='image/png' required><div id="errPict" class="red"></div><br>

      <!-- hiddenで値を送って商品追加判断 -->
      <input type="hidden" name="addKey" value="items">

      <!-- <input type="submit" name="" value="send"> -->

      <section><a class='btn_03' id="itemBtn">SEND</a></section>


    </form>

    <form id="mateForm" method="post" action="addItemsPage.php" enctype="multipart/form-data">
      
      <!-- hiddenで値を送って材料追加判断 -->
      <input type="hidden" name="addKey" value="materials">
      <h1>商品材料追加</h1>
      材料名:<input type="text" name="f_material_name" id="f_material_name" required><div id="errName" class="red"></div><br>
      材料画像:<input type="file" name="f_material_key" id="f_material_key" accept='image/png' required><div id="errFile" class="red"></div><br>
      <!-- <input type="submit" value="send" name=""> -->

      <div id="mateDbug"></div>

      <section><a class='btn_03' id="mateBtn">SEND</a></section>


    </form>


    <form id="stockerForm" method="post">
      
      <h1>在庫追加</h1>

      商品選択 : <select id="itemId" name="itemId" style="width: 200px;" required>
        <option>商品を選択してください</option>
        <?php
          $num=count($itemList);
          for ($i=0; $i < $num; $i++) { 
            echo "<option value=".$itemList[$i]['f_item_id'].">".$itemList[$i]['f_item_id'].'-'.$itemList[$i]['f_item_name']."</option>";
          }
        ?>
      </select><div id="errId" class="red"></div><br>

      商品準備時間 : <input type="number" id="time" name="time" placeholder="Time" max="120" min="0" style="width: 100px;" required><div id="errTime" class="red"></div><br>
      商品温度 : <input type="number" id="temp" name="temp" placeholder="items Temp" max="100" min="5" style="width: 100px;" required><div id="errTemp" class="red"></div><br>
      追加数 : <input type="number" id="stock" name="stock" placeholder="stock" max="100" min="1" style="width: 100px;" value="1" required><div id="errStock" class="red"></div><br>

      <div id="stokeFormDeback" style="margin-top: 30px;"></div>

      <section><a class='btn_03' id="stockBtn">SEND</a></section>


    </form>

      <div style="padding: 30px 0;"></div>

      <section><a class='btn_03' id="stockListBtn2">StockList</a></section>
      <section><a class='btn_03' id="stockListBtn">StockCounter</a></section>

<!--         <form method='get' action='#'>
          <h1>商品追加</h1><h3>商品名</h3><input type='text' name='itemName' placeholder="商品名"><br>
          <h3>販売価格</h3><input type='text' name='itemCost' placeholder="商品価格"><br>
          <h3>商品情報：<input type='checkbox' name=''>有効にする</h3><textarea rows='10' cols='35' placeholder="商品情報を入力してください"></textarea>
          <h3>お役立ち情報：<input type='checkbox' name=''>有効にする</h3><textarea rows='10' cols='35' placeholder="お役立ち情報を入力してください"></textarea><br>
          
          <h3 class="red">↑追加する商品の設定をする画面です</h3>

          <h1>素材使用アニメーション</h1>
          <h3>アニメーションを有効にする：<input type='checkbox' name='' checked></h3>
          <h3>材料A：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3>
          <h3>材料B：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3>

          <h3 class="red">↑アニメーションを有効にすると、容器に材料Aと材料B入れるアニメーションが商品購入後に再生されます。</h3>

          <section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section>
        </form> -->

        <div style="padding: 30px 0;"></div>

        <form method="post" id="logoutForm" style="padding-bottom: 500px;">
          <input type="hidden" id="outPram" name="logout" value="true" >
          <section><a class='btn_03' id="logoutBtn">LOGOUT</a></section>
        </form>
          <!-- <section><a href='../../index_0.html' class='btn_03' onclick='document.a_form.submit();' id="logoutBtn">LOGOUT</a></section> -->
          <!-- <h3 class="red logOut">ログアウトすることで自販機画面に戻ります</h3> -->

      </div>

      

      <!-- デバック用 -->
      <?php

        // echo "<div style='margin-bottom: 30px;'>ここからデバック画面</div>";

        // var_dump($_COOKIE);

        // echo "<div style='margin-top: 30px;'>終了</div>";

      ?>
      <!-- デバック用 -->
      
      <!-- <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin1.html" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin2.html" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin3.html" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin4.html" id="item4">menu</a>
          </span>
        </div>

      </div> -->


      <?php

      require 'footer.php';

      ?>

    </main>

  </body>
</html>