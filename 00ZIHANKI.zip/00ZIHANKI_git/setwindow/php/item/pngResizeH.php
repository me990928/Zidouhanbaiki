<?php
  // error_reporting(0);
  require 'pictSet.php';

  // $THUM_DIR = 'PICTURE';

  // $THUM_DIR_SL = './PICTURE/';

  // $IMG_DIR = 'PICTURE_ORG';

  // $IMG_DIR_SL = './PICTURE_ORG/';

  // $IMG_NEW_HIGHT = 200;
  // $IMG_NEW_WIDTH = 200;


  var_dump($_FILES);

  if ($_POST['addKey']==='materials') {  
    $upFile = $_FILES['f_material_key'];
  }elseif ($_POST['addKey']==='items') {
    $upFile = $_FILES['itemPict'];
  }

  $sample = file_exists($upFile['tmp_name']);

  if ($sample) {
    echo "<br>ファイルの存在を確認！<br>";

    // 出力用のフォルダ確認と生成
    if(file_exists($THUM_DIR)){
    }else{
      // echo 'フォルダなし';
      mkdir($THUM_DIR,0777);
    }
    // echo "フォルダあった";
    // 出力用のフォルダ確認と生成
    if(file_exists($IMG_DIR) === false){
      // フォルダなし
      mkdir($IMG_DIR,0777);
    }

  if(is_uploaded_file($upFile['tmp_name'])){
    echo "アップロード確認！<br>";

    // ファイル名取得
    $fileName = $upFile['name'];

    // Db接続
    try {
      $Db = new PDO('mysql:host=localhost;dbname=zihankisys;charset=utf8;port=3306','root','root');
      echo "success<br>";
    } catch (Exception $e) {
      echo "error<br>";
    }

    // ファイルナンバリング用変数
    if($_POST['addKey']==='materials'){
      $stmt = $Db->query('select count(*) as \'count\' from t_materials');
      $list = $stmt->fetchAll( PDO::FETCH_ASSOC );
      $file_num = $list[0]['count'];
    }elseif ($_POST['addKey']==='items') {
      $stmt = $Db->query('select count(*) as \'count\' from t_items');
      $list = $stmt->fetchAll( PDO::FETCH_ASSOC );
      $file_num = $list[0]['count'];
    }

    $ext = explode('.',$fileName);

    if(file_exists($IMG_DIR_SL.$ext[0].'.png')){
      echo "ある";
      $fileName = $file_num.$fileName;
    }

    chmod($IMG_DIR_SL, 0777);

    if(move_uploaded_file($upFile['tmp_name'], $IMG_DIR_SL.$fileName)){
      echo "オリジナルファイル転送成功<br>";
      $e = file_exists($IMG_DIR_SL.$fileName);

    echo $e;
    }

    $file_type = mime_content_type($IMG_DIR_SL.$fileName);

    echo $file_type.'<br>';

    //png変換
    switch ($file_type) {
      case 'image/jpeg':
          $img_org_id = imagecreatefromjpeg($IMG_DIR_SL.$fileName);
          $_fileName = explode(".",$fileName);
          imagepng($img_org_id, $IMG_DIR_SL.$_fileName[0].'.png');
          imagedestroy($img_org_id);
          unlink($IMG_DIR_SL.$fileName);
          $fileName = $_fileName[0].'.png';
          unset($img_org_id);
        break;
      
      case 'image/png':
          echo "これはpng?!<br>";
        break;
      default:
        echo "エラー処理考えといて！<br>";
    }

    $_fileName = explode(".",$fileName);

    if($_POST['addKey']=='items'){
      $itemData[1] = $_fileName[0];
      $useData[6] = $itemData[1];
      echo "商品写真";
    }elseif ($_POST['addKey']=='materials') {
      $materials[1] = $_fileName[0];
      $materials[2] = $materials[1];
      echo "材料写真";
    }

    echo $fileName.'<br>';

    //長さ取得
    $img_org_id = imagecreatefrompng($IMG_DIR_SL.$fileName);
    $img_org_x = imagesx($img_org_id);
    $img_org_y = imagesy($img_org_id);

    //変換後の長さ
    // $img_new_xx = $IMG_NEW_WIDTH;
    // $img_new_yy = $img_org_y * ($img_new_xx / $img_org_x);
    $img_new_yy = $IMG_NEW_HIGHT;
    $img_new_xx = $img_org_x * ($img_new_yy / $img_org_y);

    $img_new_id = imagecreatetruecolor($img_new_xx, $img_new_yy);
    //ブレンドモードを無効にする
    imagealphablending($img_new_id, false);
    //完全なアルファチャネル情報を保存するフラグをonにする
    imagesavealpha($img_new_id, true);


    $copy_flag = imagecopyresized($img_new_id,$img_org_id,0,0,0,0,$img_new_xx,$img_new_yy,$img_org_x,$img_org_y);

    if($copy_flag === true){
      echo 'コピー成功！<br>';
      $out_flg = imagepng($img_new_id,$THUM_DIR_SL.$fileName);
    }else{
      echo 'コピー失敗！<br>';
    }


    imagedestroy($img_new_id);
    imagedestroy($img_org_id);

    // unlink($IMG_DIR_SL.$fileName);

  }



  }else{
    echo "ファイルが存在しません！";
  }
  
?>
