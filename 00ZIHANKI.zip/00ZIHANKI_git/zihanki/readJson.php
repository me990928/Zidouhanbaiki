<?php

  $jsonUrl = "zaikoList.json";

  if (file_exists($jsonUrl)) {
    $jsonArr = file_get_contents($jsonUrl);

    $jsonData = mb_convert_encoding($jsonArr, 'UTF8', 'ASCII,JIS,UTF-8,EUC-JP,SJIS-WIN');

    $Arry = json_decode($jsonData);

    // json確認用
    $n = 0;
    foreach ($Arry as $value) {
      for ($i=0; $i < count($value); $i++) { 
        echo $value[$i].'/';
      }
      echo "<br>";
    }
  }else{
    echo "error";
    exit;
  }


?>