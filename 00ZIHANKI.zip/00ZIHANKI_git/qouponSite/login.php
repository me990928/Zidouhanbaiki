<?php
  // error_reporting(0);
  // var_dump($_POST); echo "<br>";
  // var_dump($_COOKIE); echo "<br>";
  date_default_timezone_set('Asia/tokyo');

  require '../setwindow/php/escape.php';
  require '../setwindow/php/class/db.php';
  require '../setwindow/php/class/userLogin.php';

  $userName = "Not Login !";

  $loginObj = new userLogin();

  // var_dump($_POST);

  error_reporting(-1);

  $loginObj = new userLogin();

  if (isset($_POST['login'])) {
    $loginObj->flagB = true;
    $user[0] = $_POST['userId'];
    $user[1] = $_POST['userPas'];
    echo $loginObj->flagB;
    $loginObj->setLoginId($user[0]);
    $loginObj->setLoginPass($user[1]);

    $loginObj->testModule();

    if($loginObj->conn()){     // DB実行準備

      $dbConn = $loginObj->getDb();  // DB実行

      $loginObj->findAccount($user[0],$user[1]);  // 認証

      // echo "<span style=\"color:red;\"><br>＊userOptinが表示されていない場合は更新してください</span>";

    }else{
      // echo "エラー";
  }
  }


  // var_dump($_COOKIE);
  if(isset($_COOKIE['loginFlag'])){
    if($_COOKIE['loginFlag']==true){
      // echo "<br><button onclick=\"location.href='userOption_page0.php'\">userOptin</button>";
      // echo "<br><button onclick=\"location.href='userReinput.php'\">userReinput</button>";
    }
  }


  // echo "<br>".$removeBtn;

  if (isset($inputUser)) {
    // echo "<br>".$inputUser."ユーザ登録<br>";
  }

  // if ($_COOKIE['msg']!==null) {
    // echo "<br><span style='color: red;'>".$_COOKIE['msg']."</span>";
  // }


  if (isset($_GET['logout'])) {
    $loginObj->userLogout();
  }

  // if ($_COOKIE['loginFlag']==true) {
  //   echo "
  //     <script type='text/javascript'>
  //       setTimeout('link()', 0);
  //       function link(){
  //       location.href='./setWin1.php';
  //       }
  //       </script>
  //   ";
  //   exit();
  // }

  var_dump($_COOKIE);

?>