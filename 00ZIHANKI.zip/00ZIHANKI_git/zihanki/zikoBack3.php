<?php

  require '../setwindow/php/class/db.php';
  require '../setwindow/php/class/layoutClass.php';
  $zaiObj = new Lay();

  if($zaiObj->conn()){
    $dbConn = $zaiObj->getDb();

    // ポジションテーブル一覧
    $posiData = $zaiObj->getLay();
    // 在庫テーブル一覧
    // $zaiData = $zaiObj->getZai();

    // var_dump($posiData);

    // レアウトされる商品の種類表
    for ($i=0; $i < count($posiData); $i++) { 
      $data[$i] = $posiData[$i][2];
    }

    // var_dump($posiData[0][3]);

    $data2 = array_unique($data);

    $i=0;

    $idList[]=null;

    foreach ($data2 as $val) {
      $List[$i] = $val;
      $i++;
    }
    // 完成

    // var_dump($List);

    // IDごとの在庫配列
    for ($i=0; $i < count($List); $i++) { 
      $id[$i] = $zaiObj->getZai($List[$i]);
    }

    // 完成

    // var_dump($id[0][0][2]); // 時間
    // var_dump($id[0][0][5]); // 追加日時
    // var_dump($id[0][0][1]); // 追加日時

    // 現在時刻取得
    date_default_timezone_set('Asia/Tokyo');
    $today = date('Y-m-d G:i:s');
    // echo $today.'<br>';

    // 在庫確認配列
    for ($i=0; $i < count($List); $i++) { 
      for ($n=0; $n < count($id[$i]); $n++) { 
        if($List[$i]==$id[$i][$n][1]){
        }
      }
      // echo $List[$i]."が{$n}こある";
      $zaiko[$i][0]=$List[$i];
      $zaiko[$i][1]=$n;
    }

    // 在庫判定
    for ($i=0; $i < count($zaiko); $i++) { 
      if($zaiko[$i][1]<1) {
        // echo $zaiko[$i][0]."在庫なし";
        $nzFlag='1';
      }else{
        // echo $zaiko[$i][0]."在庫あり";
        $nzFlag='0';
      }
    }
  }

  // IDごとの在庫
  // var_dump($zaiko);

  // $a = $zaiObj->getAddTime($arg);

  // print_r($a);

  for ($i=0; $i < count($data); $i++) { 
    $layId[$i][0] = $data[$i];
    for ($n=0; $n < count($zaiko); $n++) { 
      if ($data[$i]===$zaiko[$n][0]) {
        $layId[$i][1] = $zaiko[$n][1];
      }
    }
  }

  // ここまでがフロント用
// 自販機のレイアウト番号ごとの在庫
  // var_dump($layId);

  // 在庫データ配列作成
  $zaikoArr[] = 'null';

  for ($i=0; $i < count($List); $i++) {
    $zaikoArr[$i] = $zaiObj->getAllZai($List[$i]);
  }

  // var_dump($zaikoArr[3][2]);

  $zaikoList[][] = null;

  $n = 0;

  for ($i=0; $i < count($zaikoArr); $i++) { 
    foreach ($zaikoArr[$i] as $val) {
      if($val[3]<=30){
        $temp = 0;
        for ($k=0; $k < count($val); $k++) { 
          $zaikoList[$n][$k]=$val[$k];
        }
        $zaikoList[$n][$k]=$temp;
      }else{
        $temp = 1;
        for ($k=0; $k < count($val); $k++) { 
          $zaikoList[$n][$k]=$val[$k];
        }
        $zaikoList[$n][$k]=$temp;
      }
    $n++;
    }
  }

  $listArry = json_encode($zaikoList);
  file_put_contents('./json/zaikoList.json', $listArry);

// 陳列する商品の在庫リスト
// ID,商品ID,準備時間,温度,商品追加者,ホットorクール
// foreach ($zaikoList as $value) {
//   print_r($value);
  // echo "<br>";
// }

// print_r($zaikoList[0]);
// 温かいをハンドリングする
// $i = 0;
// $c = 0;
// foreach ($zaikoList as $value) {
//   $res[$i]=array_search('1', $value);
//   if($res[$i]){
//     // echo "$i/";
//     $cnt[$c] = $i;
//     $c++; 
//   }
//   $i++;
// }
$c = 0;
$i = 0;
$res = null;
foreach ($zaikoList as $val) {
  if($val[6]){
    $res[$i] = $c;
    $i++;
  }
  $c++;
}


if($res==null){
  $res = '';
}

$resj = json_encode($res);
file_put_contents('./json/hotList.json', $resj);

// // 冷たいをハンドリングする
// $i = 0;
// $c = 0;
// foreach ($zaikoList as $value) {
//   $res[$i]=array_search('0', $value);
//   if($res[$i]){
//     // echo "$i/";
//     $cnt[$c] = $i;
//     $c++;
//   }
//   $i++;
// }
$c = 0;
$i = 0;
$res = null;
foreach ($zaikoList as $val) {
  if($val[6]===0){
    $res[$i] = $c;
    $i++;
  }
  $c++;
}

if($res==null){
  $res = '';
}

$resj = json_encode($res);
file_put_contents('./json/coolList.json', $resj);

// var_dump($resj);

// 購入シミュレーション
// error_reporting(0);
// // 冷たい飲み物を探す
// $cnt = 0;
// $coolBuy = false;
// $drinkName = $_GET['coolName'];

// if ($_GET['coolFlag']=='1' && $drinkName!=='') {
// error_reporting(-1);
//   // echo "<br>";
//   if($drinkName!=''){
//     foreach($zaikoList as $val){
//       if($val[1]==$drinkName && $val[6]==0){
//         $cnt++;
//       }
//     }
//   }
//   // デバッグ用
//   // echo $drinkName.'<br>';
//   // echo 'count:'.$cnt;
//   // echo "<br>";

//   $coolBuy = true;
// }

// 在庫消費シミュレーション

// if ($coolBuy) {
//   $res = file_get_contents('./json/coolList.json',false);
//   $resNum = json_decode($res);
//   // var_dump($resNum);
//   $res = file_get_contents('./json/zaikoList.json',false);
//   $List = json_decode($res);
//   // var_dump($List);
//   $coolId = $zaiObj->FncFindBuy($resNum,$List,$drinkName);

//   // echo "$coolId";

//   $zaiObj->setDelZai($coolId);

// }


// 温かい飲み物を探す
// error_reporting(0);

// $cnt = 0;
// $hotBuy = false;
// $drinkName = $_GET['hotName'];

// if ($_GET['hotFlag']=='1' && $drinkName!=='') {
// error_reporting(-1);
//   // echo "<br>";
//   if($drinkName!=''){
//     foreach($zaikoList as $val){
//       if($val[1]==$drinkName && $val[6]==1){
//         $cnt++;
//       }
//     }
//   }
  // デバッグ用
  // echo $drinkName.'<br>';
  // echo 'count:'.$cnt;
  // echo "<br>";

//   $hotBuy = true;
// }

// 在庫消費シミュレーション

// if ($hotBuy) {
//   $res = file_get_contents('./json/hotList.json',false);
//   $resNum = json_decode($res);
//   // var_dump($resNum);
//   $res = file_get_contents('./json/zaikoList.json',false);
//   $List = json_decode($res);
//   // var_dump($List);
//   $hotId = $zaiObj->FncFindBuy($resNum,$List,$drinkName);

//   // echo "$hotId";

//   $zaiObj->setDelZai($hotId);
// }
?>