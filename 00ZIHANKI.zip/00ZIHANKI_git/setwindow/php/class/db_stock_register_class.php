<?php
// itemClass.php と同時に使う

// require './itemsClass.php';

class Stock extends Items{

  public function stockRegister($arg){

    $itemId = $arg[0];
    $time = $arg[1];
    $temp = $arg[2];
    $user = $arg[3];

    $stmt = $this->db->prepare('insert into t_items_stocks (f_item_id, f_preparation_time_m, f_temp, f_add_user) values(:itemId,:time,:temp,:user)');

    $stmt->bindParam(":itemId",$itemId,PDO::PARAM_STR);
    $stmt->bindParam(":time",$time,PDO::PARAM_INT);
    $stmt->bindParam(":temp",$temp,PDO::PARAM_INT);
    $stmt->bindParam(":user",$user,PDO::PARAM_STR);

    $stmt->execute();

    $msg = "Success";

    setcookie('msg',$msg,time()+100);
  }

  public function getStockList(){
    $list = $this->db->query('select * from t_items_stocks');
    $list = $list->fetchAll( PDO::FETCH_NUM );
    return $list;
  }

  public function getStocCounter(){
    $list = $this->db->query('select count(*) as \'stock\', f_item_id  from t_items_stocks group by f_item_id');
    $list = $list->fetchAll( PDO::FETCH_NUM );
    return $list;
  }

  public function creatTable($arg,$mode){

    echo "<table id='tableC' border='1'>";

    if($mode == "c"){
      echo "<tr>
              <td>Stock</td>
              <td>ItemID</td>
            </tr>";
    }elseif($mode == "l"){
      echo "<tr>
              <td>StockID</td>
              <td>ItemID</td>
              <td>Time</td>
              <td>Temp</td>
              <td>RegistUser</td>
              <td>RegistDate</td>
            </tr>";
    }

    for($i = 0; $i < count($arg); $i++){
      echo "<tr>";
      for($n = 0; $n < count($arg[$i]); $n++){
        echo '<td>'.$arg[$i][$n].'</td>';
      }
      echo "</tr>";
    }

    echo "</table>";
  }

}


?>