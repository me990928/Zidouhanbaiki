<?php

  // require '../escape.php';

  require '../class/db.php';

  require '../item/itemsClass.php';

  require '../class/layoutClass.php';

  $layout = new Lay();

  // var_dump($_FILES);

  if ($_POST['cuponTitle']=='' || $_FILES['logoFile']=='') {
    // code...
    exit();
  }

  if($layout->conn() ){     // DB実行準備

      $dbConn = $layout->getDb();  // DB実行

    }else{
      echo "失敗";
    }

  // var_dump($_POST);

  // var_dump($_FILES);

  $data = $_FILES['logoFile'];

  $layout->setCpnPict($data);

  $data2[0] = $_POST['cuponTitle'];

  $data2[1] = './setwindow/php/act/cpnPict/'.$data['name'];

  $layout->setCpnBox($data2);

  echo "<span style='color: blue;'>アップロード完了！</span>";

?>