$(function () {


    // $('.box').on('click',function() {
    $('.box').on('click',function() {
        // let formId = '#'+$(this).children().next().next().attr('id')
        // console.log(formId)


        // var $form = $(formId);
        // var query = $form.serialize();

        // formId = $(this,'box').children().children().next().attr('id');
        // POST
        // let $form = $('#'+formId);
        // let $form = $(formId);
        // let formData = new FormData($form.get(0));
        // let formData = new FormData(formId);


        // let id_name = $(this).find('.findF').attr('id');


        // let $form = $('#'+id_name);
        // let query = $form.serialize();

        // console.log(query)



        // let formData = 'MC000';


        // $('.box').on('click',function(){
        //     let id_name = $(this).attr('id');
        //     console.log(id_name)
        // })



        $('.box').on('click',function(){
          $('#modal-wrap').css('visibility','visible')
        })

        $('#objA').on('click',function(){
          $('#winBox').css('visibility','hidden')
        })

        $('#objA2').on('click',function(){
          $('#winBox').css('visibility','hidden')
        })

    // let $form = $('#layoutForm');
    // var formData = new FormData($form.get(0));

    // $('.box').on('click', function () {

    //     // $.ajax({
    //     //     url: 'getDrink.php',
    //     //     // type: 'GET',
    //     //     type: 'POST',
    //     //     async: true,
    //     //     // // data: strQuery,
    //     //     data: query,
    //     //     // processData: false,
    //     //     // contentType: false,
    //     //     cache: false,
    //     // })
    //     //     .done(function (responce) {
    //     //         $('#inputBox').html(responce);
    //     //         console.log('wow')
    //     //     })
    //     //     .fail(function (xhr) {
    //     //         $('#boxObj').html(xhr);
    //     //         console.log('hoge');
    //     //     })
    //     //     .always(function (xhr, msg) {
    //     //         // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
    //     //         // console.log('hoge');
    //     //         // console.log(msg);
    //     //     });
    //     $.ajax({
    //         url: 'mordalBack1.php',
    //         // type: 'GET',
    //         type: 'POST',
    //         async: true,
    //         // // data: strQuery,
    //         data: query,
    //         // processData: false,
    //         // contentType: false,
    //         // cache: false,
    //     })
    //         .done(function (responce) {
    //             $('#o-infoText').html(responce);
    //             console.log('ajax2');
    //         })
    //         .fail(function (xhr) {
    //             $('#boxObj').html(xhr);
    //             console.log(xhr);
    //         })
    //         .always(function (xhr, msg) {
    //             // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
    //             console.log('xhr');
    //             console.log(msg);
    //         });
    // });

    // $('#okBtnp1').on('click',function(){

    //     $.ajax({
    //         url: 'mordalBack2.php',
    //         // type: 'GET',
    //         type: 'POST',
    //         async: true,
    //         // // data: strQuery,
    //         data: query,
    //         // processData: false,
    //         // contentType: false,
    //         cache: false,
    //     })
    //         .done(function (responce) {
    //             $('#o-tipsText').html(responce);
    //             console.log('ajax3');
    //         })
    //         .fail(function (xhr) {
    //             $('#boxObj').html(xhr);
    //             console.log(xhr);
    //         })
    //         .always(function (xhr, msg) {
    //             // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
    //             console.log('xhr');
    //             console.log(msg);
    //         });
    // })


    // $('.orderBtn').on('click',function(){

    //     console.log(formId)

    //     const data = $('#moneyH1').html();
    //     const res = data.replace(/[^0-9]/g, '');

    //     console.log(res);

    //     $.ajax({
    //         url: 'drinkAnime.php',
    //         // type: 'GET',
    //         type: 'POST',
    //         async: true,
    //         // // data: strQuery,
    //         data: formData,
    //         processData: false,
    //         contentType: false,
    //     })
    //         .done(function (responce) {
    //             $('#animeScript').html(responce);
    //             console.log();
    //         })
    //         .fail(function (xhr) {
    //             // $('#boxObj').html(xhr);
    //             console.log(xhr);
    //         })
    //         .always(function (xhr, msg) {
    //             // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
    //             console.log('xhr');
    //             console.log(msg);
    //         });
    // })


    // $(document.querySelectorAll('#objA2')).on('click','#objA2',ajaxB1());

    });
});


