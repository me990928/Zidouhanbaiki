<?php

  require '../escape.php';

  require '../class/db.php';

  require '../item/itemsClass.php';

  require '../class/layoutClass.php';

  $layout = new Lay();

  // var_dump($_FILES);



  if ($_POST['snsTitle']=='' || $_POST['story']=='埋め込みコードを入力') {
    // echo "空欄";
    exit();
  }

  if(strpos($_POST['story'],'#')){
    echo "<span style='color: red;'>『＃』は使わないでね！</span>";
    exit();
  }

  $data[0] = $_POST['snsTitle'];
  $data[1] = $_POST['story'];
  // echo $rest;

  if($layout->conn() ){     // DB実行準備

      $dbConn = $layout->getDb();  // DB実行

      $layout->setSnsBox($data);

      echo "<span style='color: blue;'>登録成功</span>";

    }else{
      echo "失敗";
    }

?>