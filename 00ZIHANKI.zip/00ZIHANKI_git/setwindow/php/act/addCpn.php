<?php

  // var_dump($_POST);

  date_default_timezone_set('Asia/tokyo');

  require '../escape.php';

  if ($_POST['itemId']=="商品を選択してください" || $_POST['dis']=='') {
    echo "<script>alert('記入漏れがあります！')</script>";
  }else{

    require '../class/db.php';
    require '../item/itemsClass.php';
    require '../class/layoutClass.php';
    require '../class/infoClass.php';
    require '../class/couponClass.php';


    $cpnObj = new Cpon();

    if($cpnObj->conn()){


      // 送信後の世界
      if($_POST['efd']<$_POST['std']){
        echo "<script>alert('開始日と期限日が違います')</script>";
        exit();
      }

      $getNum = $cpnObj->getNum();
      $arg = [$_POST['itemId'],$_POST['std'],$_POST['efd'],$_POST['dis']];
      $cpnObj->createCoupon($arg);


    }

    echo "<script>alert('登録完了！')</script>";

  }

?>


