<?php

  // 在庫が0か1以上かを判断し、
  // 在庫が0ならcssで無在庫状態にする

  $id = $_POST['drinkBuy'];
  $temp = $_POST['tempBuy'];

  $res = file_get_contents('./json/zaikoList.json',false);
  $zaikoJson = json_decode($res);


  $res = file_get_contents('./json/coolList.json',false);
  $coolJson = json_decode($res);


  $res = file_get_contents('./json/hotList.json',false);
  $hotJson = json_decode($res);

  for ($i=0; $i < count($hotJson); $i++) { 
    $hotList[$i] = $zaikoJson[$hotJson[$i]];
  }

  for ($i=0; $i < count($coolJson); $i++) { 
    $coolList[$i] = $zaikoJson[$coolJson[$i]];
  }

  if ($temp>0) {
    echo "string";
    // 温かい
    // for ($i=0; $i < count($hotList); $i++) { 
    //   if ($hotList[$i][1]===$id) {
    //     exit;
    //   }
    // }

    echo "
<script>
  let targets = document.querySelectorAll('#{$id}');
  targets.classList.remove('box');
  console.log('yaaaaa!')
</script>";

  }else{
    // 冷たい飲み物
    echo "string!";
    var_dump($_POST);
    echo "string!";
    
  }

?>


