$(function(){

  $(document).ready(()=>{

            axios.post( 'textReader1.php', '', {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                console.log("onload")
                $('#res-ex').html(res.data);
            } );

  })


  $(document).ready(()=>{

            axios.post( 'textReader.php', '', {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                console.log("onload")
                $('#res-ex-1').html(res.data);
            } );

  })

})