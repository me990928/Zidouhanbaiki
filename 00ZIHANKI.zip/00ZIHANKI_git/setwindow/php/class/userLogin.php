<?php
// ログイン・ログアウト関係のクラス

  class userLogin extends Db{
      protected $loginId;
      protected $loginPass;
      public $flagA = false;
      public $flagB = false;

      public function setLoginId($arg){
        return $this->loginId = $arg;
      }

      public function setLoginPass($arg){
        return $this->loginPass = $arg;
      }

      public function findAccount($arg1,$arg2){
        $smtp = $this->db->prepare('select * from t_users where f_user_id = :id and f_user_pass = :pass');

        $arg1 = htmlspecialchars($arg1, ENT_QUOTES);
        $arg2 = htmlspecialchars($arg2, ENT_QUOTES);

        $smtp->bindParam(":id",$arg1,PDO::PARAM_STR);
        $smtp->bindParam(":pass",$arg2,PDO::PARAM_STR);

        // echo "ここ";

        if($smtp->execute()){
          $record = $smtp->fetch( PDO::FETCH_ASSOC );
          if(isset($record['f_user_id'])){
            $this->flagA = true;
            setcookie('loginFlag',$this->flagA,time()+15*60);
            // echo "認証成功";
          }else{
            $this->flagA = false;
            setcookie('loginFlag',$this->flagA,time()-15*60);
            echo "<script>
                $('#errMsg').html('認証失敗');
            </script>";
          }
        }
        // while($record = $smtp->fetch( PDO::FETCH_ASSOC )) {
          if($this->flagA==true){
            setcookie('userNum',$record['f_num'],time()+15*60,"/");
            setcookie('userId',$record['f_user_id'],time()+15*60,"/");
            setcookie('userName',$record['f_user_name'],time()+15*60,"/");
            setcookie('userBirthday',$record['f_birthday'],time()+15*60,"/");
            setcookie('userClass',$record['f_user_class_id'],time()+15*60,"/");
            setcookie('userStatus',$record['f_status_id'],time()+15*60,"/");


            if($this->flagB == true){

            echo "
              <script type='text/javascript'>
                setTimeout('link()', 0);
                function link(){
                location.href='./coupon.html';
                }
                </script>
            ";
            exit();
            
            }

            echo "
              <script type='text/javascript'>
                setTimeout('link()', 0);
                function link(){
                location.href='./setWin1.php';
                }
                </script>
            ";
            exit();
          }
        // }

      }

      public function userLogout(){
            error_reporting(0);
            setcookie('userNum',$record['f_num'],time()-1000,"/");
            setcookie('userId',$record['f_user_id'],time()-1000,"/");
            setcookie('userName',$record['f_user_name'],time()-1000,"/");
            setcookie('userBirthday',$record['f_birthday'],time()-1000,"/");
            setcookie('userClass',$record['f_user_class_id'],time()-1000,"/");
            setcookie('userStatus',$record['f_status_id'],time()-1000,"/");
            setcookie('loginFlag',$this->flagA,time()-15*60,"/");
            error_reporting(-1);
            // echo "認証解除";
      }

      public function testModule(){
        // echo 'setId: '.$this->loginId.'<br>';
        // echo 'setPass: '.$this->loginPass.'<br>';
      }
  }

?>