<style type="text/css">
  .phpZ{
    color: white;
  }
</style>

<div class="phpZ">
<?php

  // require '../setwindow/php/class/db.php';
  // require '../setwindow/php/class/layoutClass.php';

  $layObj = new Lay();

  if($layObj->conn()){

      $dbConn2 = $layObj->getDb();  // DB実行

      $data = $layObj->getLogo();

      // var_dump($data);

      if ($data[0][1]==='text') {
        $logo = $data[0][2];
      }else{
        $logo = '<img src=\'.'.$data[0][3].'\' style=\'height: 150px\'>';
      }

      // echo $logo;

  }else{
    // echo "失敗";
  }

?>

</div>