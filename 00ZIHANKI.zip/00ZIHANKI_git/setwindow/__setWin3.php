<?php
  date_default_timezone_set('Asia/tokyo');

  require './php/escape.php';




  // var_dump($_COOKIE);

  error_reporting(0);


  if($_COOKIE['userClass']!=="1" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+1);
    header('location: ./back.php');
  }

  error_reporting(-1);

  require './php/class/db.php';

  require './php/item/itemsClass.php';

  $itemObj = new Items();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

  }else{
    // echo "エラー";
  }

  $list = $itemObj->AlldispItemsId();

  // $num = $itemObj->getMaterialNum();

  // var_dump($_COOKIE);

  require_once './php/act/selectBox.php';

?>
<!DOCTYPE html>

<html lang="ja">

  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <script defer type="text/javascript" src="js/ajax.js"></script>
    <script defer type="text/javascript" src="js/ajax-logout.js"></script>
    <script defer type="text/javascript" src="js/ajax-layout.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>

  </head>

  <body>

    <main class="content">

      <div id="infoBar">
        <p class="red">
          この画面は別の小ウィンドウで表示されます
        </p>
      </div>
      
      <div id="contents">

        <!-- ロゴ用フォーム -->
        <form id="logForm" method='post' enctype="multipart/form-data"><h1>レイアウト設定</h1>
          <div class='setBox'>
            <h3>会社ロゴ（画像）：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3>
            <h3>会社ロゴ（テキスト）：<input type='text' name='logoName' id='setName' value="COMPANY" placeholder="会社ロゴを入力"></h3>
            <input type="radio" name="LogoType[]" value="pict">画像
            <input type="radio" name="LogoType[]" value="text" checked>テキスト
            <!-- <h3 class="red">↑画像の設定未実装</h3> -->
          </div>
          <div id="logFormDeback" style="margin: 30px 0;"></div>

          <section>
            <a href='#' class='btn_03' id="logBtn">SEND</a>
          </section>
        </form>

        <!-- レイアウト用フォーム -->
        <form method="post" id="layoutForm">
          <div class='setBox'>
            <h3>縦：<input type='number' id='heightBox' name="heightBox" value='1' min='1' max='99' value="" placeholder="縦"> マス</h3>
            <h3>横：<input type='number' id='widthBox' name="widthBox" value='1' min='1' max='99' placeholder="横"> マス</h3>
          </div>
          <!-- <h3 class="red">↑ここで商品を配置する数を設定します</h3> -->
          <div style="height: 30px;"></div>

          <div class='setBox'>
            <h3>配置の有無</h3>
          </div>
          <div id='boxObj'>
            ■
          </div>
          <!-- <h3 class="red">↑ここでチェックを入れたスペースに商品を配置できます</h3> -->

          <div style="height: 30px;"></div>


          <h3>配置する商品</h3>
          <div class="checkedBox" id="selectBox">
            01. <select  name='selectBox[]'>
              <option>商品を選択してください</option>
              <?php
                $num=count($list);
                for ($i=0; $i < $num; $i++) { 
                 echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
                }
                // test($list.$number);
              ?>
            </select> HOT<input type='checkbox' name='hotFlag' id='hotFlag'><br>
          </div>
          <!-- <h3 class="red">↑左から順に配置する商品の種類を選ぶ</h3> -->
          <div style="height: 30px;"></div>


          <input type="hidden" name="flag" value="form">

          <section>
            <a href='#' id="layoutBtn" class='btn_03'>SEND</a>
          </section>
          </form>

          <!-- <section><a href='../../index_0.html' class='btn_03 logOut' onclick='document.a_form.submit();'>LOGOUT</a></section> -->


          <!-- <h3 class="red logOut">ログアウトすることで自販機画面に戻ります</h3> -->

        <form method="post" id="logoutForm" style="padding-bottom: 500px;">
          <input type="hidden" id="outPram" name="logout" value="true" >
          <section><a class='btn_03' id="logoutBtn">LOGOUT</a></section>
        </form>


      <!-- デバック用 -->
      <?php

        // echo "<div style='margin-bottom: 30px;'>ここからデバック画面</div>";

        // var_dump($_COOKIE);

        // echo "<div style='margin-top: 30px;'>終了</div>";

      ?>
      <!-- デバック用 -->


      </div>
      
      <!-- <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin1.html" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin2.html" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin3.html" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin4.html" id="item4">menu</a>
          </span>
        </div>

      </div> -->

      <?php

      require 'footer.php';

      ?>

    </main>

  </body>
</html>