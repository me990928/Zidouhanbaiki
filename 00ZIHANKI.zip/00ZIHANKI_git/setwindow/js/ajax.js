$(function () {
    $('#loginBtn').on('click', function () {

        // GET
        // var strQuery = $('#fr_in').serialize();

        // POST
        var formData = new FormData();
        formData.append('id', $('#userId').val());
        formData.append('pass', $('#userPass').val());
        formData.append('login', $('#loginInput').val());

        console.log('formData');

        $.ajax({
            url: './php/act/loginact.php',
            // type: 'GET',
            type: 'POST',
            datatype: 'json',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#contents').after(responce);
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});

