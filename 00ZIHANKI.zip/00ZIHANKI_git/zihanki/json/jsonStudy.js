async function getMembers() {
  const response = await fetch(
    "http://127.0.0.1/00ZIHANKI/zihanki/json/coolList.json"  // jsonファイルの場所
  );
  const members = await response.json();
  // console.log(members);
  return members;
}

//  リストアップするmember
  async function listMembers(){
    const members = await getMembers();
    // members.forEach(addList);
  }

  let data = window.addEventListener("load", listMembers);

  console.log(members)

