<?php
  date_default_timezone_set('Asia/tokyo');
  require './php/escape.php';

?>

<!DOCTYPE html>

<html lang="ja">

  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <script defer type="text/javascript" src="js/ajax.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>

    ?>

    <script type="text/javascript">
      function sample1() {
        document.fr_in.action="./php/act/loginact.php";
        document.fr_in.method="post";
        document.fr_in.submit();
      }
    </script>

  </head>

  <body>

    <main class="content">

      <div id="infoBar">
        <p class="black">
          <?= date("Y-m-d") ?>
        </p>
      </div>
      
      <div id="contents">

        <form method='post' action='#' name="fr_in">
          <h1>管理者ログイン画面</h1>
          <h3>
            USERID：<input type="text" name="id" placeholder="ID" value="yuya" id="userId"><br>
            PASSWORD：<input type="text" name="pass" placeholder="PASS" value="yuya" id = "userPass">
            <input type="hidden" name="login" value="1" id="loginInput">
          </h3>
          <div class="red" id="errMsg" style="height: 2rem;"></div>
          <!-- <section><a href='#' class='btn_03' onclick='sample1()'>LOGIN</a></section> -->
          <section id="loginBtn"><a href='#' class='btn_03'>LOGIN</a></section>
        </form>

          <!-- <h3 class="red">↑ログイン画面です<br>この設定画面では自販機のレイアウトや商品に関する設定を変更することができます<br>下のバーは左から順に「商品追加」「商品情報設定」「レイアウト設定」「SNS・COUPONの設定」の項目に移動できます</h3> -->

          <!-- デバック用 -->

          <?php

            // var_dump($_COOKIE['errorClass']);

                // var_dump($_COOKIE);

                // echo $_COOKIE['errorClass'];

                // ↓消したらあかんやつ

                if (isset($_COOKIE['errorClass'])) {
                    echo "
                      <script>$('#errMsg').html('ログイン権限がありません')</script>
                    ";
                      
                }
          ?>

          <!-- デバック用 -->

          <!-- <script type="text/javascript">$('#errMsg').html("$_COOKIE['errorClass']")</script> -->

      </div>
      
      <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="#" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="#" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="#" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="#" id="item4">menu</a>
          </span>
        </div>

      </div>

    </main>

  </body>
</html>

<?php

?>