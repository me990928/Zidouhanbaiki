<?php
  require '../escape.php';

  error_reporting(0);


  if($_COOKIE['userClass']=="2" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+10,'/');
    header('location: ../user/loginPage.php');
  }

  error_reporting(-1);

  require './db_stock_register_class.php';

  var_dump($_POST);

  $stockObj = new Stock();

  if($stockObj->conn()){     // DB実行準備

    $dbConn = $stockObj->getDb();  // DB実行

    echo "成功";

    $arg[0] = $_POST['itemId'];
    $arg[1] = $_POST['time'];
    $arg[2] = $_POST['temp'];
    $arg[3] = $_COOKIE['userName'];

    $e = $_POST['stock'];

    for ($i=0; $i < $e; $i++) { 
      $stockObj->stockRegister($arg);
    }

    header('location: ./add_stock_form.php');

  }else{
    echo "エラー";
  }

?>