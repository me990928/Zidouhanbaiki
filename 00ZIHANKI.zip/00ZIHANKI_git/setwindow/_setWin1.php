<!DOCTYPE html>

<html lang="ja">

  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <script defer type="text/javascript" src="js/ajax-logout.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>

  </head>

  <body>

    <main class="content">

      <div id="infoBar">
        <p class="red">
          この画面は別の小ウィンドウで表示されます
        </p>
      </div>
      
      <div id="contents">

        <form method='get' action='#'>
          <h1>商品追加</h1><h3>商品名</h3><input type='text' name='itemName' placeholder="商品名"><br>
          <h3>販売価格</h3><input type='text' name='itemCost' placeholder="商品価格"><br>
          <h3>商品情報：<input type='checkbox' name=''>有効にする</h3><textarea rows='10' cols='35' placeholder="商品情報を入力してください"></textarea>
          <h3>お役立ち情報：<input type='checkbox' name=''>有効にする</h3><textarea rows='10' cols='35' placeholder="お役立ち情報を入力してください"></textarea><br>
          
          <h3 class="red">↑追加する商品の設定をする画面です</h3>

          <h1>素材使用アニメーション</h1>
          <h3>アニメーションを有効にする：<input type='checkbox' name='' checked></h3>
          <h3>材料A：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3>
          <h3>材料B：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3>

          <h3 class="red">↑アニメーションを有効にすると、容器に材料Aと材料B入れるアニメーションが商品購入後に再生されます。</h3>

          <section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section>
        </form>
        <form method="post" id="logoutForm">
          <input type="hidden" id="outPram" name="logout" value="true" >
          <section><a class='btn_03' id="logoutBtn">LOGOUT</a></section>
        </form>
          <!-- <section><a href='../../index_0.html' class='btn_03' onclick='document.a_form.submit();' id="logoutBtn">LOGOUT</a></section> -->
          <h3 class="red logOut">ログアウトすることで自販機画面に戻ります</h3>

      </div>
      
      <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin1.html" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin2.html" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin3.html" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin4.html" id="item4">menu</a>
          </span>
        </div>

      </div>

    </main>

  </body>
</html>