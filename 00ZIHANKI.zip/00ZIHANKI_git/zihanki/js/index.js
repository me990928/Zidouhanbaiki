$(function(){

    $('.select-zun').on('click',()=>{
      $('.mordal-ex').removeClass('mordal-off');
      $('.mordal-back').removeClass('yukkuri-off');
      $('.mordal-ex').addClass('mordal-on');
      $('.mordal-ex').addClass('mordal-on');
      $('.mordal-back').removeClass('mordal-off');
      $('.mordal-back').addClass('mordal-on');
    })
    // モーダル閉じる
    $('.btn-ex-close').on('click',function(){
       // $('.mordal-back').stop().fadeToggle(1000);
      $('.mordal-back').removeClass('mordal-on');
      $('.mordal-back').addClass('mordal-off');
      $('.mordal-back').addClass('yukkuri-off');
      $('.mordal-ex').removeClass('mordal-on');
      $('.mordal-ex').addClass('mordal-off');
      $('#buy-win').removeClass('buy-win-on');
      $('#buy-win').addClass('buy-win-off');

      // $(Object).html('');
    })

    $('.select-not').on('click',()=>{
      $('.mordal-ex-1').removeClass('mordal-off');
      $('.mordal-back').removeClass('yukkuri-off');
      $('.mordal-ex-1').addClass('mordal-on');
      $('.mordal-ex-1').addClass('mordal-on');
      $('.mordal-back').removeClass('mordal-off');
      $('.mordal-back').addClass('mordal-on');
    })
    // モーダル閉じる
    $('.btn-ex-close').on('click',function(){
       // $('.mordal-back').stop().fadeToggle(1000);
      $('.mordal-back').removeClass('mordal-on');
      $('.mordal-back').addClass('mordal-off');
      $('.mordal-back').addClass('yukkuri-off');
      $('.mordal-ex-1').removeClass('mordal-on');
      $('.mordal-ex-1').addClass('mordal-off');
      $('#buy-win').removeClass('buy-win-on');
      $('#buy-win').addClass('buy-win-off');

      // $(Object).html('');
    })
    let money = 0;
    let b_money = 0;
    let flag = 0;

    // function sumDisp() {
    //   if(money.toString().length>4){
    //     alert('投入金額いっぱいです')
    //     money = money - flag
    //   }
    //   if (money.toString().length<4) {
    //     let sp = '&nbsp;';
    //     $('#moneyH1').html('投入金額：'+sp+money+'円');
    //   if (money.toString().length<3) {
    //     let sp = '　';
    //     $('#moneyH1').html('投入金額：'+sp+money+'円');
    //   }}else{
    //     $('#moneyH1').html('投入金額：'+money+'円');
    //   }

    // }

    function animeNum(e,b_money,sp){
      var logEl = document.getElementById('moneyH1');

      console.log(b_money);

      var price = {
        金額: b_money
      }

      anime({
        targets: price,
        金額: e,
        round: 1,
        duration: 900,
        easing: 'linear',
        update: function() {
          logEl.innerHTML = price.金額 + '円';
        }
      });
    }

    function sumDisp(b_money) {
      if(money.toString().length>4){
        alert('投入金額いっぱいです')
        money = money - flag
      }
      if (money.toString().length<4) {
        let sp = '&nbsp;';
        console.log('やあ')
        animeNum(money,b_money,sp);

      if (money.toString().length<3) {
        let sp = '　';
        animeNum(money,b_money,sp);
      }}else{
        let sp = '';
        animeNum(money,b_money,sp);
      }

    }

    $('#tenBtn').on('click',function(){
      b_money = money;
      money = money + 10;
      console.log('¥'+money);
      flag = 10;
      sumDisp(b_money)
    });

    $('#fifBtn').on('click',function(){
      b_money = money;
      money = money + 50;
      console.log('¥'+money);
      flag = 50;
      sumDisp(b_money)
    });

    $('#onehBtn').on('click',function(){
      b_money = money;
      money = money + 100;
      console.log('¥'+money);
      flag = 100;
      sumDisp(b_money)
    });

    $('#thouBtn').on('click',function(){
      b_money = money;
      money = money + 1000;
      console.log('¥'+money);
      flag = 1000;
      sumDisp(b_money)
    });

    $('#sumBtn').on('click',function(){
      console.log('¥'+money);
      alert('合計金額は'+money+'円です');
    });

    $('#resetBtn').on('click',function(){
      b_money = money;
      money = 0;
      console.log('¥'+money);
      alert('金額をリセットしました')
      sumDisp(b_money)
    });

    // 購入
    $('.orderBtn').on('click',function(){
      let p = $('#priceOrder').text();
      console.log('価格は'+p+'円');
      Number(p);
      if(money-p>=0){

        let query = $('#buyForm').serialize();
        let query2 = $('#buy').serialize();

            let params = {
                0: query,
                1: query2
            }

        axios.post('cpnActor.php',params)
        .then((res)=>{

          console.log(res)
          $('#debag').html(res.data);

        $.getJSON("./json/priceFlag.json", function(data){
          if(data['0']==1){
            b_money = money;
            money = money - p;
            alert('購入完了しました。');
            sumDisp(b_money)
          }else if(data['0']==2){
            if(data['1']==false){
              return;
            }
            b_money = money;
            money = money - data['2'];
            alert('購入完了しました。');
            sumDisp(b_money)
          }
        });

        })

        
        axios.post('resetJson.php')
        .then((res)=>{
          console.log('end')
          $('#debag').html(res.data);
        })


      $('.mordal-back').removeClass('mordal-on');
      $('.mordal-back').addClass('mordal-off');
      $('.mordal-back').addClass('yukkuri-off');
      $('#mordal-p2').removeClass('mordal-on');
      $('#mordal-p2').addClass('mordal-off');
      $('#buy-win').removeClass('buy-win-on');
      $('#buy-win').addClass('buy-win-off');

      // 在庫処理

      let Id = 'buyForm';
      let dBuy = document.getElementById('drinkBuy').value;
      let tBuy = document.getElementById('tempBuy').value;
      
      $.post('zaikoBack.php',$('#buyForm').serialize())
      .done(function( res ) {
     
        console.log( res );

        $('#inputBox').html();

      })

      imgId = null;

      // $.post('zikoBack3.php',null)
      // .done((res)=>{
      //   $('#inputBox').html(res);
      // })

      axios.post( 'zikoBack3.php', null, {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                console.log(res)
                $('#inputBox').html(res.data);
            } );

      axios.post( 'classNot.php', null, {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                console.log(res)
                $('#inputBox').html(res.data);
            } );

    console.log(imgId)

      }else{
        alert('投入金額が足りませんでした');
      }
    });

    // モーダル切り替え
    $('.box').on('click',function(){
      if($(this).hasClass('select-zun')){
        return
      }
      if(!($(this).hasClass('boxnot'))){
      $('#mordal-p1').removeClass('mordal-off');
      $('.mordal-back').removeClass('yukkuri-off');
      $('#mordal-p1').addClass('mordal-on');
      $('#mordal-p1').addClass('mordal-on');
      $('.mordal-back').removeClass('mordal-off');
      $('.mordal-back').addClass('mordal-on');
      // $(Object).html('');
      }
    })

    // モーダル切り替え2
    $('#okBtnp1').on('click',function(){
      $('#mordal-p1').removeClass('mordal-on');
      $('#mordal-p1').addClass('mordal-off');
      $('#mordal-p2').removeClass('mordal-off');
      $('#mordal-p2').addClass('mordal-on');
      // $(Object).html('');
    })

    // モーダル切り替え2
    $('#okBtnp2').on('click',function(){
      $('#mordal-p2').removeClass('mordal-on');
      $('#mordal-p2').addClass('mordal-off');
      $('#buy-win').removeClass('buy-win-off');
      $('#buy-win').addClass('buy-win-on');
      // $(Object).html('');
    })

    // モーダル閉じる
    $('.btn-n').on('click',function(){
       // $('.mordal-back').stop().fadeToggle(1000);
      $('.mordal-back').removeClass('mordal-on');
      $('.mordal-back').addClass('mordal-off');
      $('.mordal-back').addClass('yukkuri-off');
      $('#mordal-p2').removeClass('mordal-on');
      $('#mordal-p2').addClass('mordal-off');
      $('#buy-win').removeClass('buy-win-on');
      $('#buy-win').addClass('buy-win-off');

      // $(Object).html('');
    })

    $('.cansel').on('click',()=>{

      $('#wall').css('width','100vw')
      $('#wall').css('height','100vh')

      window.setTimeout(()=>{
        location.reload(true);
      },1100)
    })

   $('.box').on('click',function(){

    if($(this).hasClass('select-not')){
      return;
    }
    if($(this).hasClass('select-zun')){
      return;
    }

    var imgId = null;
    imgId = $(this,'box').children().children().next().attr('id'); 

    $('.orderBtn').on('click',function(){

      let p = $('#priceOrder').text();
      console.log('価格は'+p+'円');
      Number(p);
    if(money-p>=0){

      // $('.box').css('pointer-events', 'none');

    // $.post( 'drinkAnime.php', 'name='+imgId )
 
    // .done(function( res ) {
     
    //     console.log( res );

    //     $('#animeScript').html(res);
    //     $('#animeScript').html("");

    // })

    var params = {
        0: imgId
    }

    axios.post( 'drinkAnime.php', params, {
      'Cache-Control': 'no-cache'
    } )
    .then( ( res ) => {
        // console.log(res)
        $('#animeScript').html();
        $('#animeScript').html(res.data);
    } );

    imgId = null;

    console.log(imgId);

  }else{
    imgId = null;
  }

    })


   });


});





$(function(){
  function timer_func(){

    $('.mordal-back').removeClass('mordal-off');
    $('.mordal-back').addClass('mordal-on');

    $('#mordal-cm').removeClass('mordal-off');
    $('#mordal-cm').addClass('mordal-on');

    let ev = Math.floor(Math.random() * ((2 + 1) - 1)) + 1;

    if(ev==1){
      axios.post( 'makingRanking.php', {
        'Cache-Control': 'no-cache'
      } )
      .then( ( res ) => {
          $('#cm-win').html(res.data);
      } );
    // alert(ev)
    }
    if(ev==2){

      let evf = Math.floor(Math.random() * ((5 + 1) - 1)) + 1;


      $('#cm-win').html("<img src='sozai/"+evf+"/cm.jpg' style='width: 800px;'>");
    }

  }

  var time_limit=1000 * 10 *60; //制限時間
  var timer_id=setTimeout(timer_func, time_limit);

  let flag = 1;

  //拾うイベントは追加・調整もできます
  $('body').on('keydown mousedown click',function(){
    clearTimeout(timer_id);
    timer_id=setTimeout(timer_func, time_limit);
    // alert('a')
  });

  $("#resetBtn").on('click',timer_func);

});


$(function(){
    $('#mordal-cm').on('click',function(){

      $('.mordal-back').removeClass('mordal-on');
      $('.mordal-back').addClass('mordal-off');
      $('.mordal-back').addClass('yukkuri-off');
      $('#mordal-cm').removeClass('mordal-on');
      $('#mordal-cm').addClass('mordal-off');
      $('#mordal-cm').addClass('yukkuri-off');


      window.setTimeout(()=>{
        location.reload(true);
      },1100)

  })

setInterval(function(){
    var y = new Date().getFullYear();
    var m = new Date().getMonth() + 1;
    var d = new Date().getDate();
    var w = new Date().getDay();
    var wd = ["日","月","火","水","木","金","土"];
    var youbi = wd[w];
    var h = new Date().getHours().toString().padStart(2, '0');;
    var min = new Date().getMinutes().toString().padStart(2, '0');
    var s = new Date().getSeconds().toString().padStart(2, '0');
    $("#time").html(y + "年" + m + "月" + d + "日" + "<br>" + h + ":" + min + ":" + s);
  },1000);
})
