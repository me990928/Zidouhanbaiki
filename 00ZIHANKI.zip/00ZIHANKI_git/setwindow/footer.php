<?php

  echo "

    <div id='menuBar'>

        <div class='itemBox selector'>
          <span class='material-symbols-outlined'>
            <a href='setWin1.php' id='item1'>add</a>
          </span>
        </div>

        <div class='itemBox selector'>
          <span class='material-symbols-outlined'>
            <a href='setWin2.php' id='item2'>edit_square</a>
          </span>
        </div>

        <div class='itemBox selector'>
          <span class='material-symbols-outlined'>
            <a href='setWin3.php' id='item3'>grid_on</a>
          </span>
        </div>


        <div class='itemBox selector'>
          <span class='material-symbols-outlined'>
            <a href='setWin4.php' id='item4'>menu</a>
          </span>
        </div>

      </div>

  ";

?>