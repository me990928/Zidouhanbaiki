<style type="text/css">
  table{
    margin: 15px;
  }

  td{
    padding: 5px;
    text-align: center;
    vertical-align: middle;
  }

  main{
    display: flex;
  }

</style>

<button onclick="location.href='../user/userOption_page0.php'">Options</button><br>

<main>

<?php

error_reporting(0);
  require '../escape.php';


  if($_COOKIE['userClass']=="2" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+10,'/');
    header('location: ../user/loginPage.php');
  }

  error_reporting(-1);

  require './db_stock_register_class.php';

  $stockObj = new Stock();

  if($stockObj->conn()){     // DB実行準備

    $dbConn = $stockObj->getDb();  // DB実行

    // var_dump($stockObj);     // デバック用

    // echo "成功";

    $list = $stockObj->getStockList();
    $counter = $stockObj->getStocCounter();

    $mode = "c";
    echo $stockObj->creatTable($counter,$mode);

    $mode = "l";
    echo $stockObj->creatTable($list,$mode);


  }else{
    echo "エラー";
  }


?>

</main>