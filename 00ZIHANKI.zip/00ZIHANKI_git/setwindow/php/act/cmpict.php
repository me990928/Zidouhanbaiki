<?php

  // var_dump($_POST);
  // var_dump($_FILES);
  //ファイルの保存先
  $upload = '../../../zihanki/sozai/'.$_POST['num'].'/cm.jpg'; 
  //アップロードが正しく完了したかチェック
  if(move_uploaded_file($_FILES['file']['tmp_name'], $upload) && $_FILES['file']['type']=="image/jpeg"){
    echo "<script>
                alert('登録完了');</script>";
  }else{
    echo 'アップロード失敗'; 
  }

?>