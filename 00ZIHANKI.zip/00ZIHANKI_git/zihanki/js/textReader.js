let reader = new FileReader();

let pass = "../setwindow/php/sys/text/stock.txt";

console.log(reader)

// reader.readAsText(pass);

// console.log(reader.result)