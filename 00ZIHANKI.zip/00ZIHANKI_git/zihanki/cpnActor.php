<?php

  $price[0][0]=0;

  
  $request_body = file_get_contents('php://input'); //送信されてきたbodyを取得(JSON形式）
  $jsondata = json_decode($request_body,true); // デコード

  $data1 = explode('&',$jsondata[0]);
  $buy1 = explode('&',$jsondata[1]);

  $i = 0;
  foreach ($data1 as $val) {
    $data2[$i] = explode('=',$val);
    $i++;
  }

  $i = 0;
  foreach ($buy1 as $val) {
    $buy2[$i] = explode('=',$val);
    $i++;
  }

  // var_dump($data2);

  $price_json = file_get_contents('./json/priceFlag.json');
  $jsondataprice = json_decode($price_json,true);
  // var_dump($jsondataprice);

  //$buy2
  //[0][0]:kessaiselector
  //[0][1]:number
  //[1][0]:couponCode
  //[1][1]:Code

  // $data2
  //[0][0]:itemId
  //[0][1]:ID
  //[1][0]:itemTemp
  //[1][1]:Temp


  // error_reporting(0);
  require '../setwindow/php/escape.php';
  require '../setwindow/php/class/db.php';
  require '../setwindow/php/item/itemsClass.php';
  require '../axios/infoClass.php';
  require '../setwindow/php/class/couponClass.php';

  // タイムゾーン設定
  date_default_timezone_set('Asia/tokyo');

  $cpnObj = new Cpon();
  

  if($buy2[1][1]!==""){

      if($cpnObj->conn()){     // DB実行準備

        unset($data);    

        $dbConn = $cpnObj->getDb();  // DB実行


        if($MatchRes = $cpnObj->codeMatch($buy2[1][1])){}else{

      $jsondataprice[0] = 2;
      $jsondataprice[1] = false;

      $json = json_encode($jsondataprice);
      $bytes = file_put_contents("./json/priceFlag.json", $json);
          exit;
        };

        if($cpnInfo = $cpnObj->cpnInfo($MatchRes[0][3])){}else{

      $jsondataprice[0] = 2;
      $jsondataprice[1] = false;

      $json = json_encode($jsondataprice);
      $bytes = file_put_contents("./json/priceFlag.json", $json);
          exit;
        } // [0][4]->値引き額

        if($price = $cpnObj->getPrice($MatchRes[0][2])){}else{

      $jsondataprice[0] = 2;
      $jsondataprice[1] = false;

      $json = json_encode($jsondataprice);
      $bytes = file_put_contents("./json/priceFlag.json", $json);
          exit;
        }  // [0][0]->価格

    }else{
      echo"error";
    }

    // 商品チェック
    if($data2[0][1]==$MatchRes[0][2]){
      // echo "同じ！";
    }else{
      echo "<script>alert('クーポンが間違っています')</script>";
      exit;

      $jsondataprice[0] = 2;
      $jsondataprice[1] = false;

      $json = json_encode($jsondataprice);
      $bytes = file_put_contents("./json/priceFlag.json", $json);
    }

    // クーポン対象チェック：期間、対象商品
    if(date('Y-m-d')>$cpnInfo[0][2] && date('Y-m-d')<$cpnInfo[0][3]){
    }else{
      echo "<script>alert('期限外です')</script>";
      exit;

      $jsondataprice[0] = 2;
      $jsondataprice[1] = false;

      $json = json_encode($jsondataprice);
      $bytes = file_put_contents("./json/priceFlag.json", $json);
    }

    $jsondataprice[0] = 2;
    $jsondataprice[1] = true;

    $jsondataprice[2] = $price[0][0] - $cpnInfo[0][4];


    $json = json_encode($jsondataprice);
    $bytes = file_put_contents("./json/priceFlag.json", $json); 


  }else{

    $jsondataprice[0] = 1;

    $jsondataprice[1] = true;

    $jsondataprice[2] = $price[0][0];



    $json = json_encode($jsondataprice);
    $bytes = file_put_contents("./json/priceFlag.json", $json); 

  }

  unset($arg);
  $arg[0] = $data2[0][1];
  if(isset($MatchRes[0][3])){
  $arg[1] = $MatchRes[0][3];
  }else{
    $arg[1] = "-";
  }

  $cpnObj->conn();

  $dbConn = $cpnObj->getDb();

  $cpnObj->setBuylog($arg);

?>