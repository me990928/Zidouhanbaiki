<?php
// Db接続クラス

class Db{
  // カプセル化群
  protected $userid;
  protected $pass,$host,$dbname,$port,$dsn;
  protected $db;

  // コンストラクタ
  function __construct($id="root",$pass="root",$host="localhost",$dbname="zihankisys",$port="3306"){
    $this->userid = $id;
    $this->pass = $pass;
    $this->host = $host;
    $this->dbname = $dbname;
    $this->dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8;port={$this->port}";
  }

  // ゲッター＆セッター
  public function getUserid(){
    return $this->userid;
  }
  public function getPass(){
    return $this->pass;
  }
  // public function setUserid($arg){
  //   $userid = $arg;
  // }

  // ID再設定用
  public function setUserid($arg){
    return $this->userid = $arg;
  }
  // パスワード再設定用
  public function setPass($arg){
    return $this->pass = $arg;
  }
  // ポート再設定用
  public function setPort($arg){
    return $this->port = $arg;
  }

  function conn(){
    $flag = true;

    try {
      $this->db = new PDO($this->dsn,$this->userid,$this->pass);    
    } catch (PODException $e) {
      $flag = false;
      print "接続エラー".$e->getMessage();
    }
    return $flag;
  }

  function getDb(){
    return $this->db;
  }

  

  // 登録機能
  public function setINSERTmethod($arg){

    $smtp = $this->db->prepare("insert into t_users(f_user_id,f_user_name,f_user_pass,f_birthday,f_user_class_id,f_status_id) values(:id,:name,:pass,:date,:class,'1')");

    array_walk($arg, function(&$val, $index) {
        $val = htmlspecialchars($val, ENT_QUOTES);
      });

    $adms = "";

    $strId = $arg[0];
    $strName = $arg[1];
    $strPass = $arg[2];
    $serBirth = $arg[3];
    $intClass = $arg[4];

    $smtp->bindParam(":id",$strId,PDO::PARAM_STR);
    $smtp->bindParam(":name",$strName,PDO::PARAM_STR);
    $smtp->bindParam(":pass",$strPass,PDO::PARAM_STR);
    $smtp->bindParam(":date",$serBirth,PDO::PARAM_STR);

    // admin登録処理
    if($intClass==="1"){
      error_reporting(0);
      if ($_COOKIE['userClass']=="0") {
        $adms = "admin regist ";
      }else{
        echo "masterに切り替えてください";
        die();
      }
      error_reporting(-1);
    }
    $smtp->bindParam(":class",$intClass ,PDO::PARAM_INT);

    $smtp->execute();

    echo $adms."success";
  }

  // 更新機能
  public function setUPDATEmethod($arg){
    // cookieからIDとユーザ名を取得
    // それらを条件にUPDATEを行う
    // ifで対応する列の添字の配列の中身を探り
    // 中身があればUPDATEを行う
    // DELETEも同じ原理で行う

    if($arg[1]==1){
      $stmt = $this->db->prepare('update t_users set f_user_id = :newUserId where f_user_id = :userId and f_user_name = :userName');

      $newUserId = $arg[0];

      $stmt->bindParam(":newUserId",$newUserId,PDO::PARAM_STR);

      echo "stringA";
    }elseif($arg[1]==0){
      $stmt = $this->db->prepare('update t_users set f_user_name = :newUserName where f_user_id = :userId and f_user_name = :userName');

      $newUserName = $arg[0];

      $stmt->bindParam(":newUserName",$newUserName,PDO::PARAM_STR);

      echo "stringB";

    }elseif($arg[1]==2){
      $stmt = $this->db->prepare('update t_users set f_user_name = :newUserName , f_user_id = :newUserId where f_user_id = :userId and f_user_name = :userName');

      $newUserId = $arg[0];
      $newUserName = $arg[2];

      $stmt->bindParam(":newUserId",$newUserId,PDO::PARAM_STR);
      $stmt->bindParam(":newUserName",$newUserName,PDO::PARAM_STR);

      echo "stringC";


    }

      $userId = $_COOKIE['userId'];
      $userName = $_COOKIE['userName'];

      $stmt->bindParam(":userId",$userId,PDO::PARAM_STR);
      $stmt->bindParam(":userName",$userName,PDO::PARAM_STR);

      var_dump($arg);

      $stmt->execute();

  }

  // 削除機能
  public function setDELETEmethod($arg){
    echo "<br>";
    var_dump($arg);   
    echo "<br>";   

    $stmt = $this->db->prepare('delete from t_users where f_user_id = :Id and f_user_name = :name');

    $userId = $arg[0];
    $userName = $arg[1];

    $stmt->bindParam(":Id",$userId,PDO::PARAM_STR);
    $stmt->bindParam(":name",$userName,PDO::PARAM_STR);

    $stmt->execute();
  }
}

?>