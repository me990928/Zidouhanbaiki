<?php

  class Lay extends Db {

    // 商品セット
    public function setItems($arg,$br,$sum){
      error_reporting(0);

      $cnt = 1;
      $cntLast = 1;

      $stmt = $this->db->query('delete from t_layouts');

      unset($stmt);

      for ($i=0; $i <= count($arg)-1; $i++) { 
        $stmt = $this->db->prepare('insert into t_layouts (f_position_num, f_item_id) values(:num, :id)');

        $ext = explode('-',$arg[$i]);

        // print($ext[0]);

        $num = $i+1;
        $id= $ext[0];

        $stmt->bindParam(":num",$num,PDO::PARAM_STR);
        $stmt->bindParam(":id",$id,PDO::PARAM_STR);

        $stmt->execute();

        
        if ($br == $cnt && $sum !== $cntLast) {
          $stmt = $this->db->query("insert into t_layouts (f_position_num, f_item_id) values('br','-')");
          $cnt = 0;
        }

        $cnt++;
        $cntLast++;

        // echo $i+1;
        echo $sum !== $i+1;

      }

      error_reporting(-1);

    }

    public function setPict($upFile){

      if(is_uploaded_file($upFile['tmp_name'])){
        $file = glob('./logoPict/*');
        $cnt = count($file);
        for ($i=0; $i < $cnt; $i++) {
          unlink($file[$i]);
        }

        // echo "存在確認ヨシ！";

        if (move_uploaded_file($upFile['tmp_name'],'./logoPict/'.$upFile['name'])) {
          // echo "アップロード完了！";

          return true;
        }

      }

    }

    // 会社ロゴ設定
    public function setLog($arg){
      // var_dump($arg);

      $stmt = $this->db->query('delete from t_company_logos');

      // ロゴタイプ
      $stmt = $this->db->prepare('insert into t_company_logos (f_company_logo_id,f_logo_type,f_logo_title,f_logo_pict_key) values(:id,:type,:title,:key)');
      
      $id = 1;
      $type = $arg[0];
      $title = $arg[1];
      $key = $arg[2];

      $stmt->bindParam(":id",$id,PDO::PARAM_INT);
      $stmt->bindParam(":type",$type,PDO::PARAM_STR);
      $stmt->bindParam(":title",$title,PDO::PARAM_STR);
      $stmt->bindParam(":key",$key,PDO::PARAM_STR);

      $stmt->execute();

    }

    public function getLogo(){
      $stmt = $this->db->query('select * from t_company_logos');
      $data = $stmt->fetchAll(PDO::FETCH_NUM);

      return $data;
    }

    // COUPONBOX設定

    public function getQR(){
      $stmt = $this->db->query('select * from t_coupon_setting_boxes');
      $data = $stmt->fetchAll(PDO::FETCH_NUM);

      return $data;
    }

      public function setCpnPict($upFile){

      if(is_uploaded_file($upFile['tmp_name'])){
        $file = glob('./cpnPict/*');
        $cnt = count($file);
        for ($i=0; $i < $cnt; $i++) {
          unlink($file[$i]);
        }

        // echo "存在確認ヨシ！";

        if (move_uploaded_file($upFile['tmp_name'],'./cpnPict/'.$upFile['name'])) {
          // echo "アップロード完了！";

          return true;
        }

      }

    }

    public function setCpnBox($arg){
      $stmt = $this->db->query('delete from t_coupon_setting_boxes');
      // $a = $this->db->query('select * from t_coupon_setting_boxes');

      // var_dump($arg);


      $stmt = $this->db->prepare('insert into t_coupon_setting_boxes (f_coupon_setting_box_id,f_title,f_qr_pict_key,f_status_id) values(:id,:title,:key,:stat)');

      $id = 1;
      $title = $arg[0];
      $key = $arg[1];
      $stat = 1;

      $stmt->bindParam(":id",$id,PDO::PARAM_INT);
      $stmt->bindParam(":title",$title,PDO::PARAM_STR);
      $stmt->bindParam(":key",$key,PDO::PARAM_STR);
      $stmt->bindParam(":stat",$stat,PDO::PARAM_INT);

      $stmt->execute();


    }

     public function setSnsBox($arg){
          $stmt = $this->db->query('delete from t_sns_setting_boxes');

          $stmt = $this->db->prepare('insert into t_sns_setting_boxes (f_sns_setting_box_id,f_title,f_embedding_word_key,f_status_id) values(:id,:title,:key,:stat)');

          $id = 1;
          $title = $arg[0];
          $key = $arg[1];
          $stat = 1;

          $stmt->bindParam(":id",$id,PDO::PARAM_INT);
          $stmt->bindParam(":title",$title,PDO::PARAM_STR);
          $stmt->bindParam(":key",$key,PDO::PARAM_STR);
          $stmt->bindParam(":stat",$stat,PDO::PARAM_INT);

          $stmt->execute();


        }


    public function getSNS(){
      $stmt = $this->db->query('select * from t_sns_setting_boxes');
      $data = $stmt->fetchAll(PDO::FETCH_NUM);

      return $data;
    }

      public function setTemp($data,$arg){
        echo "<br>ここからclass<br>";

        $num = count($arg);

        echo "i:".$num."/";

        for ($i=0; $i < $num; $i++) { 

          $stmt = $this->db->prepare("update t_layouts set f_layout_temp = 1 where f_position_num = :num");

          $stmt->bindParam(":num",$arg[$i],PDO::PARAM_STR);

          $stmt->execute();

          // echo "$num1";

        }
      }

      // ポジション取得
      public function getLay(){
        $stmt = $this->db->query("select * from t_layouts where f_position_num != 'br'");
        $data = $stmt->fetchAll(PDO::FETCH_NUM);

        return $data;
      }

      // 在庫データ取得
      public function getZai($arg){
        $stmt = $this->db->query("select * from t_items_stocks where f_item_id = '$arg'");
        $data = $stmt->fetchAll(PDO::FETCH_NUM);

        return $data;
      }

      // 同時導入在庫時間取得
      public function getAllZai($arg){
        $stmt = $this->db->query("select * from t_items_stocks where f_item_id = '$arg'");
        $data = $stmt->fetchAll(PDO::FETCH_NUM);
        return $data;
      }

      public function FncFindBuy($resNum,$List,$drinkName){
        // 消費在庫を参照し、IDが一番若いものを取得する
        for ($i=0; $i < count($resNum); $i++) {
          if ($List[$resNum[$i]][1]===$drinkName) {
            // echo 'お買い上げ'.$List[$resNum[$i]][0].'<br>';
            return $List[$resNum[$i]][0];
          }
        }
      }

      public function setDelZai($arg){
        $stmt = $this->db->query("delete from t_items_stocks where f_item_stock_id = $arg");
      }
  }

 



?>