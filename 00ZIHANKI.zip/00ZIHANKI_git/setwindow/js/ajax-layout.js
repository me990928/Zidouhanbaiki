$(function () {
    $('#layoutBtn').on('click', function () {

        // POST
        let $form = $('#layoutForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/layoutAct.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#contents').after(responce);
                // $('#contents').html(responce);
                console.log('a')
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });


    $('input#heightBox, input#widthBox').on('change', function () {

        // POST

        let flag = 'selected';
        // var formData = new FormData($form.get(0));
        var formData = new FormData();
        formData.append('height', $('#heightBox').val());
        formData.append('width', $('#widthBox').val());
        formData.append('flag', flag);

        console.log('formData');

        $('#selectBox').empty();

        $.ajax({
            url: './php/act/layoutAct.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            datatype: 'text',
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#selectBox').append(responce);
                // alert('登録完了');

            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });


    $('#logBtn').on('click', function () {

        // POST
        let $form = $('#logForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/logosAct.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#logFormDeback').html(responce);
                console.log('a')
                // var ary = responce.split('<br>');
                alert('登録完了');

            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });

    
});