<?php
  error_reporting(0);
  require '../escape.php';

  require 'db_get_info_class.php';

  $test = new Info();

  if($test->conn()){     // DB実行準備

    unset($data);    

    $dbConn = $test->getDb();  // DB実行

    // var_dump($test);     // デバック用

    echo "成功";

    $arg[0]=$_POST['itemId'];

    $test->getInfo($arg);

    $data = $test->outItemData();

    print_r($data);

    // error_reporting(-1);

    $list = $test->AlldispItemsId();

  }else{
    echo "エラー";
  }

?>

<style type="text/css">
  td{
    padding: 10px;
  }
</style>

<form method="post">

      Select item : <select name="itemId" style="width: 200px;" required>
        <option>------</option>
        <?php
          $num=count($list);
          for ($i=0; $i < $num; $i++) { 
            echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
          }
        ?>
      </select><br>
      <input type="submit" name="" value="send">

    </form>

    <table border="1">
      <tr>
        <td>ID</td>
        <td>Name</td>
        <td>Price</td>
        <td>Info</td>
        <td>Tip</td>
        <td>mate1</td>
        <td>mate2</td>
        <td>pict</td>
        <td>stat</td>
      </tr>
      <tr>
        <td>
          <?= $data['itemId']; ?>
        </td>
        <td>
          <?= $data['itemName']; ?>
        </td>
        <td>
          <?= $data['itemPrice']; ?>
        </td>
        <td>
          <?= $data['itemInfo']; ?>
        </td>
        <td>
          <?= $data['itemTip']; ?>
        </td>
        <td>
          <?= $data['mate1']; ?>
        </td>
        <td>
          <?= $data['mate2']; ?>
        </td>
        <td>
          <?= $data['pict']; ?>
        </td>
        <td>
          <?= $data['stat']; ?>
        </td>
      </tr>

    </table>