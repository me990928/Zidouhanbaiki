<?php

  /**
   * クーポン関連
   */

  // require '../db/db.php';

  class Cpon extends Info
  {
    public $num;
    public $code;
    public $cpnlist;

    public function setBuylog($arg){
      var_dump($arg);

      $stmt = $this->db->prepare('insert into f_buy_historys (f_coupon_id, f_item_id) values(:cid,:iid)');

      $cid = $arg[1]; // クーポンID
      $iid = $arg[0];         // 商品ID

      $stmt->bindParam(":cid",$cid,PDO::PARAM_STR);
      $stmt->bindParam(":iid",$iid,PDO::PARAM_STR);

      $stmt->execute();
    }

    public function getPrice($arg){

      $stmt = $this->db->prepare('select f_price from t_items where f_item_id = :cid');

      $cid = $arg; // クーポンコード

      $stmt->bindParam(":cid",$cid,PDO::PARAM_STR);

      $stmt->execute();

      $data = $stmt->fetchAll( PDO::FETCH_NUM );

      return $data;

    }

    public function codeMatch($arg){

      $stmt = $this->db->prepare('select * from t_coupons_lssuance where f_coupon_code = :cid');

      $cid = $arg; // クーポンコード

      $stmt->bindParam(":cid",$cid,PDO::PARAM_STR);

      $stmt->execute();

      $data = $stmt->fetchAll( PDO::FETCH_NUM );

      return $data;
    }

    public function cpnInfo($arg){

      $stmt = $this->db->prepare('select * from t_coupons where f_coupon_id = :cid');

      $cid = $arg; // クーポンコード

      $stmt->bindParam(":cid",$cid,PDO::PARAM_STR);

      $stmt->execute();

      $data = $stmt->fetchAll( PDO::FETCH_NUM );

      return $data;
    }

    public function getNum(){
      $stmt = $this->db->query(' select count(*) from t_coupons ');
      $num = $stmt->fetchAll( PDO::FETCH_NUM );

      $strlen = mb_strlen($num[0][0]);

      $len = 3 - $strlen;

      $i = 0;

      $zero = null;

      while($i<$len){
        $zero = "0".$zero;
        $i++;
      }

      $number = $zero.$num[0][0];

      return $this->num = $number;
    }
    
    public function createCode(){

      // ランダムな英数字の生成
      $str = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPUQRSTUVWXYZ';
      $str_r = substr(str_shuffle($str), 0, 10);

      return $this->code = $str_r;

    }

    public function createCoupon($arg){

      $stmt = $this->db->prepare('insert into t_coupons (f_coupon_id, f_item_id, f_start_date, f_effective_date,  f_discount, f_status_id) values(:cid,:iid,:std,:efd,:dis,:stat)');

      $cid = 'CM'.$this->num; // クーポンID
      $iid = $arg[0];         // 商品ID
      $std = $arg[1];         // 開始日
      $efd = $arg[2];         // 期限
      $dis = $arg[3];         // 割引後額
      $stat = 1;              // 有効無効

      $stmt->bindParam(":cid",$cid,PDO::PARAM_STR);
      $stmt->bindParam(":iid",$iid,PDO::PARAM_STR);
      $stmt->bindParam(":std",$std,PDO::PARAM_STR);
      $stmt->bindParam(":efd",$efd,PDO::PARAM_STR);
      $stmt->bindParam(":dis",$dis,PDO::PARAM_INT);
      $stmt->bindParam(":stat",$stat,PDO::PARAM_INT);

      $stmt->execute();

      $num = $stmt->fetchAll( PDO::FETCH_NUM );


      // echo '<br>'.$num;

      return true;

    }


    public function getCouponList(){
      // pickup Coupons List
      date_default_timezone_set('Asia/tokyo');

      $data = $this->db->query('select t_coupons.*, t_items.f_item_name from t_coupons inner join t_items on t_coupons.f_item_id = t_items.f_item_id where t_coupons.f_status_id = 1 and t_coupons.f_start_date <= \''.date("Y-m-d").'\' and t_coupons.f_effective_date >= \''.date("Y-m-d").'\'');
    
      $list = $data->fetchAll( PDO::FETCH_NUM );

      // var_dump($list);

      return $this->$cpnList = $list;
    }

    public function addCoupons($arg){
      error_reporting(-1);
      var_dump($arg);
    // 発行しますのよ！
      $itemid = $this->db->query('select f_item_id from t_coupons where f_coupon_id = \''.$arg[1].'\'');
      $id = $itemid->fetchAll( PDO::FETCH_NUM );



      $stmt = $this->db->prepare('insert into t_coupons_lssuance (f_user_id,f_item_id,f_coupon_id,f_coupon_code,f_status_id) values(:user,:item,:cpnid,:cpncode,:stat)');

      $user = $arg[0]; // ユーザID
      $item = $arg[1]; // アイテムID
      $cpnid = $arg[2]; // クーポンID
      $cpncode = $arg[3]; // クーポンコード
      $stat = 1;

      // echo $user.'<br>';
      // echo $item.'<br>';
      // echo $cpnid.'<br>';
      // echo $cpncode.'<br>';
      // echo $stat.'<br>';

      $stmt->bindParam(":user",$user,PDO::PARAM_STR);
      $stmt->bindParam(":item",$item,PDO::PARAM_STR);
      $stmt->bindParam(":cpnid",$cpnid,PDO::PARAM_STR);
      $stmt->bindParam(":cpncode",$cpncode,PDO::PARAM_STR);
      $stmt->bindParam(":stat",$stat,PDO::PARAM_INT);

      $stmt->execute();

      return true;
    }


  }

?>