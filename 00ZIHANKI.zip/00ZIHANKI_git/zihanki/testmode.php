<!-- <!DOCTYPE html>
<html lang="ja">
<head>
<title>aQure プロトタイプ 在庫あり</title>
<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zihanki.css">
<link rel="stylesheet" href="modal.css">
<link rel="stylesheet" href="prot.css">
<link rel="shortcut icon" href="">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&display=swap" rel="stylesheet">

<script defer type="text/javascript" src="jquery.js"></script>
<script defer type="text/javascript" src="modal.js"></script>
 -->
<style type="text/css">

  #php{
/*    color: white;*/
  }

  .black{
    color: black;
  }

  .box{
    width: 115px;
  }

  .divecho{
    display: flex;
    justify-content: space-between;

  }

  .drink{
    margin: 0 auto;
  }
/*
  .flex{
    display: flex;
  }*/

</style>
<!-- 
</head>

    <div id="zihankiWrap" class="midole">

        <div class="containar">
          <div id="php"> -->
<?php

require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';
require '../setwindow/php/class/layoutClass.php';

require './zaikoSys.php';
require './zaiko_0.php';

  // error_reporting(-1);

  $itemObj = new Info();
  $sysObj = new SysTxt();

  if($itemObj->conn()){     // DB実行準備

    $sysObj->conn();

    $dbConn2 = $sysObj->getDb();

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

    $list = $itemObj->getItemData();

    

    $cnt = count($list);

    for ($i=0; $i < $cnt; $i++) { 
      $e = $itemObj->getPictName($list[$i][8]);
      $pict[$i] = $e[0];
    }

    $layData = $itemObj->getlayoutData();
    // var_dump($pict[2]);


    $layData[0][2]; // 商品ID
    $layData[0][1]; // 配置番号
    $laySum = count($layData); // 合計配置数


for ($i=0; $i < $laySum; $i++) { 

    $arg[0] = $layData[$i][2];

    $itemObj->getInfo($arg);

    $data[$i] = $itemObj->outItemData();

  }

    // echo $pict[1][0];
    // echo $list[1][2];

    // var_dump($textTips);

   $brPosi = $sysObj->getBr();

  }else{
    // echo "エラー";
  }


$id = 24;
$itemPict_dir = "./sozai/11cokePetZero.png";
// $temp = "💧";  //一番若いtimestampのストックの番号を使用
$price = '¥120';

$z = '0';

for ($i=0; $i < $laySum; $i++) { 
  $not = false;

  if ($layData[$i][3]==="1") {
    $z++;
    $hc = "hot";
    $temp = "🔥";
    $tempFlag = '1';
    $hs = array_search($data[$i][0], $hot0);
    if($hot0[$hs]!=$data[$i][0]){
      $not = true;
    }
  }elseif ($layData[$i][3]==="0") {
    $z++;
    $hc = "cool";
    $temp = "💧";
    $tempFlag = '0';
    $cs = array_search($data[$i][0], $cool0);
    if($cool0[$cs]!=$data[$i][0]){
      $not = true;
    }
  }
    $nf = "";
  if ($layId[$i][1]<1 || $not=='true') {
    $hc = "not";
    $nf = "not";
  }

  // $zyunbiCond[]
  // var_dump($layData[$i][2]);
  // var_dump($layData[$i][3]);
  // var_dump($zyunbiCond);
error_reporting(0);
  foreach ($zyunbiCond as $value) {
    if($value[0] == $layData[$i][2]){
      if($value[1] == $layData[$i][3]){
        if($value[2] == false){
          $hc = "zun";
        }
      }
    }
  }
error_reporting(-1);
  $num = 1000 - $i;

  $test = "   
            <div id='{$data[$i][0]}{$nf}' class='{$data[$i][0]}-{$layData[$i][3]} data-obj select-{$hc} linkbox box{$nf} drink{$z}' style='z-index: {$num}'>
                <div class='drink'>
                    <a class='links' href='#'></a>
                    <img id='{$data[$i][0]}img{$i}' src='../setwindow/php/act/imgItemOri/{$data[$i][7]}.png' alt='商品'>
                    <div class='{$data[$i][0]}-{$layData[$i][3]} info-obj {$hc} black drink{$z}m'>{$temp}¥{$data[$i][2]}</div>
                </div>
                <a href='#'></a>
                <form  enctype='multipart/form-data' method='post' name='Form' id='{$data[$i][0]}Form{$nf}{$i}' class='findF'>
                  <!-- 
                  ここに隠しパロメータを埋め込む
                  商品IDを渡す
                  遷移先で必要なデータを引き出すために使用する
                   -->
                  <input type='hidden' class='test' name='drink' value='{$data[$i][0]}'>
                  <input type='hidden' class='test' name='num' value='{$data[$i][0]}-{$i}'>
                  <input type='hidden' class='test' name='temp' value='{$tempFlag}'>
                </form>
            </div>";
            

  $beta[$i]=$test;
}

// var_dump($layId);


?>

