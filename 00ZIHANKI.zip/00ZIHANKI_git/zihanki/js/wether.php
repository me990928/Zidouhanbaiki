<style type="text/css">
  .weathrimg{
    width: 2rem;
    height: 2rem;
    vertical-align: -10px;
  }

  .namespan{
/*    margin: 0 0 10px 0;*/
  }

  .weathrdiv{
    color: white;
    font-family: ヒラギノ角ゴシック;

    background: gray;
    padding: 0 0 7px 15px;
    border-radius: 15px;

    position: absolute;
    top: 15px;
    left: 15px;
  }


</style>
<?php

   //天気を取得したい都市　例：岐阜市
  $city = "Nagoya,jp";

  //アカウント登録で取得したAPI Key
  $appid = "72991588581414936f233577ec84070e";

  //以下のURLからJSON形式で現在の天気情報を取得
  $url = "http://api.openweathermap.org/data/2.5/weather?q=" . $city . "&lang=ja&units=metric&APPID=" . $appid;

  $json = file_get_contents( $url );
  $json = mb_convert_encoding( $json, 'UTF8', 'ASCII,JIS,UTF-8,EUC-JP,SJIS-WIN' );
  $json_decode = json_decode( $json,true );

  // var_dump($json_decode['weather'][0]['description']);

  // if( $type  === "weather" ):
  //   $out = $json_decode->weather[0]->main;

  // //現在の天気アイコン
  // elseif( $type === "icon" ):
    $name = $json_decode['name'];
    $pict = "<img class='weathrimg' src='https://openweathermap.org/img/wn/" . $json_decode['weather'][0]['icon'] . "@2x.png'>";
    $weather = $json_decode['weather'][0]['description'];
    $weatherDisp = "<div class='weathrdiv'><span class='namespan'>".$name."：".$weather.$pict."</span></div>";
  // //現在の気温
  // elseif( $type  === "temp" ):
  //   $out = $json_decode->main->temp;

  // //パラメータがないときは配列を出力
  // else:
  //   $out = $json_decode;

  // endif;

  // return $out;

?>