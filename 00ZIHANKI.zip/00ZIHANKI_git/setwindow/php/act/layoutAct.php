<?php
  // require '../escape.php';

  require '../class/db.php';

  require '../item/itemsClass.php';

  require '../class/layoutClass.php';

  $layout = new Lay();

  // var_dump($_POST);
  // var_dump($_GET);
  // var_dump($_POST['hotFlag']);

  // $height = $_POST['height'];
  // $width = $_POST['width'];

  // $num = $height * $width;

  // echo $num;

  if($layout->conn() && $_POST['flag']==='form' ){     // DB実行準備

      $dbConn = $layout->getDb();  // DB実行

      // $data = $_POST['objBox'];

      // var_dump($_POST['selectBox']);

      $data = $_POST['selectBox'];

      $sum = $_POST['widthBox'] * $_POST['heightBox'];
      $br = $_POST['widthBox'];

      foreach ($data as $key => $val) {
        if ($val === '商品を選択してください') {
          echo "<script>alert('選択されていない箇所があります。')</script>";
          exit;
        }
      }

      unset($key);
      unset($val);

      $layout->setItems($data,$br,$sum);

      error_reporting(0);

      if($_POST['hotFlag']!==null){
        // flagが立ったnumが納入されてる
        $hf =  $_POST['hotFlag'];
        // var_dump($hf);
        $layout->setTemp($data,$hf);
        error_reporting(-1);
      }else{
        // echo "Not Hot drink !";
      }


      echo "<script>alert('登録完了')</script>";

      exit();

    }else{
      // echo "エラー";
    }

    // アイテム設定用メニュー生成
    if($_POST['flag']==='selected'){
      // $numNow = $_POST['numNow']; // 今の数字
      // $numAfter = $_POST['numAfter']; // 前の数字
      // $number = $_POST['num'];

      // require '../class/db.php';

      // require '../item/itemsClass.php';

      $intW = $_POST['width'];
      $intH = $_POST['height'];

      $itemObj = new Items();

      if ($itemObj->conn()) {
        $dbConn = $itemObj->getDb();  // DB実行
      }else{
        echo "エラー";
      }

      $list = $itemObj->AlldispItemsId();


      require_once './selectBox.php';

      // for ($i=1; $i <= $num ; $i++) {
        test($list,$intW,$intH);

      // }
      
    }
  

?>