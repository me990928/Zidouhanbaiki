<?php
require './getdrinkConf.php';
require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';

    

  error_reporting(-1);

  $itemObj = new Info();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    $arg[0] = $drinkData['drink'];

    $itemObj->getInfo($arg);

    $data = $itemObj->outItemData();

    $arg = '../setwindow/php/act/tip/'.$data[4].'.txt';

    $text2 = $itemObj->getInfoText($arg);

  }else{
    // echo "エラー";
  }

  $outTip = null;

  for ($i=0; $i < count($text2); $i++) { 
    $outTip .= $text2[$i];
  }

  echo $outTip;
?>