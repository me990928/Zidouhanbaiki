<!DOCTYPE html>

<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <title>クーポンサイト-TOP</title>
  <link rel="stylesheet" type="text/css" href="css/common.css">
</head>
<body>
  <main>

    <!-- <div class="msgWin"> -->
<?php
  // error_reporting(0);
  require '../setwindow/php/escape.php';
  require '../setwindow/php/class/db.php';
  require '../setwindow/php/item/itemsClass.php';
  require '../axios/infoClass.php';
  require '../setwindow/php/class/couponClass.php';

  // タイムゾーン設定
  date_default_timezone_set('Asia/tokyo');

  $cpnObj = new Cpon();
  

  if($cpnObj->conn()){     // DB実行準備

    unset($data);    

    $dbConn = $cpnObj->getDb();  // DB実行

  // var_dump($_GET);


      // $dataの中身
      // data[0]= クーポンID
      // data[1]= 商品名
      // data[2]= 割引後の価格

      $userId = "yuya";

      $cpnArr[0]=$_COOKIE['userId'];
      $cpnArr[1]=$_GET['itemid'];
      $cpnArr[2]=$_GET['id'];
      $cpnArr[3]=$_GET['cp'];

      // var_dump($cpnArr);

      // couponClassよりaddCouponメソッドで使用する配列
      // data->'クーポンID'

      // クーポン発行メソッド
      $cpnObj->addCoupons($cpnArr);  // couponClass.phpよりユーザ宛クーポン発行

}else{
  echo"error";
}

// var_dump($_COOKIE);

?>

    <!-- </div> -->
    
    <div id="header">
      <a href="index.html"><img src="./sozai/login.png"></a>
      <div class="title">COUPON SITE</div>
    </div>

    <div id="content">

        <div class="box couponCodePageBox shadow">
          <div class="items">
            <img class="f-shadow itemImg" src="../setwindow/php/act/imgItemOri/<?= $_GET['pict'] ?>.png" alt="商品：Dr.Pepper">
          </div>
          <div class="infoBox">
            <div class="couponDay"><span class="red"><?= $_GET['enddate']?></span>まで</div>
            <div class="itemName">Dr.Pepper</div>
            <div class="itemValue"><span class="under_line red"><?= $_GET['price']?></span> → <?= $_GET['dis']?>円</div>
          </div>
            <p class="msg">下記のクーポンコードを⼊⼒してください</p>
            <section class="codeBox"><div href='useCoupon.html' class='couponCode'><?= $_GET['cp']?></div></section>
        </div>


            <section class="backBtn" style="margin-bottom: 500px"><a href='Coupon.html' class='btn_03' onclick='document.a_form.submit();'>クーポン一覧に戻る</a></section>

    </div>

  </main>
</body>
</html>