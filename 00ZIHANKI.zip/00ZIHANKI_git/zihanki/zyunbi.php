<?php

  date_default_timezone_set('Asia/Tokyo');

  $jsonUrl = "./json/zaikoList.json";

  if (file_exists($jsonUrl)) {
    $jsonArr = file_get_contents($jsonUrl);

    $jsonData = mb_convert_encoding($jsonArr, 'UTF8', 'ASCII,JIS,UTF-8,EUC-JP,SJIS-WIN');

    $Arry = json_decode($jsonData);

    if($Arry[0][0] === null){
      error_reporting(0);
    }

    foreach ($Arry as $value) {
      $arrId[] = $value[1];
    }

    $i = 0;
    foreach ($Arry as $value) {
      $Arry[$i][5] = strtotime($value[5]);
      $arrDate[] = $Arry[$i][5];
      $i++;
    }
    $i = null;

    foreach ($Arry as $value) {
      $arrTemp[] = $value[6];
    }

    // ソートする
    array_multisort(
      $arrId, SORT_ASC, SORT_STRING, 
    $arrDate, SORT_DESC, SORT_NUMERIC, 
    $arrTemp, SORT_ASC, SORT_NUMERIC,
    $Arry);

    // デバッグ用
    // for ($i=0; $i < count($Arry); $i++) { 
    //   var_dump($Arry[$i]);
    //   echo date('Y-m-d - H:i',$Arry[$i][5]);
    //   echo "<br>";
    // }

    $bef[0]=null;
    foreach ($Arry as $value) {
      if($bef[0]!==null && $value[1]==$bef[1]){
        if($value[6]!=$bef[6]){
          $zyunbiArr[]=$value;
        }
      }else{
        $bef = $value;
        $zyunbiArr[]=$value;
      }
    }

    $i = 0;

    foreach ($zyunbiArr as $value) {
      $date = time();
      $timer = $date - $value[5];
      $min = $timer / 60;
      // echo $timer.'/';
      if($min > $value[2]){
        // $zyunbiCond[$i][0] = $value[1]; 
        // $zyunbiCond[$i][1] = $value[6]; 
        // $zyunbiCond[$i][2] = true;
        // $zyunbiCond[$i][3] = $min;
        // $zyunbiCond[$i][4] = $value[2];
        // echo $zyunbiCond[$i][1]; 
      }else{
        $zyunbiCond[$i][0] = $value[1]; 
        $zyunbiCond[$i][1] = $value[6]; 
        $zyunbiCond[$i][2] = false;
        $zyunbiCond[$i][3] = $min;
        $zyunbiCond[$i][4] = $value[2];
        // echo $timer.'/';
        $i++;

      }

    }

    error_reporting(-1);

  }else{
    echo "error";
    // exit;
  }

?>