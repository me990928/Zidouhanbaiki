<!DOCTYPE html>

<html lang="ja">

  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <!-- <script defer type="text/javascript" src="js/ajax.js"></script> -->
    <script defer type="text/javascript" src="js/ajax-logout.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>

  </head>

  <body>

    <main class="content">

      <div id="infoBar">
        <p class="red">
          この画面は別の小ウィンドウで表示されます
        </p>
      </div>
      
      <div id="contents">

        <form method='get' action='#'>

          <h1>COUPON枠の設定</h1>
          <h3>タイトル：<input type='text' name='cuponTitle' placeholder="CUPON配布中!!"></h3>
          <h3>QRコード（画像）：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3>
          <h3 class="red">↑QRコードを用いて別サイトに誘導する枠の設定（クーポンサイトやホームページを想定）</h3>

          <h1>SNS枠の設定</h1>
          <h3>タイトル：<input type='text' name='cuponTitle' placeholder="SNSで共有しよう！"></h3>
          <h3>埋め込みコードの設定：</h3>
          <textarea id="story" name="story" rows="5" cols="33">埋め込みコードを入力</textarea><br>
          <h3 class="red">↑ SNSを表示する枠の設定（基本的にはSNSを表示する）</h3>

          <section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section>

        </form>

          <!-- <section><a href='../../index_0.html' class='btn_03 logOut' onclick='document.a_form.submit();'>LOGOUT</a></section> -->

          <!-- <h3 class="red logOut">ログアウトすることで自販機画面に戻ります</h3> -->
          
        <form method="post" id="logoutForm" style="padding-bottom: 500px;">
          <input type="hidden" id="outPram" name="logout" value="true" >
          <section><a class='btn_03' id="logoutBtn">LOGOUT</a></section>
        </form>


      </div>
      
      <!-- <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin1.html" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin2.html" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin3.html" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin4.html" id="item4">menu</a>
          </span>
        </div>

      </div> -->

      <?php

      require 'footer.php';

      ?>

    </main>

  </body>
</html>