let winOpenBtn = document.getElementById("objBtn");


  winOpenBtn.addEventListener('click',function openWindow(){
  window.open(
    "setWin.php",
    "設定画面",
    "top=100,left=100,width=300,height=500"
    );
  });

