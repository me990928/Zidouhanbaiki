<style type="text/css">
  .phpZ{
    color: white;
    background: black;
  }
</style>

<div class="phpZ">
<?php

  // require '../setwindow/php/class/db.php';
  // require '../setwindow/php/class/layoutClass.php';

  $layObj = new Lay();

  if($layObj->conn()){

      $dbConn3 = $layObj->getDb();  // DB実行

      $SNSdata = $layObj->getSNS();

      // var_dump($SNSdata);

      if ($SNSdata[0][3]==='1') {
        $SNStitle = $SNSdata[0][1];
        $SNSpict = $SNSdata[0][2];
     }else{
      echo "<script>alert('error')</script>";
     }

      // echo $logo;

  }else{
    // echo "失敗";
  }

?>

</div>