<?php

  // require '../setwindow/php/class/db.php';
  // require '../setwindow/php/class/layoutClass.php';
  $zaiObj = new Lay();

  if($zaiObj->conn()){
    $dbConn = $zaiObj->getDb();

    // ポジションテーブル一覧
    $posiData = $zaiObj->getLay();
    // 在庫テーブル一覧
    // $zaiData = $zaiObj->getZai();

    // var_dump($posiData);

    // レアウトされる商品の種類表
    for ($i=0; $i < count($posiData); $i++) { 
      $data[$i] = $posiData[$i][2];
    }

    // var_dump($posiData[0][3]);

    $data2 = array_unique($data);

    $i=0;

    $idList[]=null;

    foreach ($data2 as $val) {
      $List[$i] = $val;
      $i++;
    }
    // 完成

    // var_dump($List);

    // IDごとの在庫配列
    for ($i=0; $i < count($List); $i++) { 
      $id[$i] = $zaiObj->getZai($List[$i]);
    }

    // 完成

    // var_dump($id[0][0][2]); // 時間
    // var_dump($id[0][0][5]); // 追加日時
    // var_dump($id[0][0][1]); // 追加日時

    // 現在時刻取得
    date_default_timezone_set('Asia/Tokyo');
    $today = date('Y-m-d G:i:s');
    // echo $today.'<br>';

    // 在庫確認配列
    for ($i=0; $i < count($List); $i++) { 
      for ($n=0; $n < count($id[$i]); $n++) { 
        if($List[$i]==$id[$i][$n][1]){
        }
      }
      // echo $List[$i]."が{$n}こある";
      $zaiko[$i][0]=$List[$i];
      $zaiko[$i][1]=$n;
    }

    // 在庫判定
    for ($i=0; $i < count($zaiko); $i++) { 
      if($zaiko[$i][1]<1) {
        // echo $zaiko[$i][0]."在庫なし";
        $nzFlag='1';
      }else{
        // echo $zaiko[$i][0]."在庫あり";
        $nzFlag='0';
      }
    }
  }

  // IDごとの在庫
  // var_dump($zaiko);

  // $a = $zaiObj->getAddTime($arg);

  // print_r($a);

  for ($i=0; $i < count($data); $i++) { 
    $layId[$i][0] = $data[$i];
    for ($n=0; $n < count($zaiko); $n++) { 
      if ($data[$i]===$zaiko[$n][0]) {
        $layId[$i][1] = $zaiko[$n][1];
      }
    }
  }

  // ここまでがフロント用

?>