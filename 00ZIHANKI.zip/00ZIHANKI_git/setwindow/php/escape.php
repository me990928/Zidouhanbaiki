<?php

  foreach ($_POST as $key => $value) {
    $_POST[$key] = htmlspecialchars($value,ENT_QUOTES);
  }

  foreach ($_GET as $key => $value) {
    $_GET[$key] = htmlspecialchars($value,ENT_QUOTES);
  }
?>