$(function(){

    var API_KEY = "72991588581414936f233577ec84070e";

    var defaultCity = 'Nagoya';

    function currentWeather(){
        $.ajax({
            url: '//api.openweathermap.org/data/2.5/weather?q=' + defaultCity + ',jp&units=metric&appid=' + API_KEY,
            datatype: 'json',
            type: 'GET'
        })
        .done(function(res){
            console.log(res)
        })
        .fail(function(){
            console.log('err')
        })
    }

})