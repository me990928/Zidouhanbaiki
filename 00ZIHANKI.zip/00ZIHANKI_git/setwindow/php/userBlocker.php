<?php

  if($_COOKIE['userClass']=="2" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+10,'/');
    header('location: ../user/loginPage.php');
  }

?>