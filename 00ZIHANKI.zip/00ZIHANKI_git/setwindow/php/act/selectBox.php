<?php
  // print_r($list);


  function test($list,$intW,$intH){

  // $number = $numNow - $numAfter;

  // $cnt = $number;

  $num=count($list);
  $w = 1;

  for ($i=1; $i <= $intH*$intW; $i++) { 

      $e = mb_strlen($i);
      if ($e<2) {
        $a = '0'.$i;
      }else{
        $a = $i;
      }
      echo "$a. <select name='selectBox[]'>";
        echo "<option>商品を選択してください</option>";
    for ($k=0; $k < $num; $k++) { 
      echo "<option  value=".$list[$k]['f_item_id'].">".$list[$k]['f_item_id'].'-'.$list[$k]['f_item_name']."</option>";
    }
      echo "</select>";
      // echo " <input type='hidden' name='hotFlag[]' value='0'>";
      echo " HOT<input type='checkbox' name='hotFlag[]' id='hotFlag' value='$i'><br>";
    if($w == $intH && $i != $intH*$intW){
      echo "改行<br>";
      $w = 0;
    }
    $w++;
  }

  // echo $num;

  // for ($i=0; $i < $cnt; $i++) { 
  //     $e = mb_strlen($i);
  //     if ($e<2) {
  //       $a = '0'.$i;
  //     }
  //   echo $number.". <select name='selectBox[]'>";
  //   echo "<option>商品を選択してください</option>";
  //   for ($i=0; $i < $num; $i++) { 
  //     echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
  //   }
  //   echo "</select><br>";


  // }

  // for ($k=$numAfter+1; $k < $numNow+1; $k++) {
  //   $e = mb_strlen($k);
  //       if ($e<2) {
  //         $a = '0'.$k;
  //         echo "$a. <select name='selectBox[]'>";
  //             echo "<option>商品を選択してください</option>";
  //             for ($i=0; $i < $num; $i++) { 
  //                 echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
  //               }
  //         echo "</select>
  //         <br>";
  //       }else{
  //         echo "$k. <select name='selectBox[]'>";
  //         echo "<option>商品を選択してください</option>";
  //             for ($i=0; $i < $num; $i++) { 
  //                 echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
  //               }
  //         echo "</select>

  //         <br>";
  //       }

  // }

  // echo $number.". <select name='selectBox[]'>";
  //   echo "<option>商品を選択してください</option>";
  // for ($i=0; $i < $num; $i++) { 
  //   echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
  // }
  // echo "</select><br>";
}
?>