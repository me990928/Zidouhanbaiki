<?php

  // error_reporting(0);

  require '../escape.php';


  if($_COOKIE['userClass']!=="1" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+1);
    header('location: ./back.php');
  }

  error_reporting(-1);

  require '../class/db.php';

  require '../item/itemsClass.php';

  require '../class/db_stock_register_class.php';

  $stockObj = new Stock();

  if($stockObj->conn()){     // DB実行準備

    $dbConn = $stockObj->getDb();  // DB実行

    // var_dump($stockObj);     // デバック用

    // echo "成功";

    $list = $stockObj->getStockList();
    $counter = $stockObj->getStocCounter();

    $mode = "c";
    $listC = $stockObj->creatTable($counter,$mode);

    // echo $listC;

    // $listC = "<table><tr><td>やあ</td></tr></table>";

    // $alert = "<script type='text/javascript'>alert('".$listC."');</script>";

    // echo $alert;

    echo $listC;

    $mode = "l";
    // echo $stockObj->creatTable($list,$mode);


  }else{
    echo "エラー";
  }


?>