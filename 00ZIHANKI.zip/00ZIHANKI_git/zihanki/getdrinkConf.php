<?php
    
  $request_body = file_get_contents('php://input'); //送信されてきたbodyを取得(JSON形式）
  $jsondata = json_decode($request_body,true); // デコード

  // var_dump($data);

  $data1 = explode('&',$jsondata[0]);

$i = 0;
foreach ($data1 as $val) {
  $data2[$i] = explode('=',$val);
  $i++;
}
  // $data2 = explode('=',$data1);

  // var_dump($data2);

  for ($i=0; $i < count($data2); $i++) { 
    $drinkData[$data2[$i][0]] = $data2[$i][1];
  }

  // var_dump($drinkData);
?>