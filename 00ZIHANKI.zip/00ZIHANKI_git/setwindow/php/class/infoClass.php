<?php
// itemClass.php と同時に使う

// require 'itemsClass.php';

class Info extends Items{
  public $items;
  public $Infokey;
  public $Tipkey;
  public $Mate1;
  public $Mate2;
  public $Picts;
  public $Stat;


  public function getlayoutData(){
    $stmt = $this->db->query('select * from t_layouts where not f_item_id = \'-\'');
    $data = $stmt->fetchAll(PDO::FETCH_NUM);

    return $data;
  }

  public function getItemData(){
    $stmt = $this->db->query('select * from t_items');
    $data = $stmt->fetchAll(PDO::FETCH_NUM);

    return $data;
  }

  public function outItemData(){
    $array = array(
      "0" => $this->items[0][1],
      "1" => $this->items[0][2],
      "2" => $this->items[0][3],
      "3" => $this->Infokey[0][0],
      "4" => $this->Tipkey[0][0],
      "5" => $this->Mate1[0][0],
      "6" => $this->Mate2[0][0],
      "7" => $this->Picts[0][0],
      "8" => $this->Stat[0][0]
    );
    // var_dump($array);
    return $array;
  }

  public function getInfo($arg){
    $this->getItems($arg[0]);
    $this->getInfoTxt($this->items[0][4]);
    $this->getTipTxt($this->items[0][5]);
    $this->getMate1($this->items[0][6]);
    $this->getMate2($this->items[0][7]);
    $this->getPictName($this->items[0][8]);
    $this->getStatus($this->items[0][9]);
  }

  private function getItems($arg){
    // echo $arg;
    $list = $this->db->query('select * from t_items where f_item_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->items = $data;
  }

  private function getInfoTxt($arg){
    // echo $arg;
    $list = $this->db->query('select f_item_info_key from t_items_info where f_item_info_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->Infokey = $data;
  }

  private function getTipTxt($arg){
    // echo $arg;
    $list = $this->db->query('select f_tip_info_key from t_tips_info where f_tip_info_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->Tipkey = $data;
  }

  private function getMate1($arg){
    // echo $arg;
    $list = $this->db->query('select t_materials.f_material_name from t_materials_1 inner join t_materials on t_materials_1.f_material_id = t_materials.f_material_id where t_materials_1.f_material_1_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->Mate1 = $data;
  }

  private function getMate2($arg){
    // echo $arg;
    $list = $this->db->query('select t_materials.f_material_name from t_materials_2 inner join t_materials on t_materials_2.f_material_id = t_materials.f_material_id where t_materials_2.f_material_2_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->Mate2 = $data;
  }

  public function getPictName($arg){
    $list = $this->db->query('select f_item_key from t_items_picts where f_item_pict_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->Picts = $data;
  }

  private function getStatus($arg){
    $list = $this->db->query('select f_status from t_statuses where f_status_id = \''.$arg.'\'');
    $data = $list->fetchAll(PDO::FETCH_NUM);

    return $this->Stat = $data;
  }

  // テキスト読み込み

    public function getInfoText($arg){
      // 中身の配列化
      $fp = @fopen($arg, 'r');

      while(!(feof($fp))){
        // 1行分の読み込み
        $aryData[] = fgets($fp);
      }

      fclose($fp);

      return $aryData;
    }

}