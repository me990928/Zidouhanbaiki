$(function () {
    $('#registMsg').on('click', function () {

        // GET
        // var strQuery = $('#fr_in').serialize();

        // let name = $('#f_material_name').val();
        // let key = $('#f_material_key').val();

        // if(name === "" || key === ""){
        //     alert('記入漏れがあります');
        //     if (name === "") {
        //         $('#errName').html('入力してください');
        //     }
        //     if (key === "") {
        //         $('#errFile').html('選択してください');
        //     }
        // }

        // POST
        let $form = $('#msgForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/registMsg.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                // $('#contents').after(responce);
                console.log('a')
                // var ary = responce.split('<br>');
                alert('登録完了');
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});

$(function () {
    $('#couponBtn').on('click', function () {

        // GET
        // var strQuery = $('#fr_in').serialize();

        let idc = $('#itemIdc').val();
        let stdc = $('#stdc').val();
        let efdc = $('#efdc').val();
        let disc = $('#disc').val();

        if(idc === "商品を選択してください" || stdc === "" || efdc === "" || disc === ""){
            alert('記入漏れがあります');
            if (idc === "商品を選択してください") {
                $('#erridc').html('選択してください');
            }
            if (stdc === "") {
                $('#errstdc').html('入力してください');
            }
            if (efdc === "") {
                $('#errefdc').html('入力してください');
            }
            if (disc === "") {
                $('#errdisc').html('入力してください');
            }
        }

        // POST
        let $form = $('#cpnForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/createCpn.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#cpnDbug').html(responce);
                console.log('a')
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});