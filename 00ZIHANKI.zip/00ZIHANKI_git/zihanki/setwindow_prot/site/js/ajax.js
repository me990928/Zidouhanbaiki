$(function () {
    $('#item3').on('click', function () {

        // GET
        var strQuery = $('#myForm').serialize();

        // POST
        //var formData = new FormData();
        //formData.append('id', $('#keyword').val());


        console.log('formData');

        $.ajax({
            url: 'back.php',
            type: 'GET',
            // type: 'POST',
            datatype: 'text',
            async: true,
            data: strQuery,
            // data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#contents').after(responce);
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                // $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});

