$(function () {
    $('#cpnBtn').on('click', function () {

        let name = $('#cuponTitle').val();
        let key = $('#logoFile').val();

        console.log(name)

        if(name === "" || key === ""){
            alert('記入漏れがあります');
            console.log('aaaaa')
            if (name === "") {
                $('#errTitleC').html('入力してください');
            }
            if (key === "") {
                $('#errQR').html('選択してください');
            }
        }

        // POST
        let $form = $('#cpnBoxForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/couponBox.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#cBoxDebug').html(responce);
                console.log('a')
                // var ary = responce.split('<br>');
                alert('登録完了');

            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});

$(function(){
    $('#addCpnBtn').on('click',function(){

        // POST
        let $form = $('#addCpn');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/addCpn.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
        .done(function(responce){
                $('#aCpnDebug').html(responce);
        })
        .fail(function (xhr) {
            $('#aCpnDebug').html(xhr);
            console.log(xhr);
        })

    });
})

$(function () {
    $('#snsBtn').on('click', function () {

        let name = $('#snsTitle').val();
        let key = $('#story').val();

        console.log(name)

        if(name === "" || key === "埋め込みコードを入力"){
            alert('記入漏れがあります');
            if (name === "") {
                $('#errTitleS').html('入力してください');
            }
            if (key === "自販機コードを入力") {
                $('#errStoryS').html('入力してください');
            }
        }

        // POST
        let $form = $('#snsBoxForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/snsBox.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#sBoxDebug').html(responce);
                console.log('a')
                alert('登録完了');
                
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});

$(function () {
    $('#cmBtn').on('click', function () {

        let name = $('#cmnum').val();
        let key = $('#cmpict').val();

        // console.log(name)

        // if(name === "" || key === "埋め込みコードを入力"){
        //     alert('記入漏れがあります');
        //     if (name === "") {
        //         $('#errTitleS').html('入力してください');
        //     }
        //     if (key === "") {
        //         $('#errStoryS').html('ファイルをアップロードしてください');
        //     }
        // }

        // POST
        let $form = $('#cmForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/cmpict.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#cmerr').html(responce);
                console.log('a')
                
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
    });