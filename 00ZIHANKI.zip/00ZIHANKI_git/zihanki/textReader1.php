<?php

  require '../setwindow/php/class/db.php';

  require '../setwindow/php/class/sysClass.php';

  $sysObj = new SysTxt();


  if($sysObj->conn()){

    $dbConn = $sysObj->getDb();

    $zyunbiPass = $sysObj->getZyunbiMsg();

    // 設定値読み込みからの埋め込み

    $ft = file("../setwindow/php/sys/text/{$zyunbiPass[0][0]}");

    // var_dump($ft);

    $ftText = str_replace(array("\r\n", "\r", "\n"), "", $ft);

    $ftStr = null;

    foreach ($ftText as $val) {
      if($val !== ""){
      $ftStr .= $val; 
      $ftStr .= "<br>";
    }
  }

echo $ftStr;
}
?>