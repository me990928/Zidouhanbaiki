<?php

  require '../setwindow/php/class/db.php';
  require '../setwindow/php/class/layoutClass.php';
  $zaiObj = new Lay();

  if($zaiObj->conn()){

    $dbConn = $zaiObj->getDb();

    $Layout = $zaiObj->
  }

?>