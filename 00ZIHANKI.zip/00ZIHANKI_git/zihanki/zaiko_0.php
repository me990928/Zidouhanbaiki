<?php
  require('zikoBack2.php');

  $res = file_get_contents('./json/zaikoList.json',false);
  $zaikoJson = json_decode($res);


  $res = file_get_contents('./json/coolList.json',false);
  $coolJson = json_decode($res);


  $res = file_get_contents('./json/hotList.json',false);
  $hotJson = json_decode($res);

  error_reporting(0);
  // cool
  $cool0[]=null;
  for ($i=0; $i < count($coolJson); $i++) { 
    $cool0[$i] = $zaikoJson[$coolJson[$i]][1];
  }

  // hot
  $hot0[]=null;
  for ($i=0; $i < count($hotJson); $i++) { 
    $hot0[$i] = $zaikoJson[$hotJson[$i]][1];
  }

  // var_dump($host);
  error_reporting(-1);


  // var_dump($cool0);

  // $a = array_search('MC002', $cool0);

  // var_dump($a);
?>