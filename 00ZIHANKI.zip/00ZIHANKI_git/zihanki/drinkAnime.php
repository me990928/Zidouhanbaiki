<?php

  // echo "だkdhk邪hdkじゃhdk者bdjか<br>";

  // var_dump($_POST);


  $request_body = file_get_contents('php://input'); //送信されてきたbodyを取得(JSON形式）
  $jsondata = json_decode($request_body,true); // デコード

  $data1 = explode('&',$jsondata[0]);

  $i = 0;
  foreach ($data1 as $val) {
    $data2[$i] = explode('=',$val);
    $i++;
  }

  // var_dump($data2);


  // if(isset($data2[0][1])&&$data2[0][1]==true){
  //   break;
  // }

  $id = $data2[0][0];

  echo "<script>
var animationName = anime.timeline({
     loop: false,
    });

    // console.log('id')

    imgId = '{$id}';

    animationName
    .add({
        delay: 500,
        targets: '#'+imgId,
        translateY: 2000,
        elasticity: 0,
        easing: 'easeInOutSine',
        duration: 1000,
    })
    .add({
      targets: '#'+imgId,
      opacity: [1, 0],
      easing: 'easeInOutSine'
    })
    .add({
      delay: 600,
      targets: '#'+imgId,
      translateY: 0,
      easing: 'easeInOutSine'
    })
    .add({
      targets: '#'+imgId,
      opacity: [0, 1],
      duration: 1000,
      easing: 'easeInOutSine',
    })

    animationName = null;

    imgId = '';

  </script>";

?>