<?php

  require '../escape.php';

  // var_dump($_POST);

  if ($_POST['itemId']==='商品を選択してください' || $_POST['std']==='' || $_POST['efd']==='' || $_POST['dis']==='' ) {
    exit();
  }


  // 送信後の世界
  if($_POST['efd']<$_POST['std']){
    exit();
  }

date_default_timezone_set('Asia/tokyo');

  // error_reporting(0);


  if($_COOKIE['userClass']!=="1" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+1);
    header('location: ./back.php');
  }
  // var_dump($_POST['stock']);


  require '../class/db.php';

  require '../item/itemsClass.php';

  require '../class/sysClass.php';

  require '../class/infoClass.php';

  require '../class/couponClass.php';


  $itemObj = new Items();

  $sysObj = new SysTxt();

  $cpnObj = new Cpon();


  if($itemObj->conn() || $sysObj->conn() || $cpnObj->conn()){     // DB実行準備

    $itemObj->conn(); $sysObj->conn(); $cpnObj->conn();

    $dbConn0 = $itemObj->getDb();  // DB実行
    $dbConn1 = $sysObj->getDb();  // DB実行
    $dbConn2 = $cpnObj->getDb();  // DB実行

    $list = $itemObj->AlldispItemsId();


    // var_dump($itemObj);     // デバック用

    // echo "成功";
    $getNum = $cpnObj->getNum();
    // echo "<br>";
    // $code = $cpnObj->createCode();
    $arg = [$_POST['itemId'],$_POST['std'],$_POST['efd'],$_POST['dis']];
    $cpnObj->createCoupon($arg);

    echo "<script>alert('登録完了しました');</script>";

  }else{
    // echo "エラー";
  }


?>