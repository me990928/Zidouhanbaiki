<?php
  require '../escape.php';
  require '../class/db.php';
  require '../class/userLogin.php';

  var_dump($_COOKIE);
  var_dump($_POST);

  $loginObj = new userLogin();

  $loginObj->userLogout();

     echo "
      <script type='text/javascript'>
        setTimeout('link()', 0);
        function link(){
        location.href='./back.php';
        }
        </script>
    ";
    exit();
?>