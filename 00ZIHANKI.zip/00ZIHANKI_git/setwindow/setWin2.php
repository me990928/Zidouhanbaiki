<?php
  date_default_timezone_set('Asia/tokyo');

  // error_reporting(0);


  if($_COOKIE['userClass']!=="1" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+1);
    header('location: ./back.php');
  }
  // var_dump($_POST['stock']);

  require './php/escape.php';

  require './php/class/db.php';

  require './php/class/sysClass.php';

  require './php/item/itemsClass.php';

  $itemObj = new Items();

  $sysObj = new SysTxt();


  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    $list = $itemObj->AlldispItemsId();


    // var_dump($itemObj);     // デバック用

    // echo "成功";

  }else{
    // echo "エラー";
  }


  // if($sysObj->conn()){     // DB実行準備

  //   $dbConn = $sysObj->getDb();  // DB実行

  //   if (isset($_POST['stock']) && $_POST['msg_s']==='org') {
  //     $sysObj->setTextS($_POST['stock']);
  //     $sysObj->setDbStocktxt($_POST['msg_s']);
  //   }elseif ($_POST['msg_s']==='def'){
  //     $sysObj->setDbStocktxt($_POST['msg_s']);
  //   }

  //   if(isset($_POST['zyunbi']) && $_POST['msg_z']==='org'){
  //     $sysObj->setTextZ($_POST['zyunbi']);
  //     $sysObj->setDbZyunbitxt($_POST['msg_z']);
  //   }elseif($_POST['msg_z']==='def'){
  //     $sysObj->setDbZyunbitxt($_POST['msg_z']);
  //   }

  // }else{
  //   echo "エラー";
  // }

  // echo "<br>";
  // $sysObj->viewAllDisp($sysObj->getTextZ());


?>
<!DOCTYPE html>

<html lang="ja">

  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <!-- <script defer type="text/javascript" src="js/ajax.js"></script> -->
    <script defer type="text/javascript" src="js/ajax-registMsg.js"></script>
    <script defer type="text/javascript" src="js/ajax-logout.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>

  </head>

  <body>

    <main class="content">

      <div id="infoBar">
        <p class="black">
          <?= date("Y-m-d") ?>
        </p>
      </div>
      
      <div id="contents">

        <!-- <form method='get' action='#'><h1>商品状態情報メッセージ設定</h1>
          <h3>在庫確認用メッセージ：<input type='checkbox' name='' checked> 有効</h3>
          <textarea rows='10' cols='35' placeholder='メッセージを入力してください'></textarea>
          <h3>商品準備中用メッセージ：<input type='checkbox' name='' checked> 有効</h3>
          <textarea rows='10' cols='35' placeholder='メッセージを入力してください'></textarea><br>

        <h3 class="red">↑自販機の販売不可字のメッセージを設定できます<br>有効にチェックがない場合はデフォルトのメッセージが採用されます</h3>

          <section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section>
        </form> -->

        <form id="msgForm" method="post" style="margin-top: 50px;">
          <h1>商品の在庫がない時のメッセージ</h1><br>
          デフォルトメッセージ：<input type="radio" name="msg_s" value="def" checked><br>
          オリジナルメッセージ：<input type="radio" name="msg_s" value="org"><br>
          <textarea id="stock" name="stock" style="margin-bottom: 10px;"><?= $sysObj->viewAllDisp($sysObj->getTextS()); ?></textarea><br>
          <h1 style="margin-top: 50px;">商品の在庫が全て準備中の時のメッセージ</h1><br>
          デフォルトメッセージ：<input type="radio" name="msg_z" value="def" checked><br>
          オリジナルメッセージ：<input type="radio" name="msg_z" value="org"><br>
          <textarea id="zyunbi" name="zyunbi" style="margin-bottom: 10px;"><?= $sysObj->viewAllDisp($sysObj->getTextZ()); ?></textarea><br>
          <!-- <input type="submit" value="send" name=""> -->
          <section><a class='btn_03' id="registMsg">SEND</a></section>
        </form>

        <!-- <section><a href='../../index_0.html' class='btn_03' onclick='document.a_form.submit();'>LOGOUT</a></section> -->



        <form method="post" id="cpnForm">

          <h1>クーポン追加</h1><br>


              対象商品 : <select id="itemIdc" name="itemId" style="width: 200px;" required>
                <option>商品を選択してください</option>
                <?php
                  $num=count($list);
                  for ($i=0; $i < $num; $i++) { 
                    echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
                  }
                ?>
              </select><div id="erridc" class="red"></div><br>
              開始日：<input id="stdc" type="date" name="std" value="<?= date("Y-m-d") ?>" required><div id="errstdc" class="red"></div><br>
              終了日：<input id="efdc" type="date" name="efd" required><div id="errefdc" class="red"></div><br>
              割引額：<input id="disc" type="number" name="dis" required> 円<div id="errdisc" class="red"></div><br>
              <input type="hidden" name="flag" value="1">
              <!-- <input type="submit" name="" value="send"> -->

              <div id="cpnDbug"></div>

              <section><a class='btn_03' id="couponBtn">SEND</a></section>


        </form>



        <!-- <h3 class="red logOut">ログアウトすることで自販機画面に戻ります</h3> -->

        <form method="post" id="logoutForm" style="padding-bottom: 500px;">
          <input type="hidden" id="outPram" name="logout" value="true" >
          <section><a class='btn_03' id="logoutBtn">LOGOUT</a></section>
        </form>

      </div>
      
      <!-- <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin1.html" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin2.html" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin3.html" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin4.html" id="item4">menu</a>
          </span>
        </div>

      </div> -->

      <?php

      require 'footer.php';

      ?>

    </main>

  </body>
</html>