<?php

  // require '../class/db.php';

  class Items extends Db{
      protected $itemName;
      protected $itemPrice;
      public $iteminfo = "";
      protected $itemPict;
      public $itemTip ="";
      protected $mateName;
      protected $matePict;
      protected $Material1;
      protected $Material2;
      public $flagMates = false;

      public function AlldispItemsId(){
        // 商品一覧取得

        $data = $this->db->query('select f_item_id, f_item_name from t_items');
      
        $list = $data->fetchAll( PDO::FETCH_ASSOC );

        return $list;

      }

      // 材料登録
    public function setMaterial($arg){
      $rows = $this->db->query('select count(*) from t_materials');

      $row = $rows->fetch();

      var_dump($row);

      $smtp = $this->db->prepare("insert into t_materials(f_material_id,f_material_name,f_material_key) values(:id,:name,:key)");

      $val0 = htmlspecialchars($arg[0], ENT_QUOTES);
      $val1 = htmlspecialchars($arg[1], ENT_QUOTES);

      $strId = $row[0];
      $strName = $val0;
      $strKey = $val1;

      $smtp->bindParam(":id",$strId,PDO::PARAM_INT);
      $smtp->bindParam(":name",$strName,PDO::PARAM_STR);
      $smtp->bindParam(":key",$strKey,PDO::PARAM_STR);

      $smtp->execute();

      return $this->flagMates = true;
    }

      // 材料リスト
    public function getMaterialList(){
      $data = $this->db->query('select * from t_materials');
      
      $list = $data->fetchAll( PDO::FETCH_ASSOC );

      return $list;
    }

      // 材料数
    public function getMaterialNum(){

      $data = $this->db->query("select count(*) as '0' from t_materials");

      $num = $data->fetchAll(PDO::FETCH_ASSOC);

      return $num;

    }

      //商品情報
    public function setItemInfo($arg){

      // ファイル作成

      $fileName = $arg[0].".txt";

      $fileNameDir = "./text/";

      if(!file_exists($fileNameDir.$fileName)){
        touch($fileNameDir.$fileName);
      }else{
        $i=0;
        while(file_exists($fileNameDir.$i.$fileName)){
          $i++;
        }
        touch($fileNameDir.$i.$fileName);
      }

      if(isset($i))
        $fileName = $i.$fileName;

      file_put_contents($fileNameDir.$fileName, $arg[1]);

      // テキスト登録

      $namQuery = $this->db->query("select count(*) as '0' from t_items_info");

      $num = $namQuery->fetchAll(PDO::FETCH_ASSOC);

      $data = $this->db->prepare('insert into t_items_info (f_item_info_id, f_item_info_key) values(:id, :key)');

      $st = mb_strlen($num[0][0]);

      $st = 3 - $st;

      $st0 = null;

      for ($i=0; $i < $st; $i++) { 
        $st0 = $st0."0";
      }

      $id = "IM".$st0.$num[0][0];
      $key = $arg[0];

      $data->bindParam(":id",$id,PDO::PARAM_STR);
      $data->bindParam(":key",$key,PDO::PARAM_STR);

      $data->execute();

      $this->iteminfo = $id;

      return $this->iteminfo;

  }

  public function setTipInfo($arg){

      $fileName = $arg[0].".txt";

      $fileNameDir = "./tip/";

      if(!file_exists($fileNameDir.$fileName)){
        touch($fileNameDir.$fileName);
        $key = $arg[0];
      }else{
        $i=0;
        while(file_exists($fileNameDir.$i.$fileName)){
          $i++;
        }
        touch($fileNameDir.$i.$fileName);
        $key = $i.$arg[0];
      }

      if(isset($i))
        $fileName = $i.$fileName;

      file_put_contents($fileNameDir.$fileName, $arg[1]);

      // テキスト登録

      $namQuery = $this->db->query("select count(*) as '0' from t_tips_info");

      $num = $namQuery->fetchAll(PDO::FETCH_ASSOC);

      $data = $this->db->prepare('insert into t_tips_info (f_tip_info_id, f_tip_info_key) values(:id, :key)');

      $st = mb_strlen($num[0][0]);

      $st = 3 - $st;

      $st0 = null;

      for ($i=0; $i < $st; $i++) { 
        $st0 = $st0."0";
      }

      $id = "TM".$st0.$num[0][0];

      $data->bindParam(":id",$id,PDO::PARAM_STR);
      $data->bindParam(":key",$key,PDO::PARAM_STR);

      $data->execute();

      $this->itemTip = $id;

      return $this->itemTip;

  }

  public function setItemPict($name,$key){
    $stmt = $this->db->prepare('insert into t_items_picts (f_item_pict_name,f_item_key) values(:name, :key) ');

    $stmt->bindParam(":name",$name,PDO::PARAM_STR);
    $stmt->bindParam(":key",$key,PDO::PARAM_STR);

    $stmt->execute();

  }



  public function setItems($arg){
    echo "<br>";
    echo "<br>";
    echo "<br>";
    print_r($arg);
    echo "<br>";
    echo "<br>";
    echo "<br>";

    $stmt = $this->db->query("select f_item_pict_id as 'pictId' from t_items_picts where f_item_key = '".$arg[6]."'");

    $pictId = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "<br>";
    echo "<br>";
    echo "<br>";
    var_dump($pictId);
    echo "<br>";
    echo "<br>";
    echo "<br>";


    unset($stmt);


      $namQuery = $this->db->query("select count(*) as '0' from t_items");

      $num = $namQuery->fetchAll(PDO::FETCH_ASSOC);

      $st = mb_strlen($num[0][0]);

      $st = 3 - $st;

      $st0 = null;

      for ($i=0; $i < $st; $i++) { 
        $st0 = $st0."0";
      }

      $id = "MC".$st0.$num[0][0];

      echo "<br>".$num[0][0]."<br>";


      $ext1 = explode("-",$arg[4]);
      $ext2 = explode("-",$arg[5]);

      $namQuery = $this->db->query("select count(*) as '0' from t_materials_1");

      $MateNum = $namQuery->fetchAll(PDO::FETCH_ASSOC);

      $MateNum[0][0]--;

      $mate1 = $this->db->query("select f_material_1_id as '0' from t_materials_1 where f_material_1_id = ".$MateNum[0][0]." and f_material_id = ".$ext1[0][0]);

      $mate11 = $mate1->fetchAll(PDO::FETCH_ASSOC);

      echo "ここ→";var_dump($mate11);
      echo "ここ→";var_dump($ext2[0][0]);
      echo "ここ→";var_dump($MateNum[0][0]);

      $mate2 = $this->db->query("select f_material_2_id as '0' from t_materials_2 where f_material_2_id = ".$MateNum[0][0]." and f_material_id = ".$ext2[0][0]);

      $mate22 = $mate2->fetchAll(PDO::FETCH_ASSOC);



    $stmt = $this->db->prepare("insert into t_items (f_item_id,f_item_name,f_price,f_item_info_id,f_tip_info_id,f_material_1_id,f_material_2_id,f_item_pict_id,f_status_id) values 
      (:id,:name,:price,:info,:tip,:mate1,:mate2,:pict,1)");

    $stmt->bindParam(":id",$id,PDO::PARAM_STR);
    $stmt->bindParam(":name",$arg[0],PDO::PARAM_STR);
    $stmt->bindParam(":price",$arg[1],PDO::PARAM_INT);
    $stmt->bindParam(":info",$arg[2],PDO::PARAM_STR);
    $stmt->bindParam(":tip",$arg[3],PDO::PARAM_STR);
    $stmt->bindParam(":mate1",$mate11[0][0],PDO::PARAM_INT);
    $stmt->bindParam(":mate2",$mate22[0][0],PDO::PARAM_INT);
    $stmt->bindParam(":pict",$pictId[0]['pictId'],PDO::PARAM_INT);

    $stmt->execute();

    echo "<br>"; 
    echo $id;   
    echo "<br>";
    echo $arg[0];    
    echo "<br>";
    echo $arg[1];    
    echo "<br>"; 
    echo $arg[2];   
    echo "<br>";  
    echo $arg[3];  
    echo "<br>";
    echo $mate11[0][0]."P";    
    echo "<br>";
    echo $mate22[0][0]."P";
    echo "<br>";    
    echo $pictId[0]['pictId']."P";
    echo "<br>";    



  }

   public function setMaterialSub($arg1,$arg2){
      $ext1 = explode("-",$arg1);
      $ext2 = explode("-",$arg2);


      $namQuery = $this->db->query("select count(*) as '0' from t_materials_1");

      $num = $namQuery->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $this->db->prepare("insert into t_materials_1 (f_material_1_id, f_material_id) values(:id,:key)");
    $stmt->bindParam(":id",$num[0][0],PDO::PARAM_INT);
    $stmt->bindParam(":key",$ext1[0],PDO::PARAM_STR);
    $stmt->execute();

    unset($stmt);

    $stmt = $this->db->prepare("insert into t_materials_2 (f_material_2_id, f_material_id) values(:id,:key)");
    $stmt->bindParam(":id",$num[0][0],PDO::PARAM_INT);
    $stmt->bindParam(":key",$ext2[0],PDO::PARAM_STR);
    $stmt->execute();
   }

  }

?>