<?php
  error_reporting(0);
  require '../setwindow/php/escape.php';
  require '../setwindow/php/class/db.php';
  require '../setwindow/php/item/itemsClass.php';
  require 'infoClass.php';
  require '../setwindow/php/class/couponClass.php';

  // タイムゾーン設定
  date_default_timezone_set('Asia/tokyo');

  $cpnObj = new Cpon();

  if($cpnObj->conn()){     // DB実行準備

    unset($data);    

    $dbConn = $cpnObj->getDb();  // DB実行

    // var_dump($cpnObj);     // デバック用

    $list = $cpnObj->getCouponList();

    // $cpnList = $cpnObj->$cpnList;
    $i = 0;
    foreach ($list as $value) {
      // print_r($value);echo "<br>";
      $arg[0] = $value[1];
      $cpnObj->getInfo($arg);
      $data = $cpnObj->outItemData();
      // print_r($data);echo "<br>";

      $price = $data['itemPrice']-$value[4];
       
      $stDate = date('n月j日', strtotime($value[2]));
      $endDate = date('n月j日', strtotime($value[3]));


      // $dataの中身
      // data[0]= クーポンID
      // data[1]= 商品名
      // data[2]= 割引後の価格

      $userId = "yuya";

      $cpnArr[0]=$value[0];
      $cpnArr[1]=$data['itemPrice'];
      $cpnArr[2]=$price;

      // var_dump($cpnArr);

      $arg = [$userId,$cpnArr[0]];
      // couponClassよりaddCouponメソッドで使用する配列
      // data->'クーポンID'

      // クーポン発行メソッド
      $cp = $cpnObj->createCode();  // couponClass.phpよりクーポンコード生成メソッド
      // $cpnObj->addCoupons($arg);  // couponClass.phpよりユーザ宛クーポン発行

      $date = date('Y-m-d');

      if($date>=$value[2] && $date<=$value[3]){

      echo "
            <form name='form$i' method='get' style='margin-bottom: 50px;'>
            <div class='box shadow'>
              <div class='items'>
                <img class='f-shadow itemImg' src='../setwindow/php/act/imgItemOri/{$data['pict']}.png' alt='商品：Dr.Pepper'>
              </div>
              <div class='infoBox'>
                <div class='couponDay'><span class='red'>{$endDate}</span>まで</div>
                <div class='itemName'>{$data['itemName']}</div>
                <div class='itemValue'><span class='under_line red'>{$data['itemPrice']}円</span> → {$price}円</div>
              </div>
                <input type='hidden' value='{$value[0]}'>
                <input type='hidden' value='{$data['itemPrice']}'>
                <input type='hidden' value='$price'>

                <section class='useCouponTxt'><a href='useCoupon.php?id=$value[0]&price={$data['itemPrice']}&dis=$price&name={$data['itemName']}&pict={$data['pict']}&cp=$cp&stdate=$stDate&enddate=$endDate&dispar={$value[4]}&itemid={$value[1]}' class='btn_03' onclick='fnClick$i();'>このクーポンを使う</a></section>
            </div>
            ";
            $i++;

          }else{

          }
    }

    // var_dump($list);

    // $arg[0]="MC002";

    // $cpnObj->getInfo($arg);

    // $data = $cpnObj->outItemData();

    // print_r($cpnObj->items);

    // error_reporting(-1);

    $list = $cpnObj->AlldispItemsId();

    $flag = 1;

  }else{
    echo "エラー";
  }


?>