<?php
  // 共通部分の定義
  
  if($_POST['addKey']=="materials"){ 
    $IMG_DIR = "imgMateOri";       // imagesフォルダのdir
    $IMG_DIR_SL = "./imgMateOri/";   // imagesフォルダのdir
    $THUM_DIR = "imgMateThum";       // thumフォルダのdir
    $THUM_DIR_SL = "./imgMateThum/";   // thumフォルダのdir
    $IMG_NEW_WIDTH = 500;    // 新しい横幅
    $IMG_NEW_HIGHT = 700;    // 新しい縦幅
  }elseif ($_POST['addKey']=="items") {
    $IMG_DIR = "imgItemOri";       // imagesフォルダのdir
    $IMG_DIR_SL = "./imgItemOri/";   // imagesフォルダのdir
    $THUM_DIR = "imgItemThum";       // thumフォルダのdir
    $THUM_DIR_SL = "./imgItemThum/";   // thumフォルダのdir
    $IMG_NEW_WIDTH = 150;    // 新しい横幅
    $IMG_NEW_HIGHT = 700;    // 新しい縦幅
  }

?>