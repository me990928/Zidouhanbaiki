<?php

  require '../setwindow/php/escape.php';
  require '../setwindow/php/class/db.php';
  require '../setwindow/php/item/itemsClass.php';
  require '../axios/infoClass.php';
  require '../setwindow/php/class/couponClass.php';
  require '../setwindow/php/class/rankingClass.php';


  // タイムゾーン設定
  date_default_timezone_set('Asia/tokyo');

  $rnkObj = new Rank();

  $infObj = new Info();

  if ($rnkObj->conn()) {

        $dbConn = $rnkObj->getDb();  // DB実行
        $infObj->conn();
        $dbConn1 = $infObj->getDb();  // DB実行

        $rnkData = $rnkObj->getRank();

        // var_dump($rnkData);
        $i = 0;
        foreach ($rnkData as $value){
            if($i<3){
            $arg[0]=$value[0];
            $itemData1 = $infObj->getInfo($arg);
            $itemData2[] = $infObj->outItemData();
            }
            $i++;
          }


        // foreach ($itemData2 as $value) {
        //   // code...
        //   print_r($value);echo "<br>";
        // }

        $ranking = "<style type='text/css'>
  body{
    background-color: rgb(54, 54, 54);
  }

  .rankBox{
    display: flex;
    align-items: center;
    justify-content: center;
/*    border: 1px solid aqua;*/
    border-top: 0.5px solid aqua;
    border-left: 0.5px solid aqua;
    border-right: 0.5px solid aqua;
    width: 600px;
    color: white;
  }

  .rankingtitleBox{
    height: 50px;
    font-size: 1.5rem;
  }


  .rankBox div{
    margin: 40px;
    text-align: center;
    font-size: 2rem;
  }

  .rankBox img{
    width: 100%
  }
</style>
            <div>
              <div class='rankBox rankingtitleBox'>人気ランキング！</div>
              <div class='rankBox'>
                <div style='width: 70px;'>1位</div>
                <div style='width: 200px;'>{$itemData2[0]['itemName']}</div>
                <div style='width: 50px;'><img src='../setwindow/php/act/imgItemOri/{$itemData2[0]['pict']}.png'></div>
              </div>
              <div class='rankBox'>
                <div style='width: 70px;'>2位</div>
                <div style='width: 200px;'>{$itemData2[1]['itemName']}</div>
                <div style='width: 50px;'><img src='../setwindow/php/act/imgItemOri/{$itemData2[1]['pict']}.png'></div>
              </div>
              <div class='rankBox' style='border-bottom: 1px solid aqua;'>
                <div style='width: 70px;'>3位</div>
                <div style='width: 200px;'>{$itemData2[2]['itemName']}</div>
                <div style='width: 50px;'><img src='../setwindow/php/act/imgItemOri/{$itemData2[2]['pict']}.png'></div>
              </div>
            </div>
        ";

        echo $ranking;

  }

?>
