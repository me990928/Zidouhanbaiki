<?php

  $price_json = file_get_contents('./json/priceFlag.json');
  $jsondataprice = json_decode($price_json,true);

  $jsondataprice["0"]=1;
  $jsondataprice["1"]=true;
  $jsondataprice["2"]=0;

  $json = json_encode($jsondataprice);
  $bytes = file_put_contents("./json/priceFlag.json", $json);



?>