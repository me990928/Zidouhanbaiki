<?php
  require '../escape.php';

  error_reporting(0);


  if($_COOKIE['userClass']=="2" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+10,'/');
    header('location: ../user/loginPage.php');
  }

  error_reporting(-1);

  // var_dump($_COOKIE);
  var_dump($_POST);

  require './itemsClass.php';

  $itemObj = new Items();

  $userID = "root";       // ユーザIDがrootではないなら変更する
  $itemObj->setUserid($userID);

  $pass = "root";         // パスワードがrootではないなら変更する
  $itemObj->setPass($pass);

  $port = "3306";         // ポートが3306ではないなら変更する
  $itemObj->setPort($port);

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    echo "成功";

  }else{
    echo "エラー";
  }



  if($_POST['addKey']=='materials'){
    // addMaterials
    $upFile = $_FILES['f_material_key'];
    $ext = explode(".",$upFile["name"]);

    $materials[0] = $_POST['f_material_name'];
    $materials[1] = $ext[0];  // <-ここ対処


      // require 'pictResizeH.php';
      require 'pngResizeH.php';

    $itemObj = $itemObj->setMaterial($materials);
    }

  // materials all data

  if($_POST['addKey']=='items'){
    $itemData[0]=$_POST['f_item_name'];
    $useData[0]=$_POST['f_item_name']; //item name
    $useData[1]=$_POST['f_price'];  //item price
    $itemData[1]=$_POST['f_item_info_id'];
    $itemData[2]="1";
    $useData[2] = $itemObj->setItemInfo($itemData); //info id
    unset($itemData[1]);


    $itemData[1]=$_POST['f_tip_info_id'];
    $useData[3] = $itemObj->setTipInfo($itemData);  // tip id
    unset($itemData);

    $useData[4]=$_POST['f_material_1_id'];  // material 1
    $useData[5]=$_POST['f_material_2_id'];  // material 2


    $upFile = $_FILES['itemPict'];
    $ext = explode(".",$upFile["name"]);

    $itemData[0] = $_POST['f_item_name'];
    $itemData[1] = $ext[0];  // <-ここ対処

    $useData[6] = $itemData[1]; // pict_key

    // require 'pictResizeW.php';
    require 'pngResizeW.php';

    $itemObj->setMaterialSub($useData[4],$useData[5]);

    $itemObj->setItemPict($itemData[0],$itemData[1]);

    $itemObj->setItems($useData);


  }

  // var_dump($useData);

  // var_dump($_FILES);

  var_dump($_POST);
?>
