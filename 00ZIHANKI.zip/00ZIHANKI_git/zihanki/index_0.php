<?php
    header('Cache-Control: no-store');

    require './zyunbi.php';

    require './testmode.php';

    require './getlogs.php';
    require './getQRbox.php';
    require './getSNStitle.php';

    require './js/wether.php';

?>

<!DOCTYPE html>
<html lang="ja">
<head>
<title>aQure プロトタイプ 在庫あり</title>
<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="zihanki.css">
<link rel="stylesheet" href="modal.css">
<link rel="stylesheet" href="modalBata.css">
<link rel="stylesheet" href="prot.css">
<link rel="stylesheet" href="mordal.css">
<link rel="shortcut icon" href="">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js" integrity="sha512-z4OUqw38qNLpn1libAN9BsoDx6nbNFio5lA6CuTp9NlK83b89hgyCVq+N5FdBJptINztxn1Z3SaKSKUS5UP60Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<!-- <script src="js/script.js?p=(new Date()).getTime()"></script> -->
<script src="js/index.js"></script>
<script src="js/textReader.js"></script>
<script src="js/ajax-zihanki.js"></script>
<!-- <script src="js/ajax-zihanki.js?p=(new Date()).getTime()"></script> -->
<script src="js/animezihanki.js"></script>
<script src="js/axios-getdrink.js"></script>
<script src="js/axios-onload.js"></script>
<script src="js/axios-getdrink.js?p=(new Date()).getTime()"></script>
<!-- <script defer type="text/javascript" src="modal.js"></script> -->

<script type="text/javascript">
    $(function () {
        var b = $('#set');

       var h = b.height()

        if(h<1250){
            $('#set').css('height','1250');
        }else{
            $('#set').css('height',h+50);

            $('#rightBox').css('height',h-200);
        }
    })

    
</script>

</head>
<!-- <body class="zoom"> -->
<body>

<div id="wall"></div>

<!--     <div id="modal-wrap" class='a'>
        <div id="modal-window">
            <div id="box">
                <div id="msg">商品名的何か<br>価格￥150</div>
                <div id="btn"><a id="objA" href="#">OK</a></div>
            </div>
        </div>
    </div>
 -->


    <!-- モーダル用スペース -->


<div class="mordal-back mordal-off">

        <!-- page 1 -->

        <div id="mordal-p1" class="mordal-off">
        
            <div id="price-win" style="padding: 10px">
                <div>商品名『<div style="display: inline-block;" class="d-title"></div>』</div>
                <div>価格　¥<span class="drinkPrice"></span></div>
                <span id="okBtnp1" class="btn">OK</span>
            </div>

            <div id="infoBar" style="padding: 10px">
                
                <div id="hukidashi-p1" class="balloon2-right hukidashi">

                    <div id="dinkTitle-p1" class="dinkTitle d-title"></div>

                    <div class="colBox textBox">
                        <div style="height: 250px"><img style="padding-left: 30px;" class="drinkImg" src="sozai/11drp.png"></div>
                        <!-- <div id="infoText" style="overflow-y: scroll; height: 200px; text-align: left;">
                        アメリカ合衆国においては、最も古い炭酸飲料水でありごくメジャーな飲み物として知られており、コンビニエンスストアやファーストフード店で流通している。
                        </div> -->
                        <div id="infoText" class="scrollbarNone" style="overflow-y: scroll; height: 200px; width: 400px; text-align: left;">
                            <!-- <object id="o-infoText" style="padding-left: 30px;" width="400px" height="100%" data="../setwindow/php/act/text/ペプシコーラ.txt" type="text/plain"></object> -->
                            <div id="o-infoText" style="padding-left: 30px;" width="400px" height="100%"></div>
                        </div>
                    </div>

                </div>
                <div class="charPict"><img src="sozai/char.png" alt="ナレーター"></div>
            </div>
        </div>

        <!-- page 2 -->

        <div id="mordal-p2" class="mordal-off">

            <div id="select-win" style="padding: 10px;">
                <div>『<span  class="d-title"></span>』を購入しますか？</div>
                <div>価格　¥<span class="drinkPrice"></span></div>
                <div style="margin-top: 15px">
                    <span id="okBtnp2" class="btn" style="margin-right: 150px;">YES</span>
                    <span id="okBtnp2" class="cansel btn-n btn m-rst">NO</span>
                </div>
            </div>

            <div id="tips-win"  style="padding: 10px">

                <div id="hukidashi-p2" class="balloon2-right hukidashi">

                    <div id="dinkTitle-p2" class="dinkTitle d-title">Dr.Pepper</div>

                    <div class="colBox textBox">
                        <div style="height: 250px;"><img style="padding-left: 30px;" class="drinkImg" src="sozai/11drp.png"></div>
                        <!-- <div id="tipsText" style="overflow-y: scroll; height: 200px; text-align: left;">
                         アメリカには本飲料を1日3本飲むおばあさんがいます。そのおばあさんは何人かの医者に飲むことをやめるよう言われたが、おばあさんはやめることはなかった。おばあさんは103歳のときにインタビューにこう答えました...
                        「今までに2人の医者が『ドクターペッパーを飲むのを止めろ、死ぬから』って言ったのよ。そしたら、彼らのほうが先に逝っちゃったわ」
                        </div> -->
                        <div id="tipsText" class="scrollbarNone" style="overflow-y: scroll; height: 200px; width: 400px; text-align: left;">
                            <!-- <object id="o-tipsText" style="padding-left: 30px;" width="400px" height="100%" data="../setwindow/php/act/text/ペプシコーラ.txt" type="text/plain" loading="lazy"></object> -->
                            <div id="o-tipsText" style="padding-left: 30px;" width="400px" height="100%"></div>
                        </div>
                    </div>

                </div>
              
                <div class="charPict"><img src="sozai/char.png" alt="ナレーター"></div>
            </div>

        </div>



    <!-- page 3 -->

    <div id="buy-win" class="buy-win-off">
        <div>
            <div>
                <h1>購入確認画面</h1>
                    <div id="containar-index3">
                        <img class="drinkImg"  id="item" src="./sozai/11drp.png">
                        <div>
                            <h2>商品名</h2>
                            <h3 class="d-title">Dr.Pepper</h3>
                            <h2>価格</h2>
                            <div><span id="priceOrder" class="drinkPrice"></span>円</div>
                        </div>
                        <div>
                            <h2>決済方法</h2>

                                <!-- <div id="containar-icon">
                                    <img class="icon" src="./sozai/kotu.png" alt="交通系IC">
                                    <img class="icon" src="./sozai/id.png" alt="idCard">
                                    <img class="icon" src="./sozai/mastar.png" alt="mastarCard">
                                    <img class="icon" src="./sozai/quick.png" alt="quickPay">
                                    <img class="icon" src="./sozai/apple.png" alt="applePay">
                                    <img class="icon" src="./sozai/money.png" alt="現金払い">
                                </div> -->
                            <div id="containar-icon">
                                    <input type="radio" name="kessaiSelect" id="1" value="1" form="buy"><label for="1"></label>
                                    <input type="radio" name="kessaiSelect" id="2" value="2" form="buy"><label for="2"></label>
                                    <input type="radio" name="kessaiSelect" id="3" value="3" form="buy"><label for="3"></label>
                                    <input type="radio" name="kessaiSelect" id="4" value="4" form="buy"><label for="4"></label>
                                    <input type="radio" name="kessaiSelect" id="5" value="5" form="buy"><label for="5"></label>
                                    <input type="radio" name="kessaiSelect" id="6" value="6" form="buy" checked><label for="6"></label>
                            </div>

                        </div>
                    </div>
                    <div><h3>クーポンコード：<input class="v-b" type="text" name="couponId" placeholder="A12ABCD10" style="width: 380px; height: 56px;" form="buy"></h3></div>

                    
                    
                <div style="margin-top: 100px; padding: 50px;">
                    <form id='buyForm' name="buyForm">
                        <input type="hidden" name="drinkBuy" id="drinkBuy">
                        <input type="hidden" name="tempBuy" id="tempBuy">
                    </form>
                    <form action="post" name="buy" id="buy"></form>
                    <span id="okBtnp2" class="btn orderBtn m-rst-y" style="margin-right: 150px;">YES</span>
                    <span id="okBtnp2" class="cansel btn-n btn m-rst">NO</span>
                </div>
                    
            </div>        
        </div>
    </div>

<!-- ex page -->

        <div id="mordal-ex" class="mordal-off mordal-ex">
        
            <div id="price-win" style="padding: 10px">
                <span id="okBtnp1" class="btn-ex-close btn">OK</span>
            </div>

            <div id="infoBar" style="padding: 10px">
                
                <div id="hukidashi-p1" class="balloon2-right hukidashi">

                    <!-- <div id="dinkTitle-p1" class="dinkTitle d-title"></div> -->

                        <div id="title-ex" style="width: 570px; height: 80px; font-size: 3rem;">在庫準備中</div>
                        <div id="msg-ex" class="scrollbarNone" style="overflow-y: scroll; width: 570px; height: 300px;">
                            <div id="res-ex" style="margin-top: 10px; margin-left: 20px; text-align: left;"></div>
                        </div>
                   

                </div>
                <div class="charPict"><img src="sozai/char.png" alt="ナレーター"></div>
            </div>
        </div>


        <div id="mordal-ex-1" class="mordal-off mordal-ex-1">
        
            <div id="price-win" style="padding: 10px">
                <span id="okBtnp1" class="btn-ex-close btn">OK</span>
            </div>

            <div id="infoBar" style="padding: 10px">
                
                <div id="hukidashi-p1" class="balloon2-right hukidashi">

                    <!-- <div id="dinkTitle-p1" class="dinkTitle d-title"></div> -->

                        <div id="title-ex" style="width: 570px; height: 80px; font-size: 3rem;">在庫不足</div>
                        <div id="msg-ex" class="scrollbarNone" style="overflow-y: scroll; width: 570px; height: 300px;">
                            <div id="res-ex-1" style="margin-top: 10px; margin-left: 20px; text-align: left;"></div>
                        </div>
                   

                </div>
                <div class="charPict"><img src="sozai/char.png" alt="ナレーター"></div>
            </div>
        </div>
</div>

    <!-- end -->

    <!-- mordal - cm -->

    <div id="mordal-cm" class="mordal-off">
        <div id="cm-win"><img src="sozai/11drp.png"></div>
    </div>

    <!-- end -->

    <!-- <div class="companyLogoBox"><h1 class="companyFont">KOTOBUKIYA</h1></div> -->
    <div class="height"></div>
    <div class="companyLogoBox" style="position: relative;"><div id="time"></div><?= $weatherDisp ?><h1 class="companyFont"><?= $logo ?></h1></div>
    

    <style type="text/css">
        .drinkCont{
              display: grid;
              grid-template-columns: repeat(<?= $brPosi[0][0] ?>, 1fr);
              grid-gap: 10px 10px;
        }


      #time{
        background: gray;
        color: white;
        font-family: ヒラギノ角ゴシック;
        padding: 9px 15px;
        width: 155px;
        text-align: left;
        border-radius: 15px;
        position: absolute;
        top: 65;
        left: 15;
      }
    </style>

    <div id="zihankiWrap" class="midole">

        <div id="set" class="containar drinkCont">

            <!-- idには商品IDがくる -->

            <!-- <div id="1" class="data-obj select-hot linkbox">
                <div class="drink">
                    <img class="toggle" src="./sozai/11anko.png" alt="商品">
                    <div class="info-obj hot">🔥¥120</div>
                </div>
                <a class="links" href="index_1.html"></a>
            </div> -->
            
            <?php

                    // var_dump($brPosi[0][0]);

                    $s = 1;
                    $e = 0;
                    $b = $brPosi[0][0];

                for ($i=0; $i < $laySum; $i++) { 
                    // echo ($i-1)/$c;
                    if($s==1){
                        // echo "<div class='divecho'>";
                    }

                    echo $beta[$i];


                    if($s==$b){
                        // echo "</div>";
                        $s = $e;
                    }

                    $s++;
                }

            ?>

        </div>
        
        <div id="rightBox">
            <div id="infoBox">
                <!-- <h1 id="moneyH1">投入金額：　&nbsp;&nbsp;&nbsp;0円</h1> -->
                <div style="display: flex; justify-content: space-between; white-space: nowrap;"><h1 class="moneyH1">投入金額：</h1><h1 id="moneyH1" class="moneyH1">0円</h1></div>
                <h3 id="moneyH3">お釣りの不足はありません</h3>
            </div>

            <div id="cuponBox" class="linkbox">
                <h1><?= $QRtitle ?></h1>
                <a href="../qouponSite/index.html" class="link">
                <img src="../<?= $QRpict ?>" style="display: block;">
                </a>
            </div>

            <div id="snsBox" class="sns11">
                <h1><?= $SNStitle ?></h1>
                <a class="twitter-timeline" data-lang="ja" data-width="300" data-height="600" data-theme="dark" href="https://twitter.com/zihanki03070928?ref_src=twsrc%5Etfw">Tweets by zihanki03070928</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>
            
        </div>

    </div>

    <div id="testBtn">
    	<button id="sumBtn">合計確認</button>
    	<button id="resetBtn">リセット</button>
    	<button id="tenBtn">10円</button>
    	<button id="fifBtn">50円</button>
        <button id="onehBtn">100円</button>
        <button id="thouBtn">1000円</button>
    </div>
    <!-- <p class="white msgDeng">商品を選択する際は商品画像の範囲外をクリックしてください<br>ページ下のボタンで自販機の状態を変更できます<br>
    QRコードをクリックすることで、クーポンサイトに遷移します
    </p> -->

    <!-- <input type="text" name="" id="i-title" value="noName"> -->

<!-- <div id="inputBox" style="display: none; height: 0px;"> -->
<div id="inputBox" style="color: rgb(54, 54, 54)">
</div>
<div id="animeScript" style="color: rgb(54, 54, 54)">
</div>
<div id="debag" style="color: rgb(54, 54, 54)">
</div>
<div id="zunScript" style="color: rgb(54, 54, 54)">
    <?php

        error_reporting(0);

        // var_dump($zyunbiCond);

        foreach($zyunbiCond as $val){
            print_r($val);
            echo "<br>";
        }

        foreach ($zyunbiCond as $val) {

            $z = rand();

            $zTime = ($val[4] - $val[3]) * 60 * 1000;

            // $val[]

            echo "
                <script type='text/javascript'>
                  let zun1$z = document.querySelectorAll('.{$val[0]}-{$val[1]}.select-zun');
                  let zun2$z = document.querySelectorAll('.{$val[0]}-{$val[1]}.zun');

                  setTimeout(()=>{
                    zun1$z.forEach(function (element) {
                        element.classList.remove('select-zun');
                        element.classList.add('select-cool');
                        zun2$z.forEach(function(element){
                            element.classList.remove('zun');
                            element.classList.add('cool');
                        })
                    });

                  },$zTime)
                </script>
            ";
        }

        error_reporting(-1);
    ?>
</div>
</body>
</html>
