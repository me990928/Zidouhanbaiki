<?php
  require '../escape.php';

  error_reporting(0);


  if($_COOKIE['userClass']=="2" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+10,'/');
    header('location: ../user/loginPage.php');
  }

  error_reporting(-1);

  require './itemsClass.php';

  $itemObj = new Items();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

  }else{
    echo "エラー";
  }

  $list = $itemObj->getMaterialList();

  $num = $itemObj->getMaterialNum();

  // var_dump($_COOKIE);

?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <main>
    
    <form method="post" action="addItemsPage.php" enctype="multipart/form-data">
      <h1>addItemsForm</h1>
      f_item_name   :<input type="text" name="f_item_name" required><br>
      f_price       :<input type="number" name="f_price" required><br>
      f_item_info_id:<br>
      <textarea name="f_item_info_id" required></textarea><br>
      f_tip_info_id:<br>
      <textarea name="f_tip_info_id" required></textarea><br>
      f_material_1_id :<select name="f_material_1_id" required>
        <?php
          for ($i=0; $i < $num[0][0]; $i++) { 
            echo "<option>".$list[$i]['f_material_id']."-".$list[$i]['f_material_name']."</option>";
          }
        ?>
      </select><br>
      f_material_2_id :<select name="f_material_2_id" required>
        <?php
          for ($i=0; $i < $num[0][0]; $i++) { 
            echo "<option>".$list[$i]['f_material_id']."-".$list[$i]['f_material_name']."</option>";
          }
        ?>
      </select><br>
      f_item_pict_id  :<input type="file" name="itemPict" required><br>
      <!-- hiddenで値を送って商品追加判断 -->
      <input type="hidden" name="addKey" value="items">

      <input type="submit" name="" value="send">

    </form>

    <form method="post" action="addItemsPage.php" enctype="multipart/form-data">
      
      <!-- hiddenで値を送って材料追加判断 -->
      <input type="hidden" name="addKey" value="materials">
      <h1>addMaterialsForm</h1>
      f_marerial_name:<input type="text" name="f_material_name" required><br>
      f_marerial_Pict:<input type="file" name="f_material_key" required><br>
      <input type="submit" value="send" name="">

    </form>

  </main>
</body>
</html>