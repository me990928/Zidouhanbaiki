<?php

  require '../escape.php';

  error_reporting(0);


  if($_COOKIE['userClass']=="2" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+10,'/');
    header('location: ../user/loginPage.php');
  }

  if ($_COOKIE['msg']==='Success') {
    echo '<span style=\'color: red;\'>'.$_COOKIE['msg'].'</span>';
    setcookie('msg','Success',time()-1000);
  }

  error_reporting(-1);

  // require './itemsClass.php';
  require './db_stock_register_class.php';

  $itemObj = new Stock();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

    $list = $itemObj->AlldispItemsId();

  }else{
    echo "エラー";
  }

  // print_r($list);

?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <main>
    
    <form method="post" action="add_stock_register.php">

      Select item : <select name="itemId" style="width: 200px;" required>
        <?php
          $num=count($list);
          for ($i=0; $i < $num; $i++) { 
            echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
          }
        ?>
      </select><br>
      Preparation time : <input type="number" name="time" placeholder="Time" max="120" min="0" style="width: 100px;" required><br>
      temp : <input type="number" name="temp" placeholder="items Temp" max="100" min="5" style="width: 100px;" required><br>
      stock : <input type="number" name="stock" placeholder="stock" max="100" min="1" style="width: 100px;" value="1" required><br>

      <input type="submit" name="" value="send">

    </form>

    <br>

    <button onclick="location.href='./db_stock_list.php'">StockList</button><br>

  </main>
</body>
</html>