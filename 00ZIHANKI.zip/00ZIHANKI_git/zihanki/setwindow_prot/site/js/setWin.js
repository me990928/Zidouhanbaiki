let setChg1 = document.getElementById("item1");
let setChg2 = document.getElementById("item2");
let setChg3 = document.getElementById("item3");
let setChg4 = document.getElementById("item4");

let winCont = document.getElementById("contents");

setChg1.addEventListener('click',function (e){
  e.preventDefault();
  winCont.innerHTML = 
            "<form method='get' action='#'><h1>商品追加</h1><h3>商品名</h3><input type='text' name='itemName'><br><h3>販売価格</h3><input type='text' name='itemCost'><br><h3>商品情報：<input type='checkbox' name=''>有効にする</h3><textarea rows='10' cols='35'></textarea><h3>お役立ち情報：<input type='checkbox' name=''>有効にする</h3><textarea rows='10' cols='35'> </textarea><br><section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section></form>";
  });
setChg2.addEventListener('click', function (e) {
  winCont.innerHTML = "<form method='get' action='#'><h1>商品追加</h1><h3>在庫確認用メッセージ：<input type='checkbox' name='' checked> 有効</h3><textarea rows='10' cols='35' placeholder='メッセージを入力してください'></textarea><h3>お役立ち情報：<input type='checkbox' name='' checked> 有効</h3><textarea rows='10' cols='35' placeholder='メッセージを入力してください'></textarea><br><section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section></form>";
}); 
setChg3.addEventListener('click', function (e) {
  // boxObj.insertAdjacentHTML('beforeend', "<input type='number' id='widthBox' value='5' min='1' max='99'> マス</h3><h3>配置の有無</h3><div id='boxObj'></div><section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section></form><script defer type='text/javascript' src='js/setWin.js'")
  // winCont.innerHTML = "<form method='get' action='#'><h1>レイアウト設定</h1><h3>会社ロゴ：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3><h3>縦：<input type='number' id='heightBox' value='5' min='1' max='99'> マス</h3><h3>横：<input type='number' id='widthBox' value='5' min='1' max='99'> マス</h3><h3>配置の有無</h3><div id='boxObj'></div><section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section></form><script defer type='text/javascript' src='js/setWin.js'></script>";
  winCont.innerHTML = "<form method='get' action='#'><h1>レイアウト設定</h1><div class='setBox'><h3>会社ロゴ：<input type='file' name='logoFile' id='setFile' accept='image/*'></h3></div><div class='setBox'><h3>縦：<input type='number' id='heightBox' value='5' min='1' max='99'> マス</h3><h3>横：<input type='number' id='widthBox' value='5' min='1' max='99'> マス</h3></div><div class='setBox'><h3>配置の有無</h3></div><div id='boxObj'></div><section><a href='#' class='btn_03' onclick='document.a_form.submit();'>SEND</a></section></form> ";
});
setChg4.addEventListener('click',function (e){
  winCont.innerHTML = "";
});
// iphoneメニューバー延長対策

const setFillHeight = () => {
  const vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`);
  console.log(vh)
}

// 画面のサイズ変動があった時に高さを再計算する
window.addEventListener('resize', setFillHeight);

// 初期化
setFillHeight();

// レイアウト選択画面生成
// memo
// 後々、初期値をDBから取得して初期画面時に表示する
let boxObj = document.getElementById('boxObj');
let heightBox = document.getElementById('heightBox');
let widthBox = document.getElementById('widthBox');

// console.log(heightBox);

function layoutWin(){
  console.log(heightBox.value);
  boxObj.innerHTML = "";
  let cont = 1;
  for (let i = 0; i < heightBox.value; i++) {
    console.log(heightBox.value);
    cont = 1;
    for (let e = 0; e < widthBox.value; e++) {
      console.log(widthBox.value);
      boxObj.insertAdjacentHTML('beforeend', "<input type='checkbox' name='objBox' class='chkBox' value='' checked>");
      console.log(cont);
      cont++;
    }
    boxObj.insertAdjacentHTML('beforeend', '<br>');
  }
}

$(function () {

  $(document).on('change','input#heightBox',layoutWin);

});

$(function () {
  $(document).on('change', 'input#widthBox', layoutWin);
});

// 初期画面用
