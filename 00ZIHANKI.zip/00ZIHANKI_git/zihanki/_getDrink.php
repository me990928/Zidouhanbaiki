<?php
    
$request_body = file_get_contents('php://input'); //送信されてきたbodyを取得(JSON形式）
$jsonData = json_decode($request_body,true); // デコード

// debug($data['test']); //当たり前だけど連想配列です。


// $_POST['drink']=MC000;
echo "getDrink";

var_dump($_GET);

echo "getDrink";

require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';

    

  error_reporting(-1);

  $itemObj = new Info();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    $arg[0] = $_POST['drink'];

    $itemObj->getInfo($arg);

    $data = $itemObj->outItemData();

    $arg = '../setwindow/php/act/text/'.$data[3].'.txt';

    $text = $itemObj->getInfoText($arg);

    $arg = '../setwindow/php/act/tip/'.$data[4].'.txt';

    $text2 = $itemObj->getInfoText($arg);


    // var_dump($text);

  }else{
    // echo "エラー";
  }

  echo "ここ";
  var_dump($data);
  echo "ここ";


  echo count($text);

  $outInfo = null;

  // for ($i=0; $i < count($text); $i++) { 
  //   $outInfo .= $text[$i];
  // }

  $outTip = null;

  $tempFlag = $_POST['temp'];
  $drinkName = $_POST['drink'];


  // for ($i=0; $i < count($text2); $i++) { 
  //   $outTip .= $text2[$i];
  // }

  echo $outInfo;

  echo "
  <script type='text/javascript'>

  function settings(){
  var drinkTitle = document.querySelectorAll('.d-title');
  var drinkImg = document.querySelectorAll('.drinkImg');
  var drinkPrice = document.querySelectorAll('.drinkPrice');
  var infoTexta = document.getElementById('o-infoText');
  var TipText = document.getElementById('o-tipsText');
  var tempBuy = document.getElementById('tempBuy');
  var drinkBuy = document.getElementById('drinkBuy');

  // console.log(drinkTitle)

  for(var i in drinkTitle){
    drinkTitle[i].innerText = '{$data[1]}';
  }

  for(var i in drinkImg){
    drinkImg[i].src = 'sozai/{$data[7]}.png';
  }

  for(var i in drinkPrice){
    drinkPrice[i].innerText = '{$data[2]}';
  }

  //infoTexta.data = '../setwindow/php/act/text/{$data[3]}.txt';
  //TipText.data = '../setwindow/php/act/tip/{$data[4]}.txt';
  // infoTexta.innerText = '{$outInfo}';
  // TipText.innerText = '{$outTip}';
  tempBuy.value = 'tel';
  drinkBuy.value = '{$drinkName}';
}

// window.onload = settings();

  document.addEventListener('DOMContentLoaded',settings());

</script>
";

  // infoTexta.innerText = '{$outInfo}';
  // TipText.innerText = '{$outTip}';
  // infoTexta.data = '../setwindow/php/act/text/{$data[3]}.txt';
  // TipText.data = '../setwindow/php/act/tip/{$data[4]}.txt';
?>




