<?php

  class Cpn extends Db{
    
  }

?>