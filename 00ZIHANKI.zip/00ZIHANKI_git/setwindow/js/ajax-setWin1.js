$(function () {
    $('#mateBtn').on('click', function () {

        // GET
        // var strQuery = $('#fr_in').serialize();

        let name = $('#f_material_name').val();
        let key = $('#f_material_key').val();

        if(name === "" || key === ""){
            alert('記入漏れがあります');
            if (name === "") {
                $('#errName').html('入力してください');
            }
            if (key === "") {
                $('#errFile').html('選択してください');
            }
        }

        // POST
        let $form = $('#mateForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/mateAdd.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                // $('#mateDbug').(responce);
                alert('登録完了');
                console.log('a')
                document.itemForm.reset();
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                $('#mateDbug').html('ちーん（白目）');
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });
});

// ここから商品追加

$(function () {
    $('#itemBtn').on('click', function () {

        // GET
        // var strQuery = $('#fr_in').serialize();

        let name = $('#f_item_name').val();
        let price = $('#f_price').val();
        let info = $('#f_item_info_id').val();
        let tip = $('#f_tip_info_id').val();
        let mate1 = $('#f_material_1_id').val();
        let mate2 = $('#f_material_2_id').val();
        let pict = $('#itemPict').val();

        if(name === "" || price === "" || info === "" || tip === "" || mate1 === "----------" || mate2 === "----------" || pict === ""){
            alert('記入漏れがあります');
            if (name === "") {$('#errNamei').html('入力してください');}
            if (price === "") {$('#errPrice').html('入力してください');}
            if (info === "") {$('#errInfo').html('入力してください');}
            if (tip === "") {$('#errTip').html('入力してください');}
            if (mate1 === "----------") {$('#errMate1').html('選択してください');}
            if (mate2 === "----------") {$('#errMate2').html('選択してください');}
            if (pict === "") {$('#errPict').html('選択してください');}
        }

        // POST
        let $form = $('#itemForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/mateAdd.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                // $('#contents').after(responce);
                console.log('a')
                // var ary = responce.split('<br>');
                alert('登録完了');

            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });

    $('#stockBtn').on('click', function () {

        let itemId = $('#itemId').val();
        let time = $('#time').val();
        let temp = $('#temp').val();
        let stock = $('#stock').val();

        console.log(itemId);

        if(itemId == "商品を選択してください" || time === "" || temp === "" || stock === ""){
            alert('記入漏れがあります');
            if (itemId === "商品を選択してください") {$('#errId').html('入力してください');}
            if (time === "") {$('#errTime').html('入力してください');}
            if (temp === "") {$('#errTemp').html('入力してください');}
            if (stock === "") {$('#errStock').html('入力してください');}
        }

        // POST
        let $form = $('#stockerForm');
        var formData = new FormData($form.get(0));

        console.log('formData');

        $.ajax({
            url: './php/act/stockerAct.php',
            // type: 'GET',
            type: 'POST',
            async: true,
            // data: strQuery,
            data: formData,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#stokeFormDeback').html(responce);
                console.log('a')
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });


});

$(function () {
    $('#stockListBtn').on('click', function () {

        $.ajax({
            url: './php/act/stockerTable.php',
            // type: 'GET',
            // type: 'POST',
            async: true,
            // data: strQuery,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#mordalTitle').html('各種在庫合計表');
                $('#stockList').html(responce);
                console.log('やあ！（気さくな挨拶）')
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });

    
});

$(function () {
    $('#stockListBtn2').on('click', function () {

        $.ajax({
            url: './php/act/stockListTable.php',
            // type: 'GET',
            // type: 'POST',
            async: true,
            // data: strQuery,
            processData: false,
            contentType: false,
        })
            .done(function (responce) {
                $('#mordalTitle2').html('各種在庫表');
                $('#stockList2').html(responce);
                console.log('やあ！（気さくな挨拶）')
                // var ary = responce.split('<br>');
            })
            .fail(function (xhr) {
                $('#boxObj').html(xhr);
                console.log(xhr);
            })
            .always(function (xhr, msg) {
                // $('#boxObj').html($('#boxObj').html() + '<br>end:' + xhr);
                console.log('xhr');
                console.log(msg);
            });
    });

    
});

$(function() {
  $("#mordalBtn").click(function() {
    document.getElementById("mordal").classList.toggle("dispOn")
    document.getElementById("mordal").classList.toggle("dispOff")
    // document.getElementById("screen").classList.toggle("screenOn")
    document.getElementById("screen").classList.toggle("screenOff")
    document.getElementById("mordalBtn").classList.toggle("screenOn")
    document.getElementById("mordalBtn").classList.toggle("screenOff")
  });
});

$(function () {
  $('#stockListBtn').click(function(){
      $('#modalArea').fadeIn();
  });
  $('#closeModal , #modalBg').click(function(){
    $('#modalArea').fadeOut();
  });
});

$(function () {
  $('#stockListBtn2').click(function(){
      $('#modalArea2').fadeIn();
  });
  $('#closeModal2, #modalBg2').click(function(){
    $('#modalArea2').fadeOut();
  });
});



$(window).resize(function(){
    var w = $(window).width();
    var x = 568;
    if (w <= x) {
        document.getElementById("tableC").classList.toggle("small");
    } else {
        document.getElementById("tableC").classList.toggle("small");
    }
});







