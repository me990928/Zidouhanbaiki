<?php
  // error_reporting(0);
  // var_dump($_POST); echo "<br>";
  // var_dump($_COOKIE); echo "<br>";
  date_default_timezone_set('Asia/tokyo');

  require '../escape.php';
  require '../class/db.php';
  require '../class/userLogin.php';

  $userName = "Not Login !";

  if(isset($_COOKIE['userName'])){
    $userName = "welcome to <span style='color: blue;'>".$_COOKIE['userName']."</span> !";
  }

  if (isset($_COOKIE['errorClass'])) {
    $errClass = $_COOKIE['errorClass'];
  }

  if (!(isset($_COOKIE['loginFlag']))||$_COOKIE['userClass']=="0") {
    $inputUser = "<button onclick=\"location.href='userInput.php'\">userInput</button>";
  }

  // if ($_COOKIE['loginFlag']=="1"){
  //   $removeBtn = "<button onclick=\"location.href='userRemove.php'\">userRemove</button>";
  //   $dis = "disabled";
  // }

// var_dump($_COOKIE);
// var_dump($_POST);


  $loginObj = new userLogin();


  error_reporting(-1);

  $loginObj = new userLogin();

  if (isset($_POST['login'])) {
    $user[0] = $_POST['id'];
    $user[1] = $_POST['pass'];
    $loginObj->setLoginId($user[0]);
    $loginObj->setLoginPass($user[1]);

    $loginObj->testModule();

    if($loginObj->conn()){     // DB実行準備

      $dbConn = $loginObj->getDb();  // DB実行

      $loginObj->findAccount($user[0],$user[1]);  // 認証

      // echo "<span style=\"color:red;\"><br>＊userOptinが表示されていない場合は更新してください</span>";

    }else{
      // echo "エラー";
  }
  }


  // var_dump($_COOKIE);
  if(isset($_COOKIE['loginFlag'])){
    if($_COOKIE['loginFlag']==true){
      // echo "<br><button onclick=\"location.href='userOption_page0.php'\">userOptin</button>";
      // echo "<br><button onclick=\"location.href='userReinput.php'\">userReinput</button>";
    }
  }


  // echo "<br>".$removeBtn;

  if (isset($inputUser)) {
    // echo "<br>".$inputUser."ユーザ登録<br>";
  }

  // if ($_COOKIE['msg']!==null) {
    // echo "<br><span style='color: red;'>".$_COOKIE['msg']."</span>";
  // }


  if (isset($_GET['logout'])) {
    $loginObj->userLogout();
  }

  // if ($_COOKIE['loginFlag']==true) {
  //   echo "
  //     <script type='text/javascript'>
  //       setTimeout('link()', 0);
  //       function link(){
  //       location.href='./setWin1.php';
  //       }
  //       </script>
  //   ";
  //   exit();
  // }

  // var_dump($_COOKIE);

?>