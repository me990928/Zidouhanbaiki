$(function(){ 

        $('.box').on('click',function(){

        

        // if($(this).hasClass('select-not')){
        //   return;
        // }
        // if($(this).hasClass('select-zun')){
        //   return;
        // }


        let formId = '#'+$(this).children().next().next().attr('id')
        console.log(formId)

        let $form = $(formId);

        let query = $form.serialize();



            let params = {
                0: query
            }

            axios.post( 'axiosBack_getDrink.php', params, {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                // console.log(res)
                $('#inputBox').html(res.data);
            } );

            axios.post( 'mordalPage1.php', params, {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                // console.log(res)
                $('#o-infoText').html(res.data);
            } );

        $('#okBtnp1').on('click',()=>{
            axios.post( 'mordalPage2.php', params, {
              'Cache-Control': 'no-cache'
            } )
            .then( ( res ) => {
                // console.log(res)
                $('#o-tipsText').html(res.data);
            } );
        });
});


});
// 購入後の在庫処理にcssを切り替える



       