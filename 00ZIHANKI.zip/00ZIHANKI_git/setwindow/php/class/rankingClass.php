<?php

  /**
   * 
   */
  class Rank extends Cpon
  {
    
    public function getRank(){
      $stmt = $this->db->query("SELECT f_item_id,COUNT(*) FROM `f_buy_historys` GROUP BY f_item_id ORDER BY COUNT(*) DESC;");

      $data = $stmt->fetchAll( PDO::FETCH_NUM );

      return $data;
    }

  }

?>