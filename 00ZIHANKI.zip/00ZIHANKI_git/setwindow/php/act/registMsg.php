<input type="text" name="msg_s" value="org">
<input type="text" name="msg_s" value="org">

<?php


  require '../class/db.php';

  require '../class/sysClass.php';

  $sysObj = new SysTxt();

  if($sysObj->conn()){     // DB実行準備

    $dbConn = $sysObj->getDb();  // DB実行

    if (isset($_POST['stock']) && $_POST['msg_s']==='org') {
      $sysObj->setTextS($_POST['stock']);
      $sysObj->setDbStocktxt($_POST['msg_s']);
    }elseif ($_POST['msg_s']==='def'){
      $sysObj->setDbStocktxt($_POST['msg_s']);
    }

    if(isset($_POST['zyunbi']) && $_POST['msg_z']==='org'){
      $sysObj->setTextZ($_POST['zyunbi']);
      $sysObj->setDbZyunbitxt($_POST['msg_z']);
    }elseif($_POST['msg_z']==='def'){
      $sysObj->setDbZyunbitxt($_POST['msg_z']);
    }

  }else{
    echo "エラー";
  }

  echo "<br>";
  // $sysObj->viewAllDisp($sysObj->getTextZ());

  $msg_s = $_POST['stock'];
  $msg_z = $_POST['zyunbi'];

  echo "
    <script>$('#stock').val('$msg_s');</script>
    <script>$('#zyunbi').val('$msg_z');</script>
  ";

?>