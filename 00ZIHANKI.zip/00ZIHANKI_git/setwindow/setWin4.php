<?php
  date_default_timezone_set('Asia/tokyo');

  require './php/escape.php';




  // var_dump($_COOKIE);

  error_reporting(0);


  if($_COOKIE['userClass']!=="1" || !(isset($_COOKIE['userClass']))){
    setcookie("errorClass","Not class 'admin' !",time()+1);
    header('location: ./back.php');
  }

  error_reporting(-1);

  require './php/class/db.php';

  require './php/item/itemsClass.php';

  $itemObj = new Items();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    // var_dump($itemObj);     // デバック用

    // echo "成功";

  }else{
    // echo "エラー";
  }

  $list = $itemObj->AlldispItemsId();

  // $num = $itemObj->getMaterialNum();

  // var_dump($_COOKIE);

  require_once './php/act/selectBox.php';

?>

<!DOCTYPE html>

<html lang="ja">

  <head>

    <meta charset="utf-8">

    <title>名称未設定</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <link defer rel="stylesheet" type="text/css" href="css/reset.css">
    <link defer rel="stylesheet" type="text/css" href="css/common.css">
    <link defer rel="stylesheet" type="text/css" href="css/prot.css">
    <script defer type="text/javascript" src="js/setWin.js"></script>
    <!-- <script defer type="text/javascript" src="js/ajax.js"></script> -->
    <script defer type="text/javascript" src="js/ajax-logout.js"></script>
    <script defer type="text/javascript" src="js/ajax-setBox.js"></script>
    <script src="js/jquery-3.6.0.min.js"></script>


  </head>

  <body>

    <main class="content">

      <div id="infoBar">
        <p>
          <?= date("Y-m-d") ?>
        </p>
      </div>
      
      <div id="contents">

        <form id="cpnBoxForm" method='post' enctype="multipart/form-data">

          <h1>COUPON枠の設定</h1>
          <h3>タイトル：<input type='text' id="cuponTitle" name='cuponTitle' placeholder="CUPON配布中!!"></h3><div id="errTitleC" class="red"></div>
          <h3>QRコード（画像）：<input type='file' id="logoFile" name='logoFile' accept='image/*'></h3><div id="errQR" class="red"></div>
          <!-- <h3 class="red">↑QRコードを用いて別サイトに誘導する枠の設定（クーポンサイトやホームページを想定）</h3> -->

          <div id="cBoxDebug"></div>

          <section><a href='#' id="cpnBtn" class='btn_03'>SEND</a></section>

        </form>

        <form id="addCpn" method="post">
          <h1>クーポンの追加</h1>
          <h3>対象商品の選択</h3>
            <select  name='itemId'>
              <option>商品を選択してください</option>
              <?php
                $num=count($list);
                for ($i=0; $i < $num; $i++) { 
                 echo "<option value=".$list[$i]['f_item_id'].">".$list[$i]['f_item_id'].'-'.$list[$i]['f_item_name']."</option>";
                }
                // test($list.$number);
              ?>
            </select>

            <div id="selerr" style="color: red;"></div>
            <h3>有効期限</h3>
            開始日：<input type="date" name="std" value="<?= date("Y-m-d") ?>" required><br>
            終了日：<input type="date" name="efd" value="<?= date('Y-m-d', strtotime('+1 day'));  ?>" required><br>
            <h3>割引額</h3>
            <input type="number" name="dis">円

            <div id="priceErr" style="color: red;"></div>


          <section><a href='#' id="addCpnBtn" class='btn_03'>SEND</a></section>


        </form>

        <div id="aCpnDebug"></div>

        <form id="snsBoxForm" method='post' action='#'>

          <h1>SNS枠の設定</h1>
          <h3>タイトル：<input id="snsTitle" type='text' name='snsTitle' placeholder="SNSで共有しよう！"></h3><div id="errTitleS" class="red"></div>
          <h3>自販機コードの設定：</h3>
          <textarea id="story" name="story" rows="5" cols="33" placeholder="自販機コードを入力">ZI001</textarea><div id="errStoryS" class="red"></div><br>
          <!-- <h3 class="red">↑ SNSを表示する枠の設定（基本的にはSNSを表示する）</h3> -->

          <div id="sBoxDebug"></div>

          <section><a href='#' id="snsBtn" class='btn_03'>SEND</a></section>

        </form>

        <form id="cmForm" method='post' action='#'>

          <h1>CMの設定</h1>
          <h3>CM番号：<input id="cmnum" type="number" name="num" value="1" min="1" max="5" style="width: 50px;"></h3>
          <h3>CM画像：<input id="cmpict" type="file" name="file"></h3>

          <!-- <h3 class="red">↑ SNSを表示する枠の設定（基本的にはSNSを表示する）</h3> -->

          <div id="cmerr" style="color: red;"></div>


          <section><a href='#' id="cmBtn" class='btn_03'>SEND</a></section>

        </form>



          <!-- <section><a href='../../index_0.html' class='btn_03 logOut' onclick='document.a_form.submit();'>LOGOUT</a></section> -->

          <!-- <h3 class="red logOut">ログアウトすることで自販機画面に戻ります</h3> -->
          
        <form method="post" id="logoutForm" style="padding-bottom: 500px;">
          <input type="hidden" id="outPram" name="logout" value="true" >
          <section><a class='btn_03' id="logoutBtn">LOGOUT</a></section>
        </form>


      </div>
      
      <!-- <div id="menuBar">

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin1.html" id="item1">add</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin2.html" id="item2">edit_square</a>
          </span>
        </div>

        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin3.html" id="item3">grid_on</a>
          </span>
        </div>


        <div class="itemBox selector">
          <span class="material-symbols-outlined">
            <a href="setWin4.html" id="item4">menu</a>
          </span>
        </div>

      </div> -->

      <?php

      require 'footer.php';

      ?>

    </main>

  </body>
</html>