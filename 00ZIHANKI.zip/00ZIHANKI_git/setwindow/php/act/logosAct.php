<?php
  // require '../escape.php';

  require '../class/db.php';

  require '../item/itemsClass.php';

  require '../class/layoutClass.php';

  $layout = new Lay();

  if($layout->conn() ){     // DB実行準備

      $dbConn = $layout->getDb();  // DB実行

      // var_dump($_POST);
      // error_reporting(0);
      // var_dump($_FILES);

      $flag = glob('./logoPict/*');


      if (is_uploaded_file($_FILES['logoFile']['tmp_name'])) {
        error_reporting(-1);
        $upFile = $_FILES['logoFile'];

        $ext = explode('/', $upFile['type']);

        $data[0] = $ext[1];

        if($data[0]==='png'||$data[0]==='ping'||$data[0]==='jpeg'){
        }else{
          echo "<span style='color: red;'>拡張子を'png','ping','jpeg'にしてください";
          exit();
        }


        if ($_POST['LogoType'][0]==='pict') {
          if($layout->setPict($upFile)){
            echo "<span style='color: blue;'>画像のアップロードに成功しました<br></span>";
          }

          $data[1]=$upFile['name'];
          $data[2]='./setwindow/php/act/logoPict/'.$upFile['name'];

          $layout->setLog($data);
        }else{
        if (isset($flag)) {
          echo "<span style='color: #f75;'>画像ファイルの存在が確認できました<br></span>";
          exit();
        }
        echo "<span style='color: red;'>ファイルが見つかりませんでした</span>";
      }

      exit();

    }else{
      if($_POST['LogoType'][0]==='text'){
            // テキストアップロード処理
            $data[0] = "text";
            $data[1] = $_POST['logoName'];
            $data[2] = '';

            $layout->setLog($data);

            echo "<span style='color: blue;'>テキストの登録に成功しました<br></span>";

            exit();
          }
      echo "<span style='color: red;'>エラー</span>";
    }
}

?>