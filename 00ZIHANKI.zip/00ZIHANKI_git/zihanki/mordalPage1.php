<?php
require './getdrinkConf.php';
require '../setwindow/php/class/db.php';
require '../setwindow/php/item/itemsClass.php';
require '../setwindow/php/class/infoClass.php';
require '../setwindow/php/class/sysClass.php';

    

  error_reporting(-1);

  $itemObj = new Info();

  if($itemObj->conn()){     // DB実行準備

    $dbConn = $itemObj->getDb();  // DB実行

    $arg[0] = $drinkData['drink'];

    $itemObj->getInfo($arg);

    $data = $itemObj->outItemData();

    $arg = '../setwindow/php/act/text/'.$data[3].'.txt';

    $text = $itemObj->getInfoText($arg);

  }else{
    // echo "エラー";
  }

  $outInfo = null;

  for ($i=0; $i < count($text); $i++) { 
    $outInfo .= $text[$i];
  }

  echo $outInfo;

?>